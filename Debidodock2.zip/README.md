# debido

To install dependencies:

```bash
bun install
```

To run:

```bash
bun run index.ts
```

This project was created using `bun init` in bun v1.1.18. [Bun](https://bun.sh) is a fast all-in-one JavaScript runtime.

```Git
 1. git fetch origin (fetch remote) -> git branch -r (list remote branch)
 2. git checkout *branch*
 3. git branch -d *branch* (delete)
 4. git merge *name* (*name* -> current branch)
```

```
[webhooks]
api_version = "2024-10"

  [[webhooks.subscriptions]]
  topics = [
  "app/uninstalled",
  "bulk_operations/finish",
  "orders/create",
  "orders/fulfilled",
  "orders/updated",
  "orders/delete",
  "orders/cancelled",
  "refunds/create",
  "products/create",
  "products/update",
  "products/delete",
  "inventory_levels/update",
  "inventory_levels/connect",
  "inventory_levels/disconnect",
  "inventory_items/update",
  "inventory_items/create",
  "inventory_items/delete",
  "locations/create",
  "locations/activate",
  "locations/deactivate",
  "locations/delete",
  "locations/update"
]
  uri = "/shopify/webhooks"
```
