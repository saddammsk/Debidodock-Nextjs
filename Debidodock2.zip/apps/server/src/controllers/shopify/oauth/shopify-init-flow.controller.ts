import type { Context } from "hono";
import { validateShopifyHmac } from "../../../utils/validate-shopify-hmac";
import ShopifyToken from "shopify-token";
import { env } from "../../../types/env";
import { shopifyScopes } from "../../../config/shopify-scopes.config";
import db from "../../../lib/db";
import queryString from "query-string";
import workos from "../../../lib/workos";

const shopifyToken = new ShopifyToken({
  sharedSecret: env.SHOPIFY_CLIENT_SECRET,
  redirectUri: `${env.SERVER_URL}/shopify/callback`,
  apiKey: env.SHOPIFY_CLIENT_ID,
  scopes: shopifyScopes,
});

export const shopifyInitFlow = async (c: Context, qs: string) => {
  try {
    const queryObject = queryString.parse(qs);
    const shopUrl = queryObject.shop;

    if (typeof shopUrl !== "string") {
      return c.json({ error: "Invalid shop name" }, 400);
    }

    const isHmacValid = validateShopifyHmac({
      secret: env.SHOPIFY_CLIENT_SECRET,
      qs,
    });

    if (!isHmacValid) {
      return c.json({ error: "Invalid HMAC" }, 400);
    }

    const nonce = shopifyToken.generateNonce();
    const redirectUri = shopifyToken.generateAuthUrl(shopUrl, undefined, nonce);

    console.log("Redirecting to Shopify for OAuth flow: ", redirectUri);

    const shop = await db.shop.findUnique({
      where: { shopifyUrl: shopUrl },
    });

    if (shop) {
      // Redirect to app, since the shop is connected
      if (!shop.isUninstalled && shop.isShopifyInstalled) {
        return c.redirect(env.CLIENT_URL + "/inbox");
      }

      // Save nonce
      await db.shop.update({
        where: { shopifyUrl: shopUrl },
        data: { nonce },
      });

      // If the shop is uninstalled, but still has data. Redirect to Shopify to re-install the app.
      if (shop.isUninstalled) {
        return c.redirect(redirectUri);
      }

      // If the shop is not installed, redirect to Shopify to install the app.
      if (!shop.isShopifyInstalled) {
        return c.redirect(redirectUri);
      }
    } else {
      // Create organization in WorkOS
      const { id } = await workos.organizations.createOrganization({
        name: shopUrl,
      });

      // Create shop, since it doesn't exist
      await db.shop.create({
        data: {
          workosId: id,
          shopifyUrl: shopUrl,
          nonce,
        },
      });
    }

    return c.redirect(redirectUri);
  } catch (error) {
    console.error(error);
  }
};
