import type { Context } from "hono";
import queryString from "query-string";
import ShopifyToken from "shopify-token";
import { v4 } from "uuid";
import { shopifyScopes } from "../../../config/shopify-scopes.config";
import { shopifyBulkQueryOrdersInit } from "../../../handlers/shopify/init-bulk-queries/shopify-bulk-query-orders-init.handler";
import { handleSubscribeShopifyWebhooks } from "../../../handlers/shopify/shopify-subscribe-webhooks.handler";
import { shopifySyncShopData } from "../../../handlers/shopify/sync/shopify-sync-shop-data.handler";
import db from "../../../lib/db";
import { redis } from "../../../lib/redis";
import { env } from "../../../types/env";
import { validateShopifyHmac } from "../../../utils/validate-shopify-hmac";
import { shopifySyncLocationsData } from "../../../handlers/shopify/sync/shopify-sync-locations-data.handler";

const shopifyToken = new ShopifyToken({
  sharedSecret: env.SHOPIFY_CLIENT_SECRET,
  redirectUri: `${process.env.SERVER_URL}/shopify/callback`,
  apiKey: env.SHOPIFY_CLIENT_ID,
  scopes: shopifyScopes,
});

export const shopifyCallback = async (c: Context, qs: string) => {
  try {
    const queryObject = queryString.parse(qs);
    const shopUrl = queryObject.shop;
    const state = queryObject.state;
    const code = queryObject.code;

    // Check if the query is valid
    if (
      typeof shopUrl !== "string" ||
      typeof state !== "string" ||
      typeof code !== "string"
    ) {
      return c.json({ error: "Invalid shop name" }, 400);
    }

    const shop = await db.shop.findUniqueOrThrow({
      where: { shopifyUrl: shopUrl },
      select: { nonce: true, id: true },
    });

    const isHmacValid = validateShopifyHmac({
      secret: env.SHOPIFY_CLIENT_SECRET,
      qs,
    });

    // Scheck if the nonce created in "shopify-init-flow" is the same as the one in the query and if the hmac is valid
    if (!isHmacValid || state !== shop.nonce) {
      return c.json({ error: "Invalid HMAC" }, 400);
    }

    const accessToken = (await shopifyToken.getAccessToken(shopUrl, code))
      .access_token;

    const integration = await db.integration.findFirst({
      where: { AND: [{ shopId: shop.id }, { service: "SHOPIFY" }] },
    });

    if (!integration) {
      // If the integration doesn't exist, create it and save the access token
      await db.integration.create({
        data: {
          shopId: shop.id,
          service: "SHOPIFY",
          integrationSecret: {
            create: {
              accessToken,
            },
          },
        },
      });
    } else {
      // If the integration exists, update the access token
      await db.integrationSecret.update({
        where: { integrationId: integration.id },
        data: {
          accessToken,
        },
      });
    }

    // Mark connection complete with shopify installation flow is true, and that it's not uninstalled.
    await db.shop.update({
      where: { id: shop.id },
      data: {
        isShopifyInstalled: true,
        isUninstalled: false,
        nonce: null,
      },
    });

    // Subscribe to webhooks
    await handleSubscribeShopifyWebhooks(shop.id);

    // Sync bulk orders, products will be synced after the orders are synced. This is because Shopify only allows one bulk operation at a time per shop.
    await shopifyBulkQueryOrdersInit(shop.id);

    // Update shop with shopify data
    await shopifySyncShopData(shop.id);

    // Sync locations data
    await shopifySyncLocationsData(shop.id);

    const secret = v4();

    await redis.set(secret, shopUrl, "EX", 60 * 60);

    // Redirect to the onboarding page.
    return c.redirect(`${env.CLIENT_URL}/onboarding/auth?secret=${secret}`);
  } catch (error) {
    console.error(error);
    return c.json({ error: "Failed to connect user to shop" }, 500);
  }
};
