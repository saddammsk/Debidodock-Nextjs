import type { Context } from "hono";

export const productCreatedWebhook = async (c: Context) => {};
