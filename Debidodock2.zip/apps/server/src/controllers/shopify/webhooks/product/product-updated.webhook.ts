import type { Context } from "hono";

export const productUpdatedWebhook = async (c: Context) => {};
