import type { Context } from "hono";

export const productDeletedWebhook = async (c: Context) => {};
