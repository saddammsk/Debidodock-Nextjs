import type { Context } from "hono";

export const locationDeletedWebhook = async (c: Context) => {};
