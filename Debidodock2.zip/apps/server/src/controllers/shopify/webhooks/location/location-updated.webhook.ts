import type { Context } from "hono";

export const locationUpdatedWebhook = async (c: Context) => {};
