import type { Context } from "hono";

export const locationActivatedWebhook = async (c: Context) => {};
