import type { Context } from "hono";

export const locationDeactivatedWebhook = async (c: Context) => {};
