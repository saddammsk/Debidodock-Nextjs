import type { Context } from "hono";

export const inventoryItemCreatedWebhook = async (c: Context) => {};
