import type { Context } from "hono";

export const orderCancelledWebhook = async (c: Context) => {};
