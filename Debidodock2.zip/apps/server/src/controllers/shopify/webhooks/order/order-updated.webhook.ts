import type { Context } from "hono";

export const orderUpdatedWebhook = async (c: Context) => {};
