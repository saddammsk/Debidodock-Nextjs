import type { Context } from "hono";

export const orderFulfilledWebhook = async (c: Context) => {};
