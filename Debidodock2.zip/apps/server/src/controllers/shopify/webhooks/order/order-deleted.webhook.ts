import type { Context } from "hono";

export const orderDeletedWebhook = async (c: Context) => {};
