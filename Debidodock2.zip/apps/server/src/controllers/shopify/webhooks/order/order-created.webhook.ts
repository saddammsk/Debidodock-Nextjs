import type { Context } from "hono";

export const orderCreatedWebhook = async (c: Context) => {
  try {
    const data = c.get("body");
    console.log("Recieved data: ", data);

    return c.json({ message: `Recieved: ${data}` }, 200);
  } catch (error) {}
};
