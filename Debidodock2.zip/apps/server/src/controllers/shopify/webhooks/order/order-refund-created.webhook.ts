import type { Context } from "hono";

export const refundCreatedWebhook = async (c: Context) => {};
