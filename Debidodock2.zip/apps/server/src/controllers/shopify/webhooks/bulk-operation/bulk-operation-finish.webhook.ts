import type { Context } from "hono";
import db from "../../../../lib/db";
import {
  bulkOperationWebhookFinishBodySchema,
  currentBulkOperationResponseSchema,
} from "../../../../schema/shopify-schema";
import { Shopify } from "../../../../lib/shopify";
import { shopifySyncOrdersTrigger } from "../../../../trigger/shopify-sync-orders.trigger";
import { shopifySyncBulkProducts } from "../../../../handlers/shopify/sync/shopify-sync-bulk-products.handler";
import { shopifySyncProductsTrigger } from "../../../../trigger/shopify-sync-products.trigger";

export const bulkOperationFinishWebhook = async (
  c: Context,
  shopifyUrl: string
) => {
  try {
    console.log("Reached bulk");
    const body = c.get("body");
    const parsedBody = bulkOperationWebhookFinishBodySchema.parse(body);

    console.log("Parsed data: ", parsedBody);

    const shop = await db.shop.findUniqueOrThrow({
      where: { id: shopifyUrl },
      select: {
        id: true,
      },
    });

    const shopify = await Shopify(shop.id);

    const currentBulkOperation = await shopify.graphql(`{
      currentBulkOperation {
        status
        errorCode
        createdAt
        completedAt
        objectCount
        url
      }
    }`);

    console.log(currentBulkOperation);

    const parsedCurrentBulkOperation =
      currentBulkOperationResponseSchema.parse(currentBulkOperation);

    const bulkOperation = await db.shopifyBulkOperation.findUniqueOrThrow({
      where: { id: parsedBody.admin_graphql_api_id },
      select: {
        topic: true,
      },
    });

    let triggerTaskId;

    if (bulkOperation.topic === "ORDERS") {
      const task = await shopifySyncOrdersTrigger.trigger({
        url: parsedCurrentBulkOperation.currentBulkOperation.url,
        shopId: shop.id,
      });

      triggerTaskId = task.id;
    } else {
      // Sync the products bulk data.
      const task = await shopifySyncProductsTrigger.trigger({
        url: parsedCurrentBulkOperation.currentBulkOperation.url,
      });
      triggerTaskId = task.id;
    }

    await db.shopifyBulkOperation.update({
      where: { operationId: parsedBody.admin_graphql_api_id },
      data: {
        status:
          parsedCurrentBulkOperation.currentBulkOperation.status.toUpperCase(),
        triggerTaskId: triggerTaskId,
        url: parsedCurrentBulkOperation.currentBulkOperation.url,
        objectCount:
          parsedCurrentBulkOperation.currentBulkOperation.objectCount,
        completedAt:
          parsedCurrentBulkOperation.currentBulkOperation.completedAt,
      },
    });

    // Update the shop to indicate that there is no bulk operation running.
    await db.shop.update({
      where: { shopifyUrl },
      data: {
        hasBulkOperationRunning: false,
      },
    });

    return c.json("OK", 200);
  } catch (error) {
    console.error(error);
  }
};
