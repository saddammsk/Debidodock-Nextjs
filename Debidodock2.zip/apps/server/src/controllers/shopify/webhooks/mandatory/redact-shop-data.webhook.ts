import type { Context } from "hono";
import db from "../../../../lib/db";

export const redactShopDataWebhook = async (c: Context) => {
  try {
    const shopifyUrl = c.get("shopifyUrl");

    await db.shop.delete({
      where: { shopifyUrl },
    });

    console.log(shopifyUrl, ": Redacted app from webhook");

    return c.json("OK", 200);
  } catch (error) {
    console.error(error);
  }
};
