import type { Context } from "hono";
import db from "../../../../lib/db";

export const uninstallShopWebhook = async (c: Context) => {
  try {
    const shopifyUrl = c.get("shopifyUrl");

    console.log("Reached uninstall");

    if (!shopifyUrl) {
      return c.json("OK", 200);
    } else {
      await db.shop.update({
        where: { shopifyUrl },
        data: {
          isShopifyInstalled: false,
          isUninstalled: true,
        },
      });

      console.log(shopifyUrl, ": Uninstalled app from webhook");

      return c.json("OK", 200);
    }
  } catch (error) {
    console.error(error);
  }
};
