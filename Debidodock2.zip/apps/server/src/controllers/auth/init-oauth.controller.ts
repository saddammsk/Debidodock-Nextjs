import workos from "../../lib/workos";
import { env } from "../../types/env";

const clientId = env.WORKOS_CLIENT_ID;

export const initOAuth = (
  provider: string,
  state?: string
): string | undefined => {
  try {
    console.log("Generating auth url for provider: ", provider);
    const redirectUri = env.CLIENT_URL + "/auth/callback";

    return workos.sso.getAuthorizationUrl({
      provider,
      redirectUri,
      clientId,
      state: state ? state : "",
    });
  } catch (error) {
    console.error(error);
  }
};
