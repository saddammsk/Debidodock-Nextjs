import type { Context } from "hono";
import { redis } from "../../lib/redis";
import db from "../../lib/db";
import workos from "../../lib/workos";
import { generateSessionToken } from "../../handlers/sessions/generateSessionToken.handler";

export const connectShopUser = async (
  c: Context,
  secret: string,
  userId: string
) => {
  try {
    console.log("Connecting user to shop...");
    const shopUrl = await redis.get(secret);

    // Check if the values are valid
    if (!shopUrl) {
      console.error(
        `ShopUrl: ${shopUrl} is not valid, please check the secret`
      );
      return c.json({ error: "Invalid secret" }, 400);
    }

    // Get the shop by using the shopUrl found in the secret
    const shop = await db.shop.findUniqueOrThrow({
      where: { shopifyUrl: shopUrl },
    });
    const orgWorkOSId = shop.workosId;

    // Get the workosId of the user to create the membership
    const user = await db.user.findUniqueOrThrow({
      where: { id: userId },
      select: { workosId: true, id: true },
    });
    const userWorkOSId = user.workosId;

    // Create the membership in WorkOS
    const { id: membershipWorkOSId } =
      await workos.userManagement.createOrganizationMembership({
        organizationId: orgWorkOSId,
        userId: userWorkOSId,
        roleSlug: "admin",
      });

    // Create the membership in the database
    const membership = await db.membership.create({
      data: {
        userId: userId,
        workosId: membershipWorkOSId,
        role: "ADMIN",
        status: "ACTIVE",
        shopId: shop.id,
      },
    });

    console.log("User and shop is connected, generating session token");

    await generateSessionToken({
      c,
      memberWorkOSId: membership.id,
      userWorkOSId: user.id,
      role: "ADMIN",
      orgWorkOSId: shop.id,
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error(error);
    return c.json({ error: "Failed to connect user to shop" }, 500);
  }
};
