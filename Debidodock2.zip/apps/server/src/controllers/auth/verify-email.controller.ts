import type { Context } from "hono";
import workos from "../../lib/workos";
import { env } from "../../types/env";
import { handleAuthCallbackRedirect } from "../../handlers/auth/auth-callback-redirect.handler";
import { handleAuthOrganizationSelectionError } from "../../handlers/auth/auth-organization-selection-error.handler";
import { handleAuthEmailVerificationError } from "../../handlers/auth/auth-email-verification-error.handler";
import { getCookie } from "hono/cookie";

type AuthCallbackReturns = {
  redirectTo: string;
  redirectType: "path" | "url";
  organizations?: { id: string; name: string }[];
};

export const verifyEmail = async (
  c: Context,
  code: string,
  redirectAfterAuth?: string
): Promise<AuthCallbackReturns> => {
  try {
    const pendingAuthenticationToken = getCookie(
      c,
      "pendingAuthenticationToken"
    );

    if (!pendingAuthenticationToken) {
      console.error("No pending authentication token");
      return { redirectTo: "/auth/error", redirectType: "path" };
    }

    const { user, organizationId } =
      await workos.userManagement.authenticateWithEmailVerification({
        clientId: env.WORKOS_CLIENT_ID,
        code: code,
        pendingAuthenticationToken,
      });

    console.log("Redirect to app");
    return await handleAuthCallbackRedirect({
      c,
      organizationId,
      user,
      redirectAfterAuth,
    });
  } catch (error: any) {
    console.error(error.rawData);
    if (error.rawData.code === "organization_selection_required") {
      return await handleAuthOrganizationSelectionError({
        c,
        responseData: error.rawData,
        redirectAfterAuth,
      });
    } else if (error.rawData.code === "email_verification_required") {
      return await handleAuthEmailVerificationError({
        c,
        responseData: error.rawData,
        redirectAfterAuth,
      });
    } else {
      console.log("Redirect to error");
      return { redirectTo: "/auth/error", redirectType: "path" };
    }
  }
};
