import type { Context } from "hono";
import db from "../../lib/db";
import { generateSessionToken } from "../../handlers/sessions/generateSessionToken.handler";

export const shopSelectionLogin = async (
  c: Context,
  orgWorkOSId: string,
  userWorkOSId: string
) => {
  try {
    const shop = await db.shop.findUniqueOrThrow({
      where: { workosId: orgWorkOSId },
    });
    const user = await db.user.findUniqueOrThrow({
      where: { workosId: userWorkOSId },
    });

    const membership = await db.membership.findFirst({
      where: { shopId: shop.id, userId: user.id },
    });

    if (!membership) {
      console.log("Membership not found");
      return c.json({ error: "Invalid membership" }, 400);
    }

    console.log("Membership exists, generating session token");

    await generateSessionToken({
      c,
      memberWorkOSId: membership.id,
      userWorkOSId,
      role: membership.role,
      orgWorkOSId: orgWorkOSId,
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error(error);
    return c.json({ error: "Failed to connect user to shop" }, 500);
  }
};
