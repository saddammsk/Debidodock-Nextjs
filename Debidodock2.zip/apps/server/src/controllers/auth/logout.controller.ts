import { getCookie } from "hono/cookie";
import { redis } from "../../lib/redis";
import type { Context } from "hono";

export const logout = async (c: Context) => {
  try {
    const sessionToken = getCookie(c, "sessionToken");
    const intermediateToken = getCookie(c, "intermediateToken");

    if (sessionToken) {
      await redis.del(sessionToken);
    }

    if (intermediateToken) {
      await redis.del(intermediateToken);
    }

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error(error);
  }
};
