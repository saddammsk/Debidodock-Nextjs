import type { Context } from "hono";
import { handleAuthCallbackRedirect } from "../../handlers/auth/auth-callback-redirect.handler";
import { handleAuthOrganizationSelectionError } from "../../handlers/auth/auth-organization-selection-error.handler";
import workos from "../../lib/workos";
import { env } from "../../types/env";
import { handleAuthEmailVerificationError } from "../../handlers/auth/auth-email-verification-error.handler";

type AuthCallbackReturns = {
  redirectTo: string;
  redirectType: "path" | "url";
  organizations?: { id: string; name: string }[];
};

export const authCallback = async (
  c: Context,
  code: string,
  redirectAfterAuth?: string
): Promise<AuthCallbackReturns> => {
  try {
    console.log("Authenticating user in auth callback...");
    const { user, organizationId } =
      await workos.userManagement.authenticateWithCode({
        code,
        clientId: env.WORKOS_CLIENT_ID,
      });

    return await handleAuthCallbackRedirect({
      c,
      organizationId,
      redirectAfterAuth,
      user,
    });
  } catch (error: any) {
    console.error(error.rawData);
    if (error.rawData.code === "organization_selection_required") {
      return await handleAuthOrganizationSelectionError({
        c,
        responseData: error.rawData,
        redirectAfterAuth,
      });
    } else if (error.rawData.code === "email_verification_required") {
      return await handleAuthEmailVerificationError({
        c,
        responseData: error.rawData,
        redirectAfterAuth,
      });
    } else {
      console.log("Redirect to error");
      return { redirectTo: "/auth/error", redirectType: "path" };
    }
  }
};
