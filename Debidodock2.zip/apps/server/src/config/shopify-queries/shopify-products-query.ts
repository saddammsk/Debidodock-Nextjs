import { format } from "date-fns";

const today = format(new Date(), "yyyy-MM-dd");

export const shopifyProductsQuery = /* GraphQL */ `
    products(query: "created_at:>=2010-01-01 AND created_at:<${today}") {
      edges {
        node {
          id
          featuredImage {
            url
          }
          title
          handle
          status
          variants(first: 1000) {
            edges {
              node {
                id
                title
                price
                barcode
                inventoryItem {
                  id
                  sku
                  unitCost {
                    amount
                  }
                  inventoryLevels(first: 1000) {
                    edges {
                      node {
                        id
                        quantities(names: ["on_hand", "available", "committed", "incoming"]) {
                          id
                          quantity
                          name
                        }
                        location {
                          id
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
}`;
