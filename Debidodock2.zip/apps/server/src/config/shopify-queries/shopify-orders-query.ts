import { format } from "date-fns";

const today = format(new Date(), "yyyy-MM-dd");

export const shopifyOrdersQuery = /* GraphQL */ `
  orders(query: "created_at:>=2010-01-01 AND created_at:<${today}") {
    edges {
      node {
        id
        name
        displayFulfillmentStatus
        createdAt
        updatedAt
        totalWeight
        taxLines {
          ratePercentage
          priceSet {
            shopMoney {
              amount
            }
          }
        }
        processedAt
        transactions {
          paymentIcon {
            url
          }
          formattedGateway
          gateway
        }
        lineItems(first: 1000) {
          edges {
            node {
              id
              taxable
              vendor
              duties {
                taxLines {
                  priceSet {
                    shopMoney {
                      amount
                    }
                  }
                }
              }
              quantity
              name
              variant {
                id
                inventoryItem {
                  inventoryLevels(first: 1000) {
                    edges {
                      node {
                        id
                      }
                    }
                  }
                }
              }
            }
          }
        }
        fulfillmentOrders(first: 1000) {
          edges {
            node {
              id
              deliveryMethod {
                methodType
                serviceCode
              }
            }
          }
        }
        currentTotalPriceSet {
          presentmentMoney {
            amount
            currencyCode
          }
          shopMoney {
            amount
            currencyCode
          }
        }
      }
    }
  }
`;
