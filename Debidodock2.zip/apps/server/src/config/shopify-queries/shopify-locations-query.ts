export const shopifyLocationsQuery = /* GraphQL */ `
    locations(first: 1000) {
      edges {
        node {
          id
          address {
            address1
            city
            country
            countryCode
            phone
            province
            zip
            longitude
            latitude
          }
        }
      }
    }
`;
