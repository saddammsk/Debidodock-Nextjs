import { z } from "zod";

const bulkStatusLowerCaseEnum = z.enum([
  "canceled",
  "canceling",
  "completed",
  "created",
  "expired",
  "failed",
  "running",
]);

export const createBulkOperationResponseSchema = z.object({
  bulkOperationRunQuery: z.object({
    bulkOperation: z.object({
      id: z.string(),
      status: z.enum([
        "CANCELED",
        "CANCELING",
        "COMPLETED",
        "CREATED",
        "EXPIRED",
        "FAILED",
        "RUNNING",
      ]),
    }),
    userErrors: z.array(z.object({})),
  }),
});

export const currentBulkOperationResponseSchema = z.object({
  currentBulkOperation: z.object({
    status: bulkStatusLowerCaseEnum,
    errorCode: z.string().nullable().optional(),
    createdAt: z.string(),
    completedAt: z.string(),
    objectCount: z.number(),
    url: z.string(),
  }),
});

export const bulkOperationWebhookFinishBodySchema = z.object({
  admin_graphql_api_id: z.string(),
  completed_at: z.string(),
  created_at: z.string(),
  error_code: z.string().nullable().optional(),
  status: bulkStatusLowerCaseEnum,
  type: z.string(),
});

export const shopifyProductsQuerySchema = z.object({
  products: z.object({
    edges: z.array(
      z.object({
        node: z.object({
          featuredImage: z.object({
            url: z.string(),
          }),
          title: z.string(),
          handle: z.string(),
          status: z.string(),
          variants: z.object({
            edges: z.array(
              z.object({
                node: z.object({
                  title: z.string(),
                  price: z.number(),
                  barcode: z.string(),
                  inventoryItem: z.object({
                    id: z.string(),
                    sku: z.string(),
                    unitCost: z.object({
                      amount: z.number(),
                    }),
                    inventoryLevels: z.object({
                      edges: z.array(
                        z.object({
                          node: z.object({
                            id: z.string(),
                            quantities: z.object({
                              id: z.string(),
                              quantity: z.number(),
                              name: z.string(),
                            }),
                            location: z.object({
                              id: z.string(),
                            }),
                          }),
                        })
                      ),
                    }),
                  }),
                }),
              })
            ),
          }),
        }),
      })
    ),
  }),
});
