import queryString from "query-string";
import crypto from "crypto";

type ValidateShopifyHmacProps = {
  secret: string;
  qs: string;
};

export const validateShopifyHmac = ({
  secret,
  qs,
}: ValidateShopifyHmacProps) => {
  const query = queryString.parse(qs);
  const hmac = query.hmac;

  delete query.hmac;

  const input = queryString.stringify(query);

  const hash = crypto.createHmac("SHA256", secret).update(input).digest("hex");

  return hash === hmac;
};
