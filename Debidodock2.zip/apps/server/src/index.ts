import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import { env } from "./types/env";

// Routes imports
import { authRoutes } from "./routes/auth.route";
import { shopifyRoutes } from "./routes/shopify.route";
import { shopifyWebhookRoutes } from "./routes/shopify-webhooks.route";

const app = new Hono();

// Middlewares
app.use(logger());
app.use(
  "/*",
  cors({
    origin: env.CLIENT_URL,
    credentials: true,
  })
);

// Routes
const routes = app
  .basePath("/")
  .route("/auth", authRoutes)
  .route("/shopify", shopifyRoutes)
  .route("/shopify/webhooks", shopifyWebhookRoutes);

export default {
  port: env.PORT,
  fetch: app.fetch,
};

export type AppType = typeof routes;
