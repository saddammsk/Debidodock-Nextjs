import { task } from "@trigger.dev/sdk/v3";
import { shopifySyncBulkProducts } from "../handlers/shopify/sync/shopify-sync-bulk-products.handler";

export const shopifySyncProductsTrigger = task({
  id: "shopify-sync-products",
  run: async (payload: { url: string }) => {
    const url = payload.url;

    await shopifySyncBulkProducts(url);
  },
});
