import { task } from "@trigger.dev/sdk/v3";
import { shopifySyncBulkOrders } from "../handlers/shopify/sync/shopify-sync-bulk-orders.handler";
import { shopifyBulkQueryProductsInit } from "../handlers/shopify/init-bulk-queries/shopify-bulk-query-products-init.handler";

export const shopifySyncOrdersTrigger = task({
  id: "shopify-sync-orders",
  run: async (payload: { url: string; shopId: string }) => {
    const url = payload.url;
    await shopifySyncBulkOrders(url);
  },
  onSuccess: async (payload: { url: string; shopId: string }) => {
    const shopId = payload.shopId;
    await shopifyBulkQueryProductsInit(shopId);
  },
});
