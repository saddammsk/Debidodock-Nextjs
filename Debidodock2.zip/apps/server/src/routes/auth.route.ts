import { zValidator } from "@hono/zod-validator";
import { Hono } from "hono";
import { z } from "zod";
import { authCallback } from "../controllers/auth/auth-callback.controller";
import { connectShopUser } from "../controllers/auth/connect-shop-user.controller";
import { initOAuth } from "../controllers/auth/init-oauth.controller";
import { validateSession } from "../middlewares/validate-session.middleware";
import { shopSelectionLogin } from "../controllers/auth/shop-selection-login.controller";
import { logout } from "../controllers/auth/logout.controller";
import { getCookie } from "hono/cookie";
import { verifyEmail } from "../controllers/auth/verify-email.controller";

const authCallbackSchema = z.object({
  code: z.string(),
  state: z.string().optional(),
});

const loginSchema = z.object({
  provider: z.enum([
    "GoogleOAuth",
    "GitHubOAuth",
    "MicrosoftOAuth",
    "AppleOAuth",
  ]),
  redirectAfterAuth: z.string().optional(),
});

const shopLoginSchema = z.object({
  orgWorkOSId: z.string(),
});

const verifyEmailSchema = z.object({
  code: z.string(),
  redirectAfterAuth: z.string().optional(),
});

const connectShopifySchema = z.object({
  secret: z.string(),
});

type Variables = {
  userWorkOSId: string;
  orgWorkOSId?: string;
  role?: string;
  memberWorkOSId?: string;
};

export const authRoutes = new Hono<{ Variables: Variables }>()
  // AUTH
  .get("/", validateSession, async (c) => {
    return c.json({ success: true });
  })
  // LOGIN
  .post("/login", zValidator("json", loginSchema), (c) => {
    const { provider, redirectAfterAuth } = c.req.valid("json");
    const redirectUrl = initOAuth(provider, redirectAfterAuth);

    if (!redirectUrl) {
      return c.json({ error: "Could not generate redirect url" }, 400);
    }

    return c.json({ redirectUrl });
  })
  // CALLBACK
  .get("/callback", zValidator("query", authCallbackSchema), async (c) => {
    const { code, state: redirectAfterAuth } = c.req.valid("query");
    const { redirectTo, organizations, redirectType } = await authCallback(
      c,
      code,
      redirectAfterAuth
    );

    return c.json({ redirectTo, organizations, redirectType });
  })
  .post("/logout", validateSession, async (c) => {
    return await logout(c);
  })
  .post(
    "/shop-selection-login",
    validateSession,
    zValidator("json", shopLoginSchema),
    async (c) => {
      const { orgWorkOSId } = c.req.valid("json");
      const userWorkOSId = c.get("userWorkOSId");
      return await shopSelectionLogin(c, orgWorkOSId, userWorkOSId);
    }
  )
  .get(
    "/connect-shop-user",
    validateSession,
    zValidator("query", connectShopifySchema),
    async (c) => {
      const secret = c.req.valid("query").secret;
      const userWorkOSId = c.get("userWorkOSId");
      return await connectShopUser(c, secret, userWorkOSId);
    }
  )
  .post("/verify-email", zValidator("json", verifyEmailSchema), async (c) => {
    const code = c.req.valid("json").code;
    const redirectAfterAuth = c.req.valid("json").redirectAfterAuth;

    const res = await verifyEmail(c, code, redirectAfterAuth);

    return c.json(res);
  });
