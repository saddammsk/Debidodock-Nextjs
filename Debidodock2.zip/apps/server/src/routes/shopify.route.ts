import queryString from "query-string";
import { Hono } from "hono";
import { shopifyInitFlow } from "../controllers/shopify/oauth/shopify-init-flow.controller";
import { shopifyCallback } from "../controllers/shopify/oauth/shopify-callback.controller";

export const shopifyRoutes = new Hono()
  .get("/init", async (c) => {
    const query = c.req.query();
    const stringifiedQuery = queryString.stringify(query);

    return await shopifyInitFlow(c, stringifiedQuery);
  })
  .get("/callback", async (c) => {
    const qs = c.req.query();
    const stringifiedQuery = queryString.stringify(qs);

    return await shopifyCallback(c, stringifiedQuery);
  });
