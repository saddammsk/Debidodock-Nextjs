import { Hono } from "hono";
import { validateShopifyWebhook } from "../middlewares/validate-shopify-webhook.middleware";

import { uninstallShopWebhook } from "../controllers/shopify/webhooks/mandatory/uninstall.webhook";
import { redactShopDataWebhook } from "../controllers/shopify/webhooks/mandatory/redact-shop-data.webhook";
import { orderCreatedWebhook } from "../controllers/shopify/webhooks/order/order-created.webhook";
import { orderFulfilledWebhook } from "../controllers/shopify/webhooks/order/order-fulfilled.webhook";
import { orderUpdatedWebhook } from "../controllers/shopify/webhooks/order/order-updated.webhook";
import { orderDeletedWebhook } from "../controllers/shopify/webhooks/order/order-deleted.webhook";
import { orderCancelledWebhook } from "../controllers/shopify/webhooks/order/order-cancelled.webhook";
import { refundCreatedWebhook } from "../controllers/shopify/webhooks/order/order-refund-created.webhook";
import { productCreatedWebhook } from "../controllers/shopify/webhooks/product/product-created.webhook";
import { productUpdatedWebhook } from "../controllers/shopify/webhooks/product/product-updated.webhook";
import { productDeletedWebhook } from "../controllers/shopify/webhooks/product/product-deleted.webhook";
import { inventoryLevelUpdatedWebhook } from "../controllers/shopify/webhooks/inventory-level/inventory-level-updated.webhook";
import { inventoryLevelConnectedWebhook } from "../controllers/shopify/webhooks/inventory-level/inventory-level-connected.webhook";
import { inventoryLevelDisconnectedWebhook } from "../controllers/shopify/webhooks/inventory-level/inventory-level-disconnected.webhook";
import { inventoryItemUpdatedWebhook } from "../controllers/shopify/webhooks/inventory-item/inventory-item-updated.webhook";
import { inventoryItemCreatedWebhook } from "../controllers/shopify/webhooks/inventory-item/inventory-item-created.webhook";
import { inventoryItemDeletedWebhook } from "../controllers/shopify/webhooks/inventory-item/inventory-item-deleted.webhook";
import { locationCreatedWebhook } from "../controllers/shopify/webhooks/location/location-created.webhook";
import { locationActivatedWebhook } from "../controllers/shopify/webhooks/location/location-activated.webhook";
import { locationDeactivatedWebhook } from "../controllers/shopify/webhooks/location/location-deactivated.webhook";
import { locationDeletedWebhook } from "../controllers/shopify/webhooks/location/location-deleted.webhook";
import { locationUpdatedWebhook } from "../controllers/shopify/webhooks/location/location-updated.webhook";
import { bulkOperationFinishWebhook } from "../controllers/shopify/webhooks/bulk-operation/bulk-operation-finish.webhook";

type Variables = {
  shopifyUrl: string;
  body: string;
};

// Body can be accessed with c.get("body")

export const shopifyWebhookRoutes = new Hono<{ Variables: Variables }>()
  .use(validateShopifyWebhook)
  // MANDATORY
  .post("/uninstall", async (c) => {
    return await uninstallShopWebhook(c);
  })
  .post("/redact", async (c) => {
    return await redactShopDataWebhook(c);
  })
  // BULK OPERATION
  .post("/bulk-operation-finish", async (c) => {
    const shopifyUrl = c.get("shopifyUrl");
    return await bulkOperationFinishWebhook(c, shopifyUrl);
  })
  // ORDER
  .post("/order-created", async (c) => {
    return await orderCreatedWebhook(c);
  })
  .post("/order-fulfilled", async (c) => {
    return await orderFulfilledWebhook(c);
  })
  .post("/order-updated", async (c) => {
    return await orderUpdatedWebhook(c);
  })
  .post("/order-deleted", async (c) => {
    return await orderDeletedWebhook(c);
  })
  .post("/order-cancelled", async (c) => {
    return await orderCancelledWebhook(c);
  })
  .post("/refund-created", async (c) => {
    return await refundCreatedWebhook(c);
  })
  // PRODUCT
  .post("/product-created", async (c) => {
    return await productCreatedWebhook(c);
  })
  .post("/product-updated", async (c) => {
    return await productUpdatedWebhook(c);
  })
  .post("/product-deleted", async (c) => {
    return await productDeletedWebhook(c);
  })
  // INVENTORY LEVEL
  .post("/inventory-level-updated", async (c) => {
    return await inventoryLevelUpdatedWebhook(c);
  })
  .post("/inventory-level-connected", async (c) => {
    return await inventoryLevelConnectedWebhook(c);
  })
  .post("/inventory-level-disconnected", async (c) => {
    return await inventoryLevelDisconnectedWebhook(c);
  })
  // INVENTORY ITEM
  .post("/inventory-item-updated", async (c) => {
    return await inventoryItemUpdatedWebhook(c);
  })
  .post("/inventory-item-created", async (c) => {
    return await inventoryItemCreatedWebhook(c);
  })
  .post("/inventory-item-deleted", async (c) => {
    return await inventoryItemDeletedWebhook(c);
  })
  // LOCATION
  .post("/location-created", async (c) => {
    return await locationCreatedWebhook(c);
  })
  .post("/location-activated", async (c) => {
    return await locationActivatedWebhook(c);
  })
  .post("/location-deactivated", async (c) => {
    return await locationDeactivatedWebhook(c);
  })
  .post("/location-deleted", async (c) => {
    return await locationDeletedWebhook(c);
  })
  .post("/location-updated", async (c) => {
    return await locationUpdatedWebhook(c);
  });
