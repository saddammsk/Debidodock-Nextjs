import { z } from "zod";

const envSchema = z.object({
  DATABASE_URL: z.string({
    required_error: "DATABASE_URL is required",
  }),
  PRISMA_FIELD_ENCRYPTION_KEY: z.string({
    required_error: "PRISMA_FIELD_ENCRYPTION_KEY is required",
  }),
  PORT: z.string({
    required_error: "PORT is required",
  }),
  NODE_ENV: z.enum(["development", "production", "test"], {
    required_error: "NODE_ENV is required",
  }),
  SERVER_URL: z.string({
    required_error: "SERVER_URL is required",
  }),
  CLIENT_URL: z.string({
    required_error: "CLIENT_URL is required",
  }),
  DATABASE_URL_UNPOOLED: z.string({
    required_error: "DATABASE_URL_UNPOOLED is required",
  }),
  WORKOS_API_KEY: z.string({
    required_error: "WORKOS_API_KEY is required",
  }),
  WORKOS_CLIENT_ID: z.string({
    required_error: "WORKOS_CLIENT_ID is required",
  }),
  SHOPIFY_CLIENT_ID: z.string({
    required_error: "SHOPIFY_CLIENT_ID is required",
  }),
  SHOPIFY_CLIENT_SECRET: z.string({
    required_error: "SHOPIFY_CLIENT_SECRET is required",
  }),
  SHOPIFY_APP_URL: z.string({
    required_error: "SHOPIFY_APP_URL is required",
  }),
  SHOPIFY_VERSION: z.string({
    required_error: "SHOPIFY_VERSION is required",
  }),
  REDIS_URL: z.string({
    required_error: "REDIS_URL is required",
  }),
});

export const env = envSchema.parse(process.env);
