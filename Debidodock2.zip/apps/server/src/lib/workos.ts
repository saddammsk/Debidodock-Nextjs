import { WorkOS } from "@workos-inc/node";
import { env } from "../types/env";

const workos = new WorkOS(env.WORKOS_API_KEY);

export default workos;
