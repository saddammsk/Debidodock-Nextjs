import { PrismaClient } from "@prisma/client";
import { fieldEncryptionExtension } from "prisma-field-encryption";

const prismaClientWithEncryption = () => {
  const prisma = new PrismaClient();
  fieldEncryptionExtension({
    encryptionKey: process.env.PRISMA_FIELD_ENCRYPTION_KEY,
  });
  return prisma;
};

declare global {
  var prismaGlobal: undefined | ReturnType<typeof prismaClientWithEncryption>;
}

const db = globalThis.prismaGlobal ?? prismaClientWithEncryption();

export default db;

if (process.env.NODE_ENV !== "production") {
  globalThis.prismaGlobal = db;
}
