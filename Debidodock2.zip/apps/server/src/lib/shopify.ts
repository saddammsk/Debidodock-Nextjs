import shopify from "shopify-api-node";
import db from "./db";
import { env } from "../types/env";

export const Shopify = async (shopId: string) => {
  const shop = await db.shop.findUniqueOrThrow({
    where: { id: shopId },
    include: {
      integrations: {
        where: { service: "SHOPIFY" },
        include: { integrationSecret: { select: { accessToken: true } } },
        take: 1,
      },
    },
  });

  const shopName = shop.shopifyUrl;
  const accessToken = shop.integrations[0].integrationSecret?.accessToken;

  if (!accessToken) {
    console.error(`Error in shopifySyncBulkData: Access token is not set`);
    throw new Error("Access token is not set");
  }

  if (!shopName) {
    console.error(`Error in shopifySyncBulkData: Shop name is not set`);
    throw new Error("Shop name is not set");
  }

  return new shopify({
    shopName,
    accessToken,
    apiVersion: env.SHOPIFY_VERSION,
  });
};
