import { redis } from "../../lib/redis";
import type { SessionToken } from "./generateSessionToken.handler";

export const parseSessionToken = async (
  sessionToken: string
): Promise<SessionToken | null> => {
  const jsonString = await redis.get(sessionToken);

  if (!jsonString) {
    return null;
  } else {
    const sessionData = JSON.parse(jsonString);

    return sessionData;
  }
};
