import { redis } from "../../lib/redis";

export const revokeSessionByMembershipId = async (
  memberWorkOSId: string
): Promise<void> => {
  try {
    const sessionToken = await redis.get(memberWorkOSId);

    if (!sessionToken) {
      return;
    }

    await redis.del(sessionToken);
  } catch (error) {
    console.error(error);
  }
};
