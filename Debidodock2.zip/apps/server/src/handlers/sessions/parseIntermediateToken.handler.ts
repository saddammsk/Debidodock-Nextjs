import { redis } from "../../lib/redis";

export const parseIntermediateToken = async (
  intermediateToken: string
): Promise<string | null> => {
  try {
    const userId = await redis.get(intermediateToken);
    if (!userId) {
      return null;
    }
    return userId;
  } catch (error) {
    console.error(error);
    return null;
  }
};
