import { setCookie } from "hono/cookie";
import { INTERMEDIATE_TOKEN_EXPIRY_HOUR } from "../../config";
import type { Context } from "hono";
import { v4 } from "uuid";
import { redis } from "../../lib/redis";

type GenerateIntermediateTokenProps = {
  userWorkOSId: string;
  c: Context;
};

export const generateIntermediateToken = async ({
  c,
  userWorkOSId,
}: GenerateIntermediateTokenProps) => {
  try {
    const intermediateSessionToken = v4();

    setCookie(c, "intermediateToken", intermediateSessionToken, {
      maxAge: INTERMEDIATE_TOKEN_EXPIRY_HOUR * 60 * 60 * 1000,
      httpOnly: true,
      secure: true,
      sameSite: "none",
    });

    const expiresInSeconds = INTERMEDIATE_TOKEN_EXPIRY_HOUR * 60 * 60;

    console.log("Setting intermediate token in Redis");

    await redis.set(
      intermediateSessionToken,
      userWorkOSId,
      "EX",
      expiresInSeconds
    );

    return intermediateSessionToken;
  } catch (error) {
    console.error(error);
  }
};
