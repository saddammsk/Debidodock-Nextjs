import { v4 } from "uuid";
import { SESSION_TOKEN_EXPIRY_DAYS } from "../../config";
import type { Context } from "hono";
import { setCookie } from "hono/cookie";
import { redis } from "../../lib/redis";

export type SessionToken = {
  userWorkOSId: string;
  orgWorkOSId: string;
  memberWorkOSId: string;
  role: string;
};

type SessionTokenProps = {
  c: Context;
} & SessionToken;

export const generateSessionToken = async ({
  memberWorkOSId,
  role,
  orgWorkOSId,
  userWorkOSId,
  c,
}: SessionTokenProps) => {
  try {
    const sessionToken = v4();

    const expiresInSeconds = SESSION_TOKEN_EXPIRY_DAYS * 24 * 60 * 60;

    const jsonString = JSON.stringify({
      userWorkOSId,
      orgWorkOSId,
      memberWorkOSId,
      role,
    });

    setCookie(c, "sessionToken", sessionToken, {
      httpOnly: true,
      sameSite: "none",
      maxAge: expiresInSeconds,
    });

    console.log("Setting session token in Redis");

    await redis.set(sessionToken, jsonString, "EX", expiresInSeconds);
    await redis.set(memberWorkOSId, sessionToken, "EX", expiresInSeconds);

    return sessionToken;
  } catch (error) {
    console.error(error);
  }
};
