import { redis } from "../../lib/redis";
import type { SessionToken } from "./generateSessionToken.handler";

export const revokeSessionToken = async (
  sessionToken: string
): Promise<void> => {
  try {
    const jsonString = await redis.get(sessionToken);

    if (!jsonString) {
      return;
    }

    const sessionData = JSON.parse(jsonString) as SessionToken;

    await redis.del(sessionData.memberWorkOSId);

    await redis.del(sessionToken);
  } catch (error) {
    console.error(error);
  }
};
