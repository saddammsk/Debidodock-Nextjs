import type { Context } from "hono";
import db from "../../lib/db";
import { generateSessionToken } from "../sessions/generateSessionToken.handler";
import { env } from "../../types/env";
import { generateIntermediateToken } from "../sessions/generateIntermediateToken.handler";
import type { User } from "@workos-inc/node";

type HandleAuthCallbackRedirectProps = {
  organizationId?: string;
  redirectAfterAuth?: string;
  user: User;
  c: Context;
};

type HandleAuthCallbackRedirectReturns = {
  redirectTo: string;
  redirectType: "path" | "url";
};

export const handleAuthCallbackRedirect = async ({
  c,
  organizationId,
  redirectAfterAuth,
  user,
}: HandleAuthCallbackRedirectProps): Promise<HandleAuthCallbackRedirectReturns> => {
  try {
    console.log("Handling auth callback redirect...");
    await db.user.upsert({
      where: { email: user.email },
      create: {
        name: user.firstName + " " + user.lastName || "",
        email: user.email,
        workosId: user.id,
      },
      update: {
        name: user.firstName + " " + user.lastName || "",
        email: user.email,
        workosId: user.id,
      },
    });

    if (organizationId) {
      // User has one organization, create a session token
      const shop = await db.shop.findUniqueOrThrow({
        where: { workosId: organizationId },
        select: { id: true },
      });

      const membership = await db.membership.findFirstOrThrow({
        where: { userId: user.id, shopId: shop.id },
        select: { id: true, role: true, workosId: true },
      });

      console.log(
        "One organization is connected to the user, generating session token"
      );

      await generateSessionToken({
        c,
        memberWorkOSId: membership.workosId,
        userWorkOSId: user.id,
        role: membership.role,
        orgWorkOSId: organizationId,
      });

      // Redirect to the inbox
      return { redirectTo: "/inbox", redirectType: "path" };
    } else if (!organizationId && !redirectAfterAuth) {
      await generateIntermediateToken({ c, userWorkOSId: user.id });
      // If there is no organization and no redirectAfterAuth, redirect to Shopify to install the app.

      return { redirectTo: env.SHOPIFY_APP_URL, redirectType: "url" };
    } else {
      // First time user is connecting to a new shop, generate an intermediate token
      await generateIntermediateToken({
        c,
        userWorkOSId: user.id,
      });

      return {
        redirectTo: "/onboarding/cost",
        redirectType: "path",
      };
    }
  } catch (error) {
    console.error(error);
    return {
      redirectTo: "/auth/error",
      redirectType: "path",
    };
  }
};
