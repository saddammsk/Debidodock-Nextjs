import { z } from "zod";
import { generateIntermediateToken } from "../sessions/generateIntermediateToken.handler";
import type { Context } from "hono";

const organizationSchema = z.object({
  id: z.string(),
  name: z.string(),
});

const userSchema = z.object({
  object: z.literal("user"),
  id: z.string(),
  email: z.string().email(),
  first_name: z.string(),
  last_name: z.string(),
  email_verified: z.boolean(),
  profile_picture_url: z.string().url(),
  created_at: z.string(),
  updated_at: z.string(),
});

const responseSchema = z.object({
  code: z.literal("organization_selection_required"),
  message: z.string(),
  pending_authentication_token: z.string(),
  organizations: z.array(organizationSchema),
  user: userSchema,
});

type ResponseSchema = z.infer<typeof responseSchema>;

type HandleAuthOrganizationSelectionErrorProps = {
  redirectAfterAuth?: string;
  responseData: ResponseSchema;
  c: Context;
};

type HandleAuthOrganizationSelectionErrorReturns = {
  redirectTo: string;
  redirectType: "path" | "url";
  organizations?: { id: string; name: string }[];
};

export const handleAuthOrganizationSelectionError = async ({
  responseData,
  redirectAfterAuth,
  c,
}: HandleAuthOrganizationSelectionErrorProps): Promise<HandleAuthOrganizationSelectionErrorReturns> => {
  try {
    const response = responseSchema.parse(responseData);
    await generateIntermediateToken({
      c,
      userWorkOSId: response.user.id,
    });

    // The user is going to install another shop, redirect to the onboarding page
    if (redirectAfterAuth?.includes("/onboarding/auth?")) {
      console.log("RedirectAfterAuth includes onboarding");
      return {
        redirectTo: redirectAfterAuth,
        redirectType: "path",
      };
    }

    console.log("Redirect to choose shop");
    return {
      redirectTo: "/auth/choose-shop",
      organizations: response.organizations,
      redirectType: "path",
    };
  } catch (error) {
    console.error(error);
    return {
      redirectTo: "/auth/error",
      redirectType: "path",
    };
  }
};
