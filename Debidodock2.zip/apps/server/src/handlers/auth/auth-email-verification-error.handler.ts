import type { Context } from "hono";
import { setCookie } from "hono/cookie";
import { z } from "zod";

const emailVerificationResponseSchema = z.object({
  code: z.literal("email_verification_required"),
  message: z.string(),
  pending_authentication_token: z.string(),
  email: z.string().email(),
  email_verification_id: z.string(),
});

type EmailVerificationResponseSchema = z.infer<
  typeof emailVerificationResponseSchema
>;

type HandleAuthEmailVerificationErrorProps = {
  responseData: EmailVerificationResponseSchema;
  redirectAfterAuth?: string;
  c: Context;
};

type HandleAuthEmailVerificationErrorReturns = {
  redirectTo: string;
  redirectType: "path" | "url";
  organizations?: { id: string; name: string }[];
};

export const handleAuthEmailVerificationError = async ({
  c,
  redirectAfterAuth,
  responseData,
}: HandleAuthEmailVerificationErrorProps): Promise<HandleAuthEmailVerificationErrorReturns> => {
  try {
    const response = emailVerificationResponseSchema.parse(responseData);
    console.log("Redirect to verify email");
    setCookie(
      c,
      "pendingAuthenticationToken",
      response.pending_authentication_token,
      {
        httpOnly: true,
        sameSite: "none",
        maxAge: 60 * 60 * 24 * 7,
        secure: true,
      }
    );
    return {
      redirectTo: `/auth/verify-email?redirectAfterAuth=${redirectAfterAuth}`,
      redirectType: "path",
    };
  } catch (error) {
    console.error(error);

    return {
      redirectTo: "/auth/error",
      redirectType: "path",
    };
  }
};
