import { Readable } from "stream";
import readline from "readline";

export const shopifySyncBulkOrders = async (url: string) => {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    if (!response.body) {
      throw new Error("Response body is null");
    }

    const reader = response.body.getReader();

    // Create a custom Readable stream from the response body
    const readable = new Readable({
      async read() {
        try {
          const { done, value } = await reader.read();
          if (done) {
            this.push(null);
          } else {
            this.push(Buffer.from(value));
          }
        } catch (error) {
          this.destroy(error as Error);
        }
      },
    });

    const rl = readline.createInterface({
      input: readable,
      crlfDelay: Infinity,
    });

    let orderCount = 0;

    for await (const line of rl) {
      try {
        const order = JSON.parse(line);
        console.log("Order: ", order);
        // Handle order here
        orderCount++;

        if (orderCount % 1000 === 0) {
          console.log(`Processed ${orderCount} orders`);
        }
      } catch (error) {
        console.error("Error processing order:", error);
      }
    }

    reader.releaseLock();

    console.log(`Finished processing. Total orders processed: ${orderCount}`);
  } catch (error) {
    console.error("Error in shopifySyncBulkOrders:", error);
  }
};
