import type { WeightUnit } from "@prisma/client";
import db from "../../../lib/db";
import { Shopify } from "../../../lib/shopify";

export const shopifySyncShopData = async (shopId: string) => {
  try {
    const shopify = await Shopify(shopId);

    const shopData = await shopify.shop.get();

    await db.shop.update({
      where: { id: shopId },
      data: {
        shopifyId: shopData.id.toString(),
        isTaxesIncluded: shopData.taxes_included ? true : false,
        shopifyPlan: shopData.plan_name,
        countryCode: shopData.country_code,
        weightUnit: shopData.weight_unit as WeightUnit,
        currency: shopData.currency,
        currencyPrefix: shopData.money_with_currency_format,
        name: shopData.name,
        shopBilling: {
          upsert: {
            create: {
              city: shopData.city,
              country: shopData.country,
              email: shopData.email,
              phone: shopData.phone,
              province: shopData.province,
              zip: shopData.zip,
              street1: shopData.address1,
              street2: shopData.address2,
            },
            update: {},
          },
        },
      },
    });
  } catch (error) {
    console.error(error);
  }
};
