export const shopifySyncBulkProducts = async (url: string) => {
  try {
  } catch (error) {
    console.error(error);
  }
};
