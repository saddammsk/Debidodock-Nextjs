import Shopify from "shopify-api-node";
import db from "../../../lib/db";
import { env } from "../../../types/env";

export const shopifySyncLocationsData = async (shopId: string) => {
  try {
  } catch (error) {
    console.error(error);
  }
};
