import { Shopify } from "../../lib/shopify";
import { env } from "../../types/env";

export const handleSubscribeShopifyWebhooks = async (shopId: string) => {
  try {
    const shopify = await Shopify(shopId);

    console.log("SERVER URL:", env.SERVER_URL);

    console.log("Starting subscribing to webhooks");
    await Promise.all([
      /* APP UNINSTALLED */
      shopify.webhook.create({
        topic: "app/uninstalled",
        address: `${env.SERVER_URL}/shopify/webhooks/uninstall`,
        format: "json",
      }),

      /* BULK OPERATIONS */
      shopify.webhook.create({
        topic: "bulk_operations/finish",
        address: `${env.SERVER_URL}/shopify/webhooks/bulk-operation-finish`,
        format: "json",
      }),

      ////////////////////////////
      /* ORDERS */
      ////////////////////////////

      /* ORDER CREATE */
      shopify.webhook.create({
        topic: "orders/create",
        address: `${env.SERVER_URL}/shopify/webhooks/order-created`,
        format: "json",
      }),

      /* ORDER FULFILLED */

      shopify.webhook.create({
        topic: "orders/fulfilled",
        address: `${env.SERVER_URL}/shopify/webhooks/order-fulfilled`,
        format: "json",
      }),

      /* ORDER UPDATED */

      shopify.webhook.create({
        topic: "orders/updated",
        address: `${env.SERVER_URL}/shopify/webhooks/order-updated`,
        format: "json",
      }),

      /* ORDER DELETED */

      shopify.webhook.create({
        topic: "orders/delete",
        address: `${env.SERVER_URL}/shopify/webhooks/order-deleted`,
        format: "json",
      }),

      /* ORDER CANCELED */
      shopify.webhook.create({
        topic: "orders/cancelled",
        address: `${env.SERVER_URL}/shopify/webhooks/order-cancelled`,
        format: "json",
      }),

      /* REFUND CREATED */

      shopify.webhook.create({
        topic: "refunds/create",
        address: `${env.SERVER_URL}/shopify/webhooks/refund-created`,
        format: "json",
      }),

      ////////////////////////////
      /* PRODUCTS */
      ////////////////////////////

      /* PRODUCT CREATED */

      shopify.webhook.create({
        topic: "products/create",
        address: `${env.SERVER_URL}/shopify/webhooks/product-created`,
        format: "json",
      }),

      /* PRODUCT UPDATED */

      shopify.webhook.create({
        topic: "products/update",
        address: `${env.SERVER_URL}/shopify/webhooks/product-updated`,
        format: "json",
      }),

      /* PRODUCT DELETED */

      shopify.webhook.create({
        topic: "products/delete",
        address: `${env.SERVER_URL}/shopify/webhooks/product-deleted`,
        format: "json",
      }),

      ////////////////////////////
      /* INVENTORY LEVELS */
      ////////////////////////////

      /* INVENTORY LEVEL UPDATED */
      shopify.webhook.create({
        topic: "inventory_levels/update",
        address: `${env.SERVER_URL}/shopify/webhooks/inventory-level-updated`,
        format: "json",
      }),

      /* INVENTORY LEVEL CONNECTED */
      shopify.webhook.create({
        topic: "inventory_levels/connect",
        address: `${env.SERVER_URL}/shopify/webhooks/inventory-level-connected`,
        format: "json",
      }),

      /* INVENTORY LEVEL DISCONNECTED */
      shopify.webhook.create({
        topic: "inventory_levels/disconnect",
        address: `${env.SERVER_URL}/shopify/webhooks/inventory-level-disconnected`,
        format: "json",
      }),

      ////////////////////////////
      /* INVENTORY ITEMS */
      ////////////////////////////

      /* INVENTORY ITEM UPDATED */
      shopify.webhook.create({
        topic: "inventory_items/update",
        address: `${env.SERVER_URL}/shopify/webhooks/inventory-item-updated`,
        format: "json",
      }),

      /* INVENTORY ITEM CREATED */
      shopify.webhook.create({
        topic: "inventory_items/create",
        address: `${env.SERVER_URL}/shopify/webhooks/inventory-item-created`,
        format: "json",
      }),

      /* INVENTORY ITEM DELETED */
      shopify.webhook.create({
        topic: "inventory_items/delete",
        address: `${env.SERVER_URL}/shopify/webhooks/inventory-item-deleted`,
        format: "json",
      }),

      ////////////////////////////
      /* LOCATION */
      ////////////////////////////

      /* LOCATION CREATED */
      shopify.webhook.create({
        topic: "locations/create",
        address: `${env.SERVER_URL}/shopify/webhooks/location-created`,
        format: "json",
      }),

      /* LOCATION ACTIVATED */
      shopify.webhook.create({
        topic: "locations/activate",
        address: `${env.SERVER_URL}/shopify/webhooks/location-activated`,
        format: "json",
      }),

      /* LOCATION DEACTIVATED */
      shopify.webhook.create({
        topic: "locations/deactivate",
        address: `${env.SERVER_URL}/shopify/webhooks/location-deactivated`,
        format: "json",
      }),

      /* LOCATION DELETED */
      shopify.webhook.create({
        topic: "locations/delete",
        address: `${env.SERVER_URL}/shopify/webhooks/location-deleted`,
        format: "json",
      }),

      /* LOCATION UPDATED */
      shopify.webhook.create({
        topic: "locations/update",
        address: `${env.SERVER_URL}/shopify/webhooks/location-updated`,
        format: "json",
      }),
    ]);

    console.log("Subscribed to webhooks");
  } catch (error) {
    console.error(error);
  }
};
