import { shopifyOrdersQuery } from "../../../config/shopify-queries/shopify-orders-query";
import db from "../../../lib/db";
import { Shopify } from "../../../lib/shopify";
import { createBulkOperationResponseSchema } from "../../../schema/shopify-schema";

export const shopifyBulkQueryOrdersInit = async (shopId: string) => {
  try {
    const shopify = await Shopify(shopId);

    const query = `
      mutation {
        bulkOperationRunQuery(
          query: """
            {
              ${shopifyOrdersQuery}
            }
          """
        ) {
          bulkOperation {
            id
            status
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

    const response = await shopify.graphql(query);

    console.dir(response, { depth: null });

    const parsedResponse = createBulkOperationResponseSchema.parse(response);

    await db.shopifyBulkOperation.create({
      data: {
        operationId: parsedResponse.bulkOperationRunQuery.bulkOperation.id,
        topic: "ORDERS",
        shopId: shopId,
        status: parsedResponse.bulkOperationRunQuery.bulkOperation.status,
      },
    });

    await db.shop.update({
      where: { id: shopId },
      data: {
        hasBulkOperationRunning: true,
      },
    });
  } catch (error) {
    console.error(error);
  }
};
