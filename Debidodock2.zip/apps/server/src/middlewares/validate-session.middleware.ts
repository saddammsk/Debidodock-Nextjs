import { createMiddleware } from "hono/factory";
import { getCookie } from "hono/cookie";
import { parseSessionToken } from "../handlers/sessions/parseSessionToken.handler";
import { parseIntermediateToken } from "../handlers/sessions/parseIntermediateToken.handler";

export const validateSession = createMiddleware(async (c, next) => {
  try {
    console.log("Validating session...");
    const sessionToken = getCookie(c, "sessionToken");

    // If there is no session token, check for an intermediate token
    if (sessionToken) {
      const sessionTokenData = await parseSessionToken(sessionToken);
      if (!sessionTokenData) {
        console.log("Session token data not found");
        return c.json({ error: "Unauthorized" }, 401);
      }

      c.set("userWorkOSId", sessionTokenData.userWorkOSId);
      c.set("memberWorkOSId", sessionTokenData.memberWorkOSId);
      c.set("role", sessionTokenData.role);
      c.set("orgWorkOSId", sessionTokenData.orgWorkOSId);
    } else {
      console.log("No session token found, checking for intermediate token");
      const intermediateToken = getCookie(c, "intermediateToken");

      if (!intermediateToken) {
        console.log("No intermediate token found in cookies");
        return c.json({ error: "Unauthorized" }, 401);
      }

      const userId = await parseIntermediateToken(intermediateToken);

      if (!userId) {
        console.log("Intermediate token found, but not in redis");
        return c.json({ error: "Unauthorized" }, 401);
      }

      c.set("userWorkOSId", userId);
    }

    console.log("Session validated, continuing...");

    await next();
  } catch (error) {
    console.log("Error validating session: ", error);
    return c.json({ error: "Unauthorized" }, 401);
  }
});
