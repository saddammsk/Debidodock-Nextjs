import type { Context, Next } from "hono";
import crypto from "crypto";
import { env } from "../types/env";

export const validateShopifyWebhook = async (c: Context, next: Next) => {
  const shopifyUrl = c.req.header("x-shopify-shop-domain");
  const hmac = c.req.header("x-shopify-hmac-sha256");
  const topic = c.req.header("x-shopify-topic");
  const rawBody = await c.req.raw.text();

  const hash = crypto
    .createHmac("sha256", env.SHOPIFY_CLIENT_SECRET)
    .update(rawBody)
    .digest("base64");

  if (hash !== hmac) {
    console.log(shopifyUrl, ": Unauthorized, invalid webhook hmac");
    return c.json("Unauthorized", 401);
  }

  console.log(
    shopifyUrl,
    `: ${topic} webhook received and validated`,
    "hmac: ",
    hmac,
    "topic: ",
    topic
  );

  c.set("shopifyUrl", shopifyUrl);
  c.set("body", JSON.parse(rawBody));

  return await next();
};
