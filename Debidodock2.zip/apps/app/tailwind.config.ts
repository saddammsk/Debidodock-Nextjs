import baseConfig from "@debido/ui/tailwind.config";
import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{ts,tsx}", "../../packages/ui/src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        black1: "#111111",
        black2: "#151515",
        black3: "#181818",
        black4: "#111111e6",
        gray1: "#F6F6F6",
        gray2: "#B3B3B3",
        gray3: "#262626",
        gray4: "#232323",
        gray5: "#2D2D2D",
        gray6: "#1A1A1A",
        gray7: "#292929",
        gray8: "#FFFFFFD9",
        gray9: "#1B1B1B",
        gray10: "#1c1c1c",
        white: "#FFFFFF",
        yellow1: "#FFAE11",
        blue1: "#3E97FF",
        blue2: "#1E59FF",
        blue3: "#1E59FF0D",
        blue4: "#1E59FF33",
        blue5: "#4072FF",
        blue6: "#1F5AFE",
        blue7: "#1877F2",
        green1: "#48CC93",
        green2: "#48CC931A",
        red1: "#FD5858",
      },
      boxShadow: {
        none: "none",
      },
      screens: {
        "xs": "320px",
        "xsm": "375px",
        "sm": "540px",
        "md": "768px",
        "lg": "1024px",
        "xl": "1280px",
        "2xl": "1440px",
        "3xl": "1920px",
      },

      fontFamily: {
        inter: "var(--font-inter)",
      },
      fontSize: {
        "3xll": ["32px", "40px"],
      },
    },
  },
  plugins: [
    function ({ addUtilities }) {
      addUtilities({
        '.no-spin-buttons': {
          '-webkit-appearance': 'none',
          '-moz-appearance': 'textfield',
          'margin': '0',
        },
      });
    },
  ],
  presets: [baseConfig],
} satisfies Config;
