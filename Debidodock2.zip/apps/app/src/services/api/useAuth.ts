import { redirect } from "@tanstack/react-router";
import { hcClient } from "../../lib/hc";
import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";

type LoginWithOAuthProps = {
  provider: "GoogleOAuth" | "GitHubOAuth" | "MicrosoftOAuth" | "AppleOAuth";
  redirectAfterAuth?: string;
};

export const useAuth = () => {
  // States
  const [shopSelectionLoading, setShopSelectionLoading] = useState(false);

  const navigate = useNavigate();

  // Check if the user is authenticated
  const checkAuth = async () => {
    try {
      const res = await hcClient.auth.$get();
      if (res.ok) {
        return await res.json();
      } else if (res.status === 401) {
        return navigate({
          to: "/login",
        });
      }
    } catch (error) {
      return navigate({
        to: "/auth/error",
      });
    }
  };

  // If the user has more than one organization, they need to select one to login
  const shopSelectionLogin = async (organizationId: string) => {
    try {
      setShopSelectionLoading(true);
      const res = await hcClient.auth["shop-selection-login"].$post({
        json: {
          orgWorkOSId: organizationId,
        },
      });

      if (res.ok) {
        setShopSelectionLoading(false);
        navigate({ to: "/inbox" });
      }
    } catch (error) {
      setShopSelectionLoading(false);
      navigate({
        to: "/auth/error",
        search: { message: "Could not login with shop" },
      });
    }
  };

  const loginWithOAuth = async ({
    provider,
    redirectAfterAuth,
  }: LoginWithOAuthProps) => {
    try {
      const res = await hcClient.auth.login.$post({
        json: {
          provider,
          redirectAfterAuth,
        },
      });
      if (res.ok) {
        const data = await res.json();
        window.location.href = data.redirectUrl;
      }
    } catch (error) {
      return navigate({
        to: "/auth/error",
        search: {
          message: `Could not login with ${provider}, please try again or contact support`,
        },
      });
    }
  };

  // Handle logout
  const logout = async () => {
    try {
      const res = await hcClient.auth.logout.$post();

      if (res.ok) {
        return navigate({
          to: "/login",
        });
      }
    } catch (error) {
      return navigate({
        to: "/auth/error",
        search: {
          message: `Could not logout, please try again or contact support`,
        },
      });
    }
  };

  const handleVerifyEmail = async (
    code: string,
    redirectAfterAuth?: string
  ) => {
    if (code.length !== 6) return;
    try {
      const res = await hcClient.auth["verify-email"].$post({
        json: {
          code,
          redirectAfterAuth,
        },
      });

      if (res.ok) {
        const data = await res.json();
        if (data.redirectType === "url") {
          return (window.location.href = data.redirectTo);
        } else {
          return redirect({
            to: data.redirectTo,
            search: { organizations: data.organizations },
          });
        }
      }
    } catch (error) {
      return navigate({
        to: "/auth/error",
        search: {
          message: `Could not verify email, please try again or contact support`,
        },
      });
    }
  };

  return {
    checkAuth,
    shopSelectionLogin,
    shopSelectionLoading,
    loginWithOAuth,
    logout,
    handleVerifyEmail,
  };
};
