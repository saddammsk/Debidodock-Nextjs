import { type AppType } from "@debido/server/index";
import { hc } from "hono/client";
import { env } from "../types/env";

export const hcClient = hc<AppType>(env.VITE_SERVER_URL + "/", {
  init: {
    credentials: "include",
  },
});
