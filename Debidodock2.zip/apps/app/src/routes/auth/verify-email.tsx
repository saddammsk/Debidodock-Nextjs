import { buttonVariants } from "@debido/ui/components/button";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSeparator,
  InputOTPSlot,
} from "@debido/ui/components/input-otp";
import { cn } from "@debido/ui/lib/utils";
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { useAuth } from "../../services/api/useAuth";

const searchSchema = z.object({
  redirectAfterAuth: z.string().optional(),
});

export const Route = createFileRoute("/auth/verify-email")({
  validateSearch: searchSchema,
  component: VerifyCode,
});

function VerifyCode() {
  const { redirectAfterAuth } = Route.useSearch();

  const { handleVerifyEmail } = useAuth();

  return (
    <main className="h-screen w-full flex items-center justify-center p-4">
      <div className="max-w-[430px] flex flex-col items-center justify-center w-full gap-8">
        {/* HEADER */}
        <div className="w-full flex flex-col justify-center items-center">
          <h1 className="text-3xl font-medium">Verify your email</h1>
          <p className="text-base text-muted mt-2">
            We sent you a verification code to your email address
          </p>
        </div>

        {/* INPUT */}
        <InputOTP
          maxLength={6}
          onChange={async (code) =>
            await handleVerifyEmail(code, redirectAfterAuth)
          }
        >
          <InputOTPGroup>
            <InputOTPSlot index={0} />
            <InputOTPSlot index={1} />
            <InputOTPSlot index={2} />
          </InputOTPGroup>
          <InputOTPSeparator />
          <InputOTPGroup>
            <InputOTPSlot index={3} />
            <InputOTPSlot index={4} />
            <InputOTPSlot index={5} />
          </InputOTPGroup>
        </InputOTP>

        <hr className="w-full max-w-[376px]" />

        <div className="w-full max-w-[376px] flex space-x-2">
          <a
            href="https://mail.google.com/mail/u/0/#search/welcome@workos.dev"
            target="_blank"
            className={cn(
              buttonVariants({ variant: "secondary" }),
              "w-full h-12"
            )}
          >
            <img src="/gmail.svg" alt="Google Logo" className="w-6 h-6 mr-2" />
            Gmail
          </a>
          <a
            href="https://outlook.live.com/mail/search?q=welcome@workos.dev"
            target="_blank"
            className={cn(
              buttonVariants({ variant: "secondary" }),
              "w-full h-12"
            )}
          >
            <img
              src="/outlook.svg"
              alt="Outlook Logo"
              className="w-6 h-6 mr-2"
            />
            Outlook
          </a>
        </div>
      </div>
    </main>
  );
}
