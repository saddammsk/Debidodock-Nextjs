import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const searchSchema = z.object({
  message: z.string().optional(),
});

export const Route = createFileRoute("/auth/error")({
  validateSearch: searchSchema,
  component: AuthError,
});

function AuthError() {
  const { message } = Route.useSearch();
  return (
    <main className="h-screen w-full flex items-center justify-center">
      Woops, something went wrong: {message}
    </main>
  );
}
