import { createFileRoute, redirect } from "@tanstack/react-router";
import { z } from "zod";
import { hcClient } from "../../lib/hc";

const searchSchema = z.object({
  code: z.string(),
  state: z.string().optional(),
});

export const Route = createFileRoute("/auth/callback")({
  validateSearch: searchSchema,
  beforeLoad: async ({ search }) => {
    const res = await hcClient.auth.callback.$get({
      query: {
        code: search.code,
        state: search.state,
      },
    });

    if (res.ok) {
      const data = await res.json();

      console.log("Redirect data: ");
      console.log(data);

      if (data) {
        if (data.redirectType === "url") {
          window.location.href = data.redirectTo;
        } else {
          redirect({
            to: data.redirectTo,
            search: { organizations: data.organizations },
            throw: true,
          });
        }
      }
    }
  },
  component: () => <div>Hello /auth/callback!</div>,
});
