import { Button } from "@debido/ui/components/button";
import { CaretRight } from "@phosphor-icons/react";
import { createFileRoute, redirect } from "@tanstack/react-router";
import { z } from "zod";
import { useAuth } from "../../services/api/useAuth";

const searchSchema = z.object({
  organizations: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
    })
  ),
});

export const Route = createFileRoute("/auth/choose-shop")({
  validateSearch: searchSchema,
  beforeLoad: async ({ search }) => {
    if (!search.organizations || search.organizations.length === 0) {
      throw redirect({
        to: "/auth/error",
      });
    } else {
      console.log(search.organizations);
    }
  },
  component: ChooseShop,
});

function ChooseShop() {
  const { organizations } = Route.useSearch();
  const { shopSelectionLogin, shopSelectionLoading } = useAuth();
  return (
    <main className="h-screen w-full flex items-center justify-center p-4">
      <div className="max-w-[430px] w-full">
        {/* HEADER */}
        <div className="w-full flex flex-col justify-center items-center">
          <h1 className="text-3xl font-semibold">Choose shop to login</h1>
          <p className="text-base text-muted mt-2">
            Choose the shop you want to login to
          </p>
        </div>

        {/* ORGANIZATIONS */}
        <div className="mt-8 flex flex-col gap-1.5">
          {organizations.map((organization) => (
            <Button
              disabled={shopSelectionLoading}
              onClick={async () => await shopSelectionLogin(organization.id)}
              key={organization.id}
              className="w-full justify-start text-base pl-6 pr-5 h-12"
              variant="secondary"
            >
              <img
                className="size-7 mr-3"
                src="/shopify.svg"
                alt={`Login with ${organization.name}`}
              />
              {organization.name}
              <CaretRight
                size={16}
                weight="bold"
                className="text-muted ml-auto"
              />
            </Button>
          ))}
        </div>
      </div>
    </main>
  );
}
