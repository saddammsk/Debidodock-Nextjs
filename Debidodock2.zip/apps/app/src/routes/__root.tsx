import { createRootRoute, Outlet, useLocation } from "@tanstack/react-router";
import MainNavMenu from "../components/nav-menu/NavMenu";
import { useGlobalContext } from "../context/GlobalContext";
import SettingsSidebar from "../components/common/SettingsSidebar";

export const Route = createRootRoute({
  component: () => {
    const { toggleSidebar, setToggleSidebar } = useGlobalContext();
    const pathName = useLocation();
    const isSettingsPath = pathName.pathname.startsWith("/settings");

    return (
      <div className="flex">
        {toggleSidebar && (
        <div
          onClick={() => setToggleSidebar(false)}
          className={
            `${toggleSidebar ? "block" : "hidden"}` +
            " lg:hidden z-10 w-full absolute h-screen top-0 opacity-50 bg-black1"
          }
        ></div>
      )}
        <div className={ `${toggleSidebar ? "block" : "hidden"}` + " lg:block w-[222px] bg-black1 left-0 z-50 h-screen fixed pt-3 px-2 pb-8 top-0"}>
          {!isSettingsPath ? (
              <nav className="">
                <MainNavMenu />
              </nav>
          ) : (
            <>
              <aside
                className={`${
                  toggleSidebar ? "block" : "hidden"
                } lg:block transition-all duration-300 lg:static absolute z-50 lg:bg-transparent bg-black1 lg:border-none border border-gray4`}
              >
                <SettingsSidebar />
              </aside>
            </>
          )}
        </div>
        <main className="lg:w-[calc(100%_-_222px)] w-full ml-auto">
          <Outlet />
        </main>
      </div>
    );
  },
});
