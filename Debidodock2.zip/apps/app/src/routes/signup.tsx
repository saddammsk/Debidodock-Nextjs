import { Button } from "@debido/ui/components/button";
import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { useTheme } from "../hooks/useTheme";
import { useAuth } from "../services/api/useAuth";

const searchSchema = z.object({
  redirectAfterAuth: z.string().optional(),
});

export const Route = createFileRoute("/signup")({
  component: Signup,
  validateSearch: searchSchema,
});

function Signup() {
  const { resolvedTheme } = useTheme();
  const { redirectAfterAuth } = Route.useSearch();
  const { loginWithOAuth } = useAuth();

  return (
    <main className="h-screen w-full flex items-center justify-center p-4">
      <div className="max-w-[430px] w-full">
        {/* HEADER */}
        <div className="w-full flex flex-col justify-center items-center">
          <h1 className="text-3xl font-semibold">Welcome to Debido</h1>
          <p className="text-base text-muted mt-2">
            Sign up to start your journey
          </p>
        </div>

        {/* SIGNIN OPTIONS */}
        <div className="mt-8 flex flex-col gap-1.5">
          <Button
            onClick={async () =>
              await loginWithOAuth({
                provider: "GoogleOAuth",
                redirectAfterAuth,
              })
            }
            className="w-full h-11"
            variant="secondary"
          >
            <img
              className="size-6 mr-3"
              src="/google.svg"
              alt="Login with Google"
            />
            Sign up with Google
          </Button>
          <Button
            onClick={async () =>
              await loginWithOAuth({
                provider: "GitHubOAuth",
                redirectAfterAuth,
              })
            }
            className="w-full h-11"
            variant="secondary"
          >
            <img
              className="size-6 mr-3"
              src={
                resolvedTheme === "light"
                  ? "/github-light.svg"
                  : "/github-dark.svg"
              }
              alt="Login with Github"
            />
            Sign up with Github
          </Button>
        </div>
      </div>
    </main>
  );
}
