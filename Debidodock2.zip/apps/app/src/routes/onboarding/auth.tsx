import { createFileRoute, redirect } from "@tanstack/react-router";
import { hcClient } from "../../lib/hc";
import { z } from "zod";

const searchSchema = z.object({
  secret: z.string(),
});

export const Route = createFileRoute("/onboarding/auth")({
  component: OnboardingAuth,
  validateSearch: searchSchema,
  beforeLoad: async ({ search }) => {
    const secret = search.secret;

    const res = await hcClient.auth["connect-shop-user"].$get({
      query: {
        secret,
      },
    });

    if (res.status === 200) {
      throw redirect({ to: "/onboarding/cost" });
    } else {
      throw redirect({
        to: "/signup",
        search: {
          redirectAfterAuth: `/onboarding/auth?secret=${secret}`,
        },
      });
    }
  },
});

function OnboardingAuth() {
  return <main className="h-screen w-full flex"></main>;
}
