import { createFileRoute, redirect } from "@tanstack/react-router";
import { hcClient } from "../../../lib/hc";

export const Route = createFileRoute("/onboarding/shopify/sync")({
  beforeLoad: async () => {
    try {
      const res = await hcClient.auth.$get();
      if (res.ok) {
        return await res.json();
      } else if (res.status === 401) {
        throw redirect({
          to: "/login",
          search: {
            redirectAfterAuth: "/onboarding/shopify/sync",
          },
        });
      }
    } catch (error) {
      throw redirect({
        to: "/login",
        search: {
          redirectAfterAuth: "/onboarding/shopify/sync",
        },
      });
    }
  },
  component: ShopifySync,
});

function ShopifySync() {
  return (
    <main className="h-screen w-full flex items-center justify-center p-4">
      <div className="max-w-[430px] w-full"></div>
    </main>
  );
}
