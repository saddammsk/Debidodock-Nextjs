import { createRootRoute, Outlet, useLocation } from "@tanstack/react-router";
import SettingsSidebar from "../../components/common/SettingsSidebar";
import { useGlobalContext } from "../../context/GlobalContext";



export const Route = createRootRoute({component: () => {
  const { toggleSidebar, setToggleSidebar } = useGlobalContext();
   const pathName = useLocation();
   const isSettingsPath = pathName.pathname.startsWith("/settings");

  return(
    <div className="flex">
      {!isSettingsPath && (
      <>
        {!toggleSidebar && (
          <div
            onClick={() => setToggleSidebar(true)}
            className="lg:hidden z-10 block w-full absolute left-0 h-screen top-0 opacity-50 bg-black1"
          ></div>
        )}
        <aside
          className={`${
            toggleSidebar ? '-left-full' : 'left-0'
          } md:block transition-all duration-300 md:static absolute z-50 md:bg-transparent bg-black1 md:border-none border border-gray4`}
        >
          <SettingsSidebar/>
        </aside>
          </>
        )}
   
      <main className="w-full">
        <Outlet />
      </main>
    </div>
  
)}});
