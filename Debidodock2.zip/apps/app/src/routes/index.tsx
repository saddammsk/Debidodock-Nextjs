import { Button } from "@debido/ui/components/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@debido/ui/components/select";
import { Switch } from "@debido/ui/components/switch";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from "@debido/ui/components/context-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@debido/ui/components/table";
import { Textarea } from "@debido/ui/components/textarea";
import { Checkbox } from "@debido/ui/components/checkbox";
import DatePicker from "@debido/ui/components/date-picker";
import DateRangePicker from "@debido/ui/components/date-range-picker";
import { Tabs, TabsList, TabsTrigger } from "@debido/ui/components/tabs";
import { Sheet, SheetContent, SheetTrigger } from "@debido/ui/components/sheet";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@debido/ui/components/dialog";
import InputCard from "@debido/ui/components/input-card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuPortal,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@debido/ui/components/dropdown-menu";
import { createFileRoute } from "@tanstack/react-router";
import { useTheme } from "../hooks/useTheme";
import { useState } from "react";
import { toast } from "sonner";
import { DateRange } from "react-day-picker";
import { format } from "date-fns";
import MainNavMenu from "../components/nav-menu/NavMenu";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const { setTheme, theme } = useTheme();
  const [count, setCount] = useState<string | number>(0);
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  return (
    <div className="flex flex-col items-center gap-3 justify-center h-screen">
      <div className="w-[800px]">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Age</TableHead>
              <TableHead>Email</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell>John Doe</TableCell>
              <TableCell>30</TableCell>
              <TableCell>asdasdasdasdsa</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>John Doe</TableCell>
              <TableCell>asdasd</TableCell>
              <TableCell>john@example.com</TableCell>
            </TableRow>
            <TableRow>
              <TableCell>John Doe</TableCell>
              <TableCell>test</TableCell>
              <TableCell>john@example.com</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>

      <Textarea placeholder="asd placeholder" className="w-[400px]" />

      <ContextMenu>
        <ContextMenuTrigger className="flex h-[150px] w-[300px] items-center justify-center rounded-md border border-dashed text-sm">
          Right asd me
        </ContextMenuTrigger>
        <ContextMenuContent>
          <ContextMenuItem>Item 123</ContextMenuItem>
          <ContextMenuItem>Item 123</ContextMenuItem>
          <ContextMenuItem>Item 123</ContextMenuItem>
          <ContextMenuItem>Item 123</ContextMenuItem>
        </ContextMenuContent>
      </ContextMenu>

      <Button
        variant="secondary"
        onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      >
        {theme === "dark" ? "Light" : "Dark"}
      </Button>

      <DatePicker date={date} setDate={setDate} disableDatesAfter={new Date()}>
        <Button variant="secondary">Open date picker</Button>
      </DatePicker>

      <DateRangePicker dateRange={dateRange} setDateRange={setDateRange}>
        <Button variant="secondary">
          {dateRange?.from && dateRange?.to
            ? format(dateRange.from, "eee dd. MMM yyyy") +
              " - " +
              format(dateRange.to, "eee dd. MMM yyyy")
            : "Open date range"}
        </Button>
      </DateRangePicker>

      <Button
        onClick={() =>
          toast("Hello world", {
            description: "This is a toast",
            action: {
              label: "Undo",
              onClick: () => toast.dismiss(),
            },
          })
        }
      >
        Toast
      </Button>

      <Switch />

      <Checkbox />

      <MainNavMenu  />

      <Tabs>
        <TabsList>
          <TabsTrigger value="123">123</TabsTrigger>
          <TabsTrigger value="113">333</TabsTrigger>
          <TabsTrigger value="133">344</TabsTrigger>
        </TabsList>
      </Tabs>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="secondary">Open menu</Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>Sub trigger</DropdownMenuSubTrigger>
            <DropdownMenuPortal>
              <DropdownMenuSubContent>
                <DropdownMenuItem>Sub item 1</DropdownMenuItem>
                <DropdownMenuItem>Sub item 1</DropdownMenuItem>
                <DropdownMenuItem>
                  Sub item 1 <DropdownMenuShortcut>x+y</DropdownMenuShortcut>
                </DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuPortal>
          </DropdownMenuSub>

          <DropdownMenuSeparator />

          <DropdownMenuItem>Item 1</DropdownMenuItem>
          <DropdownMenuItem>Item 2</DropdownMenuItem>

          <DropdownMenuItem>Item 3</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <div className="w-[400px]">
        <Select>
          <SelectTrigger>
            <SelectValue placeholder="Select" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="s">Item 1</SelectItem>
            <SelectItem value="ds">Item 1</SelectItem>
            <SelectItem value="ss">Item 1</SelectItem>
            <SelectItem value="sa">asd 1</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <InputCard
        value={count}
        setValue={setCount}
        incrementBy={2}
        selectList={[
          { value: "s", label: "Item 1" },
          { value: "ds", label: "Item 1" },
          { value: "ss", label: "Item 1" },
          { value: "sa", label: "Item 1" },
        ]}
        className="w-[400px]"
        label="Label"
      />

      <Sheet>
        <SheetTrigger asChild>
          <Button variant="secondary">Open sheet</Button>
        </SheetTrigger>
        <SheetContent>asdasdasd</SheetContent>
      </Sheet>

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="secondary">Open dialog</Button>
        </DialogTrigger>
        <DialogContent>Hello 123</DialogContent>
      </Dialog>
    </div>
  );
}
