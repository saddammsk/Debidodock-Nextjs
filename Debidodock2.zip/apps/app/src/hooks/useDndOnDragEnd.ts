/* eslint-disable @typescript-eslint/no-explicit-any */
import {
  DragEndEvent,
  KeyboardSensor,
  MouseSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import { arrayMove } from "@dnd-kit/sortable";

export const useDndOnDragEnd = (setList: any, list: any[]) => {
  const mouseSensor = useSensor(MouseSensor, {
    activationConstraint: {
      distance: 5,
    },
  });

  const keyboardSensor = useSensor(KeyboardSensor);
  const sensors = useSensors(mouseSensor, keyboardSensor);

  const handleDragEnd = (event: DragEndEvent) => {
    const getPosition = (id: string | number) =>
      list.findIndex((board) => board.id === id.toString());

    const { active, over } = event;

    if (!over || active.id === over.id) return;

    setList((list: any[]) => {
      const originalPosition = getPosition(active.id);
      const newPosition = getPosition(over.id);

      return arrayMove(list, originalPosition, newPosition);
    });
  };

  return { handleDragEnd, sensors };
};
