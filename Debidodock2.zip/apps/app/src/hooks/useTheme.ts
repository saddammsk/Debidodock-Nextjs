import { useContext } from "react";
import { Theme, ThemeProviderContext } from "../components/ThemeProvider";

export const useTheme = () => {
  const context = useContext(ThemeProviderContext);

  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }

  // Method to determine the actual theme based on the context's theme state
  const getResolvedTheme = (): Theme => {
    // Check if the theme is set to 'system' and resolve it based on the system preference
    if (context.theme === "system") {
      return window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light";
    }
    // Otherwise, return the theme as is
    return context.theme;
  };

  // Return the theme context along with the resolvedTheme method
  return {
    ...context,
    resolvedTheme: getResolvedTheme(),
  };
};
