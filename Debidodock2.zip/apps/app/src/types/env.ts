import { z } from "zod";

const envSchema = z.object({
  VITE_NODE_ENV: z.enum(["development", "production", "test"], {
    required_error: "NODE_ENV is required",
  }),
  VITE_SERVER_URL: z.string({
    required_error: "SERVER_URL is required",
  }),
  VITE_CLIENT_URL: z.string({
    required_error: "CLIENT_URL is required",
  }),
});

export const env = envSchema.parse(import.meta.env);
