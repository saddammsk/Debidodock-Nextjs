import React, { createContext, useContext, useState, ReactNode } from "react";

interface GlobalContextState {
  showPopup: boolean;
  setShowPopup: (showPopup: boolean) => void;
  EditMode: boolean;
  setEditMode: (EditMode: boolean) => void;
  toggleSidebar: boolean;
  setToggleSidebar: (toggleSidebar: boolean) => void;
  toggleEditSidebar: boolean;
  setToggleEditSidebar: (toggleEditSidebar: boolean) => void;
  showImportBankModel: boolean;
  setShowImportBankModel: (setShowImportBankModel: boolean) => void;
  addNewFinance: boolean;
  setAddNewFinance: (addNewFinance: boolean) => void;
  showSettings: boolean;
  setShowSettings: (showSettings: boolean) => void;
  showActiveOrder: boolean;
  setShowActiveOrder: (showActiveOrder: boolean) => void;
  showNestedPopup: boolean;
  setShowNestedPopup: (showNestedPopup: boolean) => void;
  SavedWidgetPopup: boolean;
  setSavedWidgetPopup: (SavedWidgetPopup: boolean) => void;
  isAddedWidget: boolean;
  setIsAddedWidget: (isAddedWidget: boolean) => void;

}

const GlobalContext = createContext<GlobalContextState | null>(null);

export const GlobalContextProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [showPopup, setShowPopup] = useState<boolean>(false);
  const [showNestedPopup, setShowNestedPopup] = useState<boolean>(false);
  const [EditMode, setEditMode] = useState<boolean>(false);
  const [toggleSidebar, setToggleSidebar] = useState<boolean>(false);
  const [toggleEditSidebar, setToggleEditSidebar] = useState<boolean>(false);
  const [showImportBankModel, setShowImportBankModel] = useState<boolean>(false);
  const [addNewFinance, setAddNewFinance] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showActiveOrder, setShowActiveOrder] = useState<boolean>(false);
  const [SavedWidgetPopup, setSavedWidgetPopup] = useState<boolean>(false);
  const [isAddedWidget, setIsAddedWidget] = useState<boolean>(false);

  return (
    <GlobalContext.Provider value={{ 
      showPopup,
      setShowPopup,
      EditMode,
      setEditMode,
      toggleSidebar,
      setToggleSidebar,
      toggleEditSidebar,
      setToggleEditSidebar,
      showImportBankModel,
      setShowImportBankModel,
      addNewFinance,
      setAddNewFinance,
      showSettings,
      setShowSettings,
      showActiveOrder,
      setShowActiveOrder,
      showNestedPopup,
      setShowNestedPopup,
      SavedWidgetPopup,
      setSavedWidgetPopup,
      isAddedWidget,
      setIsAddedWidget

      }}>
      {children}
    </GlobalContext.Provider>
  );
};

export const useGlobalContext = () => {
  const context = useContext(GlobalContext);
  if (!context) {
    throw new Error("useGlobalContext must be used within a GlobalContextProvider");
  }
  return context;
};
