import { useEffect, useState } from "react";
import { AreaChart, Area, ResponsiveContainer } from "recharts";
import { ChartContainer } from "../ui/chart";

interface ChartDataItem {
  [key: string]: number;
}

interface ChartData {
  label: string;
  dataset: ChartDataItem[];
}

interface OverviewChartProps {
  chartData: ChartData;
}

const chartConfig: { [key: string]: { label: string; color: string } } = {
  Revenue: {
    label: "Revenue",
    color: "hsl(var(--chart-1))",
  },
};

export default function OverviewChart({ chartData }: OverviewChartProps) {
  const [data, setData] = useState<ChartDataItem[]>([]);

  useEffect(() => {
    if (chartData && chartData.dataset) {
      setData(chartData.dataset);
    }
  }, [chartData]);

  const config = chartConfig[chartData.label] || { color: "hsl(var(--chart-1))" };

  return (
    <ChartContainer config={chartConfig}>
      <ResponsiveContainer width="100%"  height={150}>
        <AreaChart
          data={data}
          margin={{
            top: 0,
            right: 0,
            left: 0,
            bottom: 0,
          }}
        >
          <defs>
            <linearGradient id={chartData.label} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={config.color} stopOpacity={0.2} />
              <stop offset="60%" stopColor={config.color} stopOpacity={0.05} />
            </linearGradient>
          </defs>
          <Area
            dataKey={chartData.label}
            type="natural"
            fill={`url(#${chartData.label})`}
            fillOpacity={0.4}
            stroke={config.color}
            stackId="a"
          />
        </AreaChart>
      </ResponsiveContainer>
    </ChartContainer>
  );
}
