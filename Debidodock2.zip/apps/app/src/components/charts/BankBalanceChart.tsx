import * as React from "react";
import { Area, AreaChart, XAxis, YAxis, ReferenceDot } from "recharts";
import { Package, HandCoins, DotsThree } from "@phosphor-icons/react";
import { Card, CardContent } from "../ui/card";
import { ChartContainer } from "../ui/chart";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { FadersHorizontal } from "@phosphor-icons/react";
import { ChartTooltip, ChartTooltipContent } from "../ui/chart";

interface Event {
  type: string;
  icon: React.ComponentType<{ size: number; color: string }>;
}

interface ChartData {
  date: string;
  Balance: number;
  events?: Event[];
  icon?: string;
}

interface EventMapping {
  [date: string]: Event[];
}

const chartData: ChartData[] = [
  { date: "2024-07-01", Balance: 222, events: [{ type: "Package", icon: Package, eventName: '📦'}] },
  { date: "2024-07-09", Balance: 2527, events: [{ type: "HandCoins", icon: HandCoins, eventName: '🪙'}] },
  { date: "2024-07-05", Balance: 222, events: [{ type: "HandCoins", icon: Package, eventName: '📦'}] },
  { date: "2024-04-01", Balance: 222, events: [{ type: "HandCoins", icon: Package, eventName: '📦'}] },
  { date: "2024-04-02", Balance: 97 },
  { date: "2024-04-03", Balance: 167, events: [{ type: "HandCoins", icon: Package, eventName: '📦'}] },
  { date: "2024-04-04", Balance: 242 },
  { date: "2024-04-05", Balance: 373 },
  { date: "2024-04-06", Balance: 301 },
  { date: "2024-04-07", Balance: 245 },
  { date: "2024-04-08", Balance: 409 },
  { date: "2024-04-09", Balance: 59 },
  { date: "2024-04-10", Balance: 261 },
  { date: "2024-04-11", Balance: 327 },
  { date: "2024-04-12", Balance: 292 },
  { date: "2024-04-13", Balance: 342 },
  { date: "2024-04-14", Balance: 137 },
  { date: "2024-04-15", Balance: 120 },
  { date: "2024-04-16", Balance: 138 },
  { date: "2024-04-17", Balance: 446 },
  { date: "2024-04-18", Balance: 364 },
  { date: "2024-04-19", Balance: 243 },
  { date: "2024-04-20", Balance: 89 },
  { date: "2024-04-21", Balance: 137 },
  { date: "2024-04-22", Balance: 224 },
  { date: "2024-04-23", Balance: 138 },
  { date: "2024-04-24", Balance: 387 },
  { date: "2024-04-25", Balance: 215 },
  { date: "2024-04-26", Balance: 75 },
  { date: "2024-04-27", Balance: 383 },
  { date: "2024-04-28", Balance: 122 },
  { date: "2024-04-29", Balance: 315 },
  { date: "2024-04-30", Balance: 4540 },
];

const eventMapping: EventMapping = chartData.reduce((acc, item) => {
  if (item.events) {
    item.events.forEach((event) => {
      acc[item.date] = acc[item.date] || [];
      acc[item.date].push(event);
    });
  }
  return acc;
}, {} as EventMapping);

const chartConfig = {
  Balance: {
    label: "Balance",
    color: "hsl(var(--chart-1))",
  },
};

export function BankBalanceChart() {
  const [timeRange, setTimeRange] = React.useState<string>("30d");

  const filterDataByTimeRange = (data: ChartData[], range: string): ChartData[] => {
    const referenceDate = new Date("2024-06-30");
    const daysMap: { [key: string]: number } = { "30d": 30, "90d": 90, "7d": 7 };
    const startDate = new Date(referenceDate);
    startDate.setDate(startDate.getDate() - daysMap[range]);
    return data.filter((item) => new Date(item.date) >= startDate);
  };

  const filteredData = filterDataByTimeRange(chartData, timeRange);

  return (
    <div className="w-full my-3 max-h-[618px]">
   
    <Card className="bg-black2">
    <div className="w-full bg-black3 flex items-center justify-between gap-6 px-3 py-2.5 border-b border-gray4">
          <div className="text-sm text-gray2 flex items-center gap-2 font-medium ">
            <p>Bank Balance</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-6 h-6"></div>
          </div>
        </div>
      <div className="flex items-center justify-end gap-2 py-4 pb-7 px-4">
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="min-w-[78px] gap-2 h-8 px-2 border border-gray5 bg-gray3 text-xs w-fit rounded-lg focus:ring-0">
            <SelectValue placeholder="Display" />
            <FadersHorizontal size={16} />
          </SelectTrigger>
          <SelectContent className="rounded-xl bg-black1">
            <SelectItem value="30d" className="rounded-lg">Last 30 days</SelectItem>
            <SelectItem value="90d" className="rounded-lg">Last 3 months</SelectItem>
            <SelectItem value="7d" className="rounded-lg">Last 7 days</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <CardContent className="pb-0 !px-0">
      <ChartContainer config={chartConfig} className="aspect-auto md:h-[469px] h-[300px] w-full">
      <AreaChart data={filteredData}>
        <defs>
          <linearGradient id="fillBalance" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-Balance)" stopOpacity={0.2} />
            <stop offset="60%" stopColor="var(--color-Balance)" stopOpacity={0.05} />
          </linearGradient>
        </defs>
        <XAxis
          dataKey="date"
          axisLine={false}
          tickLine={true}
          tickMargin={6}
          textAnchor="middle"
          fontSize={10}
          orientation="bottom"
          tickFormatter={(value) =>
            new Date(value).toLocaleDateString("en-US", { month: "short", day: "numeric" })
          }
          padding={{ left: 0, right: 20 }} 
        />
        <YAxis
          dataKey="Balance"
          axisLine={false}
          tickLine={false}
          tickMargin={25}
          tickFormatter={(value) => (value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value)}
        />
        <ChartTooltip
          content={
            <ChartTooltipContent
              labelFormatter={(value) =>
                new Date(value).toLocaleDateString("en-US", { month: "short", day: "numeric" })
              }
              indicator="dot"
            />
          }
        />
        <Area dataKey="Balance" type="natural" fill="url(#fillBalance)" stroke="var(--color-Balance)" stackId="a" />

        {filteredData.map((entry, index) => {
          if (eventMapping[entry.date]) {
            return eventMapping[entry.date].map((event, eventIndex) => {
              const {eventName} = event;
              return (
                <React.Fragment key={`event-${index}-${eventIndex}`}>
                  <ReferenceDot
                    x={entry.date}
                    y={entry.Balance}
                    r={16}
                    fill="var(--blue-2)"
                    strokeWidth={0}
                    label={eventName}
                  />
                </React.Fragment>
              );
            });
          }
          return null;
        })}
      </AreaChart>
      </ChartContainer>
      </CardContent>
    </Card>
    </div>
  );
}
