import { FixedSizeList as List } from "react-window";
import { format, addDays, startOfDay, isWithinInterval } from "date-fns";
import { Factory, Truck, Garage } from "@phosphor-icons/react";
import { useState, useRef, useEffect } from "react";
import { useDrag } from "react-use-gesture";

const CalendarChart = () => {
  const today = new Date();
  const startDate = addDays(today, -15);
  const highlightedDate = startOfDay(today); // Normalize to midnight
  const totalDays = 90; // Total days to render
  const rowHeight = 24; // Row height
  const parentHeight = 246;

  const [scrollOffset, setScrollOffset] = useState(0);
  const [listWidth, setListWidth] = useState(0);
  const [dayWidth, setDayWidth] = useState(0); // Dynamic day width
  const listRef = useRef(null);
  const containerRef = useRef(null);

  const rowData = [
    [
      {
        start: startOfDay(addDays(startDate, 0)),
        end: startOfDay(addDays(startDate, 10)),
        status: "In Production",
        id: "order-001",
      },
      {
        start: startOfDay(addDays(startDate, 5)),
        end: startOfDay(addDays(startDate, 10)),
        status: "In Delivery",
        id: "order-002",
      },
      {
        start: startOfDay(addDays(startDate, 15)),
        end: startOfDay(addDays(startDate, 20)),
        status: "Delivered",
        id: "order-003",
      },
    ],
  ];



  const calculateLeft = (start: Date): number => {
    const diffInDays = Math.floor((startOfDay(start).getTime() - startOfDay(startDate).getTime()) / (1000 * 60 * 60 * 24));
    return diffInDays * dayWidth;
  };

  const calculateWidth = (start: Date, end: Date): number => {
    const diffInDays = Math.floor((startOfDay(end).getTime() - startOfDay(start).getTime()) / (1000 * 60 * 60 * 24)) + 0.2;
    return diffInDays * dayWidth;
  };

  const handleElementClick = (id:string) => {
    window.location.href = `/purchase-order/${id}`;
  };

  const bind = useDrag(({ offset: [x], last }) => {
    if (listRef.current) {
      const scrollX = Math.max(0, -x);
      listRef.current.scrollTo(scrollX);
      if (last) setScrollOffset(scrollX);
    }
  });

  const Row = ({ index, style }) => {
    if (index === 0) {
      return (
        <div
          style={{
            ...style,
            display: "flex",
            position: "relative",
            alignItems: "center",
            gap: `60.6px`,
            height: rowHeight + 10,
            marginBottom: "20px",
          }}
        >
          {Array.from({ length: totalDays }).map((_, i) => {
            const currentDate = startOfDay(addDays(startDate, i)); 

            return (
              <div
                key={i}
                style={{
                  width: dayWidth,
                  textAlign: "center",
                  fontSize: "10px",
                  padding: "0 4px",
                  color: "#B3B3B3",
                  position: "relative",
                  cursor: "default",
                }}
              >
                {format(currentDate, "MMM dd")}
              </div>
            );
          })}
        </div>
      );
    }

    const rowIndex = index - 1;
    return (
      <div
        style={{
          ...style,
          display: "flex",
          alignItems: "center",
          position: "relative",
          height: rowHeight,
          left: 0,
        }}
      >
        {rowData[rowIndex].map((item, idx) => {
          const isSegmentIntervalled = isWithinInterval(highlightedDate, {
            start: item.start,
            end: item.end,
          });

          return (
            <div
              key={idx}
              style={{
                position: "absolute",
                left: calculateLeft(item.start),
                width: calculateWidth(item.start, item.end),
                height: "100%",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                background: "linear-gradient(90deg, #1E1E1E 0%, #151515 100%)",
                color: isSegmentIntervalled ? "#F6F6F6" : "#B3B3B3",
                borderRadius: "8px",
                padding: "16px 10px",
                fontSize: "12px",
                cursor: "pointer",
              }}
              onClick={() => handleElementClick(item.id)}
            >
              {item.status === "In Production" ? (
                <Factory size={20} />
              ) : item.status === "In Delivery" ? (
                <Truck size={20} />
              ) : (
                <Garage size={20} />
              )}
              {item.status}

              {isSegmentIntervalled && (
                <div
                  style={{
                    position: "absolute",
                    top: -50,
                    left: 0,
                    width: "1px",
                    height: parentHeight,
                    backgroundColor: "#1E59FF",
                    zIndex: 1,
                  }}
                />
              )}
            </div>
          );
        })}
      </div>
    );
  };

  useEffect(() => {
    if (containerRef.current) {
      setListWidth(containerRef.current.offsetWidth);
    }
  }, []);

  useEffect(() => {
    if (listWidth > 0) {
      const totalVisibleDays = (startDate, today) => {
        return Math.floor((today - startDate) / (1000 * 60 * 60 * 24));
      };
      const totalDaysInRange = totalVisibleDays(startDate, today);
      setDayWidth(listWidth / totalDaysInRange);
    }
  }, [listWidth]);

  return (
    <div
      ref={containerRef}
      {...bind()}
      style={{
        overflow: "hidden",
        width: "100%",
      }}
    >
      <List
        className="!overflow-hidden px-2"
        ref={listRef}
        height={parentHeight}
        itemCount={rowData.length + 1}
        itemSize={rowHeight}
        layout="horizontal"
        width={listWidth}
        initialScrollOffset={scrollOffset}
      >
        {Row}
      </List>
    </div>
  );
};

export default CalendarChart;
