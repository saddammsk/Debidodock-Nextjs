"use client";
import * as React from "react";
import { Label, Pie, PieChart } from "recharts";

import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

const chartData = [
  { name: "office", revenue: 200, fill: "var(--yellow-1)" },
  { name: "salary", revenue: 210, fill: "var(--purple-1)" },
  { name: "marketing", revenue: 50, fill: "var(--clay-1)" },
  { name: "etc", revenue: 200, fill: "var(--blue-1)" },
  { name: "etc", revenue: 200, fill: "var(--blue-1)" },
  { name: "etc", revenue: 200, fill: "var(--blue-1)" },
];

const chartConfig = {
  revenue: {
    label: "name",
  },
  data1: {
    label: "data1",
    color: "var(--yellow-1)",
  },
  data2: {
    label: "data2",
    color: "var(--purple-1)",
  },
  data3: {
    label: "data3",
    color: "var(--clay-1)",
  },
  data4: {
    label: "data4",
    color: "var(--blue-1)",
  },
} satisfies ChartConfig;

export function RevenueChart() {
  const [curValue, setcurValue] = React.useState<number | null>();
  const [percentDisplay, setPercentDisplay] = React.useState<string>("");
  const totalValue = chartData.reduce((acc, curr) => acc + curr.revenue, 0);

  React.useEffect(() => {
    const percent = curValue ? Math.round((curValue / totalValue) * 100) : null;
    setPercentDisplay(`${percent}%`);
  }, [curValue]);

  return (
    <div className="w-full font-inter flex justify-center items-center px-10">
      <ChartContainer
        config={chartConfig}
        className="mx-auto w-full aspect-square max-h-[300px] "
      >
        <PieChart>
          <ChartTooltip
            cursor={false}
            content={<ChartTooltipContent hideLabel />}
          />
          <Pie
            className="hover:-translate-y-1 hover:drop-shadow-lg z-10 relative transition-all duration-500 opacity-70 hover:opacity-100 pb-10"
            data={chartData}
            dataKey="revenue"
            nameKey="name"
            innerRadius={75}
            onMouseEnter={({ revenue }) => setcurValue(revenue)}
            onMouseLeave={() => setcurValue(null)}
            stroke="#151515"
            cornerRadius={8}
            strokeWidth={3}
            label={({ name }) => name}
          >
            <Label
              content={({ viewBox }) => {
                if (viewBox && "cx" in viewBox && "cy" in viewBox) {
                  return (
                    <text
                      x={viewBox.cx}
                      y={viewBox.cy}
                      textAnchor="middle"
                      dominantBaseline="middle"
                    >
                      <tspan
                        fill="#fff"
                        x={viewBox.cx}
                        y={viewBox.cy}
                        className="text-3xll font-bold"
                      >
                        {percentDisplay !== "null%" ? percentDisplay : ""}
                      </tspan>
                    </text>
                  );
                }
              }}
            />
          </Pie>
        </PieChart>
      </ChartContainer>
    </div>
  );
}
