import { Button } from '@debido/ui/components/button'
import { ArrowRight, Truck, X } from '@phosphor-icons/react'
import { useState } from 'react'

interface ModelProps{
  setShowPopup: (showPopup: boolean) => void
}

const ShippingEditView = ({setShowPopup}:ModelProps) => {

  const [shippingTabs, setShippingTabs] = useState<string>('weight-base');


  
  return (
    <div className="w-full">
    {/* Head */}
   <div className="flex justify-between items-center">
   <div className="flex items-center gap-2">
       <div className="w-9 h-9 flex items-center justify-center bg-gray3 border border-gray5 rounded">
           <Truck size={20} />
       </div>
   <h2 className="text-white text-sm font-medium">Pakke i postkasse</h2>
   </div>
   <Button className="text-gray2 -mt-3 -mr-2 !bg-transparent shadow-none" onClick={() => setShowPopup(false)}>
   <X size={18} />
   </Button>
    </div>

    {/* Payment */}
    <form>
    <div className="w-full mt-8 md:min-h-[76vh] 3xl:min-h-[82vh]">
    <h3 className='text-xs text-gray2 font-medium mb-2'>Payment due</h3>
    <div className="flex items-center gap-3">
           <select className="bg-gray3 border text-xs text-gray1 font-medium border-gray5 rounded-md w-full h-9 px-3" name="" id="">
               <option selected>Monthly</option>
               <option value="Option 1">Option 1</option>
               <option value="Option 1">Option 2</option>
               <option value="Option 1">Option 3</option>
           </select>
           <span>on</span>
           <select className="bg-gray3 border text-xs text-gray1 font-medium border-gray5 rounded-md w-full h-9 px-3" name="" id="">
               <option selected>2nd</option>
               <option value="Option 1">Option 1</option>
               <option value="Option 1">Option 2</option>
               <option value="Option 1">Option 3</option>
           </select>

    </div>

    <label className="inline-flex items-center relative gap-2 mt-4 mb-6">
       <span className='text-xs text-gray2 font-medium'>Includes VAT</span>
       <div className="flex items-center justify-center relative">
       <input type="checkbox" className="peer h-5 w-9 appearance-none checked:bg-blue2 border transition-all duration-300 border-gray5 bg-gray6 checked:border-blue5 rounded-full p-0.5" name="" id="" value="checkedValue" defaultChecked />
       <span className="w-4 h-4 bg-white rounded-full block absolute left-0.5 peer-checked:translate-x-4 transition-all duration-300"></span>
       </div>
   </label>


   <div className="w-full ">
    <h3 className='text-xs text-gray2 font-medium mb-2'>Shipping prices</h3>

    <div className="w-full grid grid-cols-2 items-center gap-2 bg-black1 border h-8 border-gray4 rounded-md">
       {/* Tab Menu */}
       <Button onClick={(e)=>{e.preventDefault();setShippingTabs('weight-base')}} className={`${shippingTabs === 'weight-base'? 'bg-black2 border-gray5': 'bg-transparent text-gray2 border-transparent'}` + ' !shadow-none hover:shadow-none border hover:border-gray5 text-xs hover:bg-black2 h-8 font-medium'}>
       Weight based
       </Button>
       <Button onClick={(e)=>{e.preventDefault();setShippingTabs('fixed-rate')}} className={`${shippingTabs === 'fixed-rate' ? 'bg-black2 border-gray5' : 'bg-transparent text-gray2 border-transparent'}` + ' !shadow-none hover:shadow-none border hover:border-gray5 text-xs hover:bg-black2 h-8 font-medium'}>
       Fixed rate
       </Button>
    </div>
        {/* Tabs Content */}
        {(shippingTabs === 'weight-base') && 
       <div className="w-full flex sm:flex-row flex-col justify-center items-center gap-[18px] mt-6">
       <div className="w-full grid grid-cols-2 gap-1.5">
           <div className="w-full">
               <h3 className='text-xs text-gray2 font-medium mb-1.5'>From</h3>
               <div className="w-full relative flex items-center mb-1.5">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'  />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                   </select>
               </div>
               <div className="w-full relative flex items-center">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'   />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                   </select>
               </div>

           </div>
           <div className="w-full">
               <h3 className='text-xs text-gray2 font-medium mb-1.5'>To</h3>
               <div className="w-full relative flex items-center mb-1.5">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'  />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                   </select>
               </div>
               <div className="w-full relative flex items-center">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'  />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                   </select>
               </div>

           </div>
       </div>

       <div className="sm:flex hidden items-end gap-6 mt-4 justify-center flex-col">
           <ArrowRight size={20}/>
           <ArrowRight size={20}/>
       </div>

       <div className="w-full grid grid-cols-1 gap-1.5">
           <div className="w-full">
               <h3 className='text-xs text-gray2 font-medium mb-1.5'>Cost</h3>
               <div className="w-full relative flex items-center mb-1.5">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'  />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">NOK</option>
                       <option value="KG">NOK</option>
                       <option value="KG">NOK</option>
                   </select>
               </div>
               <div className="w-full relative flex items-center">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'   />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">NOK</option>
                       <option value="KG">NOK</option>
                       <option value="KG">NOK</option>
                   </select>
               </div>

           </div>
         
       </div>
       </div>}

       {(shippingTabs === 'fixed-rate') && 
       <div className="w-full flex sm:flex-row flex-col justify-center items-center gap-[18px] mt-6">
       <div className="w-full grid grid-cols-2 gap-1.5">
           <div className="w-full">
               <h3 className='text-xs text-gray2 font-medium mb-1.5'>From</h3>
               <div className="w-full relative flex items-center mb-1.5">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'  />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                   </select>
               </div>
               <div className="w-full relative flex items-center">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'   />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                   </select>
               </div>

           </div>
           <div className="w-full">
               <h3 className='text-xs text-gray2 font-medium mb-1.5'>To</h3>
               <div className="w-full relative flex items-center mb-1.5">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'  />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                   </select>
               </div>
               <div className="w-full relative flex items-center">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'  />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                       <option value="KG">KG</option>
                   </select>
               </div>

           </div>
       </div>

       <div className="sm:flex hidden items-end gap-6 mt-4 justify-center flex-col">
           <ArrowRight size={20}/>
           <ArrowRight size={20}/>
       </div>

       <div className="w-full grid grid-cols-1 gap-1.5">
           <div className="w-full">
               <h3 className='text-xs text-gray2 font-medium mb-1.5'>Cost</h3>
               <div className="w-full relative flex items-center mb-1.5">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'  />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">NOK</option>
                       <option value="KG">NOK</option>
                       <option value="KG">NOK</option>
                   </select>
               </div>
               <div className="w-full relative flex items-center">
                   <input type="number" className='bg-gray6 w-full border px-4 py-3 rounded-md text-sm text-gray1 font-medium' placeholder='10'   />
                   <select name="" id="" className='text-xs text-gray2 px-1 font-medium absolute bg-gray6 right-3 '>
                       <option value="KG">NOK</option>
                       <option value="KG">NOK</option>
                       <option value="KG">NOK</option>
                   </select>
               </div>

           </div>
         
       </div>
       

       </div>}


   </div>
    </div>

    
    <Button type='submit' className='h-10 w-full md:mt-auto mt-10'>
    Update
    </Button>
    </form>


    </div>
  )
}

export default ShippingEditView