import { Button } from '@debido/ui/components/button'
import { Factory, X } from '@phosphor-icons/react'

interface ModelProps{
  setShowPopup: (showPopup: boolean) => void
}

const GatewaysEditView = ({setShowPopup}:ModelProps) => {


  
  return (
    <div className="w-full">
    {/* Head */}
   <div className="flex justify-between items-center">
   <div className="flex items-center gap-2">
    <div className="w-9 h-9 flex items-center justify-center bg-gray3 border border-gray5 rounded">
        <Factory size={20} />
    </div>
    <h2 className="text-white text-sm font-medium">Vipps</h2>
   </div>
   <Button className="text-gray2 -mt-3 -mr-2 !bg-transparent shadow-none" onClick={() => setShowPopup(false)}>
   <X size={18} />
   </Button>
    </div>

    <form>
    <div className="w-full flex flex-col mt-8 md:min-h-[83vh] 3xl:min-h-[85vh]">
    <div className="w-full mb-4">
    <div className="w-full flex items-center gap-2.5">
        <div className="w-full">
        <h3 className='text-xs text-gray2 font-medium mb-2'>Percentage fee</h3>
        <label htmlFor="Handling-fee" className='relative flex items-center'>
        <div className="relative flex items-center">
        <input id='lead-time' type="number" className='h-10 w-full text-sm bg-gray6 border border-gray7 py-3 px-4 rounded-md text-gray1 placeholder:text-gray1' placeholder='10' />
            <span className='text-gray2 text-sm absolute right-3 bg-gray6 px-2'>%</span>
        </div>
        </label>
        </div>
        <div className="w-full">
        <h3 className='text-xs text-gray2 font-medium mb-2'>Fixed fee</h3>
        <label htmlFor="lead-time" className='relative flex items-center'>
        <div className="relative flex items-center">
        <input id='lead-time' type="number" className='h-10 w-full text-sm bg-gray6 border border-gray7 py-3 px-4 rounded-md text-gray1 placeholder:text-gray1' placeholder='10' />
            <select name="Fixed-fee" id="Fixed-fee" className='absolute right-2 text-xs bg-gray6 text-gray2'>
                <option value="option1">NOK</option>
                <option value="option1">NOK</option>
                <option value="option1">NOK</option>
                <option value="option1">NOK</option>
            </select>
        </div>
        </label>
        </div>
    </div>

    </div>
    <label className="inline-flex w-fit items-center relative gap-2 mb-6">
    <span className='text-xs text-gray2 font-medium'>Capture when fulfilled</span>
    <div className="flex items-center justify-center relative">
    <input type="checkbox" className="peer h-5 w-9 appearance-none checked:bg-blue2 border transition-all duration-300 border-gray5 bg-gray6 checked:border-blue5 rounded-full p-0.5" name="" id="" value="checkedValue" defaultChecked />
    <span className="w-4 h-4 bg-white rounded-full block absolute left-0.5 peer-checked:translate-x-4 transition-all duration-300"></span>
    </div>
   </label>

   <div className="w-full flex items-center justify-between bg-black1 rounded-lg p-6 border border-gray4">
    <div className="">
        <h3 className='text-sm text-gray1 font-medium mb-1'>Track payouts</h3>
        <p className='text-xs text-gray2 font-medium'>Track your payouts and outstanding balance</p>
    </div>

    <label className="inline-flex items-center relative gap-2">
    <div className="flex items-center justify-center relative">
    <input type="checkbox" className="peer h-5 w-9 appearance-none checked:bg-blue2 border transition-all duration-300 border-gray5 bg-gray6 checked:border-blue5 rounded-full p-0.5" name="" id="" value="checkedValue" defaultChecked />
    <span className="w-4 h-4 bg-white rounded-full block absolute left-0.5 peer-checked:translate-x-4 transition-all duration-300"></span>
    </div>
   </label>

   </div>


    <div className="w-full mt-8 mb-5">
    <h3 className='text-xs text-gray2 font-medium mb-3'>Payout schedule</h3>
    <div className="flex items-center gap-3">
        <select className="bg-gray3 border text-xs text-gray1 font-medium border-gray5 rounded-md w-full h-9 px-3" name="" id="">
            <option selected>Monthly</option>
            <option value="Option 1">Option 1</option>
            <option value="Option 1">Option 2</option>
            <option value="Option 1">Option 3</option>
        </select>
        <span className='text-xs text-gray2'>on</span>
        <select className="bg-gray3 border text-xs text-gray1 font-medium border-gray5 rounded-md w-full h-9 px-3" name="" id="">
            <option selected>2nd</option>
            <option value="Option 1">Option 1</option>
            <option value="Option 1">Option 2</option>
            <option value="Option 1">Option 3</option>
        </select>

    </div>


    <h3 className='text-xs text-gray2 font-medium mb-3 mt-5'>Payout schedule</h3>
    <select className="bg-gray3 border text-xs text-gray1 font-medium border-gray5 rounded-md w-full h-9 px-3" name="" id="">
            <option selected>Monthly</option>
            <option value="Option 1">Option 1</option>
            <option value="Option 1">Option 2</option>
            <option value="Option 1">Option 3</option>
        </select>



    </div>




    <Button type='submit' className='h-10 w-full md:mt-auto mt-10'>
    Update
    </Button>

    </div>
    </form>
    </div>
  )
}

export default GatewaysEditView