import { Button } from '@debido/ui/components/button'
import { Info, MapPin, Plug, Question, X } from '@phosphor-icons/react'

interface ModelProps{
  setShowPopup: (showPopup: boolean) => void
}

const LocationsEditView = ({setShowPopup}:ModelProps) => {


  
  return (
    <div className="w-full">
    {/* Head */}
   <div className="flex justify-between items-center">
   <div className="flex items-center gap-2">
    <div className="w-9 h-9 flex items-center justify-center bg-gray3 border border-gray5 rounded">
        <MapPin size={20} />
    </div>
    <h2 className="text-white text-sm font-medium">Hjelsenglia warehouse</h2>
   </div>
   <Button className="text-gray2 -mt-3 -mr-2 !bg-transparent shadow-none" onClick={() => setShowPopup(false)}>
   <X size={18} />
   </Button>
    </div>

    <form>
    <div className="w-full mt-8">
    <div className="w-full">
    <div className="w-full grid sm:grid-cols-2 grid-cols-1 gap-2.5">
        <div className="w-full">
        <h3 className='text-xs text-gray2 font-medium mb-2'>Payment due</h3>
        <label htmlFor="Handling-fee" className='relative flex items-center'>
        <input id='Handling-fee' type="number" className='h-10 w-full text-sm bg-gray6 border border-gray7 py-3 px-4 rounded-md text-gray1 placeholder:text-gray1' placeholder='10' />
            <span className='text-sm text-gray2 absolute right-1 bg-gray6 p-2'>NOK</span>
        </label>
        </div>
        <div className="w-full">
        <h3 className='text-xs text-gray2 font-medium mb-2'>Handling fee per extra SKU</h3>
        <label htmlFor="Handling-fee" className='relative flex items-center'>
        <input id='Handling-fee' type="number" className='h-10 w-full text-sm bg-gray6 border border-gray7 py-3 px-4 rounded-md text-gray1 placeholder:text-gray1' placeholder='10' />
            <span className='text-sm text-gray2 absolute right-1 bg-gray6 p-2'>NOK</span>
        </label>
        </div>

    </div>
    <label className="inline-flex items-center relative gap-2 mt-4 mb-6">
    <span className='text-xs text-gray2 font-medium'>Includes VAT</span>
    <div className="flex items-center justify-center relative">
    <input type="checkbox" className="peer h-5 w-9 appearance-none checked:bg-blue2 border transition-all duration-300 border-gray5 bg-gray6 checked:border-blue5 rounded-full p-0.5" name="" id="" value="checkedValue" defaultChecked />
    <span className="w-4 h-4 bg-white rounded-full block absolute left-0.5 peer-checked:translate-x-4 transition-all duration-300"></span>
    </div>
   </label>
    </div>

    <div className="w-full">
    <h3 className='text-xs text-gray2 font-medium mb-2'>Payment due</h3>
    <div className="flex items-center gap-3">
           <select className="bg-gray3 border text-xs text-gray1 font-medium border-gray5 rounded-md w-full h-9 px-3" name="" id="">
               <option selected>Monthly</option>
               <option value="Option 1">Option 1</option>
               <option value="Option 1">Option 2</option>
               <option value="Option 1">Option 3</option>
           </select>
           <span className='text-xs text-gray2'>on</span>
           <select className="bg-gray3 border text-xs text-gray1 font-medium border-gray5 rounded-md w-full h-9 px-3" name="" id="">
               <option selected>2nd</option>
               <option value="Option 1">Option 1</option>
               <option value="Option 1">Option 2</option>
               <option value="Option 1">Option 3</option>
           </select>

    </div>
    </div>

    <hr className='w-full border-t border-gray4 my-6' />

    <div className="w-full mb-5">
        <div className="flex items-center gap-3.5">
            <h3 className='text-sm text-gray1'>Shipping address</h3>
            <Question size={18} weight='fill' className='text-gray2' />
        </div>
    </div>


    <div className="w-full">
        <div className="w-ful mb-4">
            <label htmlFor="street-address" className='text-xs text-gray2 font-medium mb-2 block'>Street address</label>
            <input name='street-address' id="street-address" type="text" placeholder='Street address' className='bg-gray6 border border-gray7 w-full h-10 px-4 text-sm text-gray2 placeholder:text-gray2 rounded-md ' />
        </div>
        <div className="w-full grid sm:grid-cols-2 grid-cols-1 gap-2.5 mb-4">
        <div className="w-ful">
            <label htmlFor="city" className='text-xs text-gray2 font-medium mb-2 block'>City</label>
            <input name='city' type="text" id='city' placeholder='City' className='bg-gray6 border border-gray7 w-full h-10 px-4 text-sm text-gray2 placeholder:text-gray2 rounded-md ' />
        </div>
        <div className="w-ful">
            <label htmlFor="Zip" className='text-xs text-gray2 font-medium mb-2 block'>Zip</label>
            <input name='Zip' type="text" id='Zip' placeholder='Zip' className='bg-gray6 border border-gray7 w-full h-10 px-4 text-sm text-gray2 placeholder:text-gray2 rounded-md ' />
        </div>
        </div>

        <div className="w-ful mb-4">
            <label htmlFor="street-address" className='text-xs text-gray2 font-medium mb-2 block'>Country</label>
            <select className="bg-gray3 border text-xs text-gray1 font-medium border-gray5 rounded-md w-full h-9 px-3" name="" id="">
               <option selected>Norway</option>
               <option value="Option 1">Option 1</option>
               <option value="Option 1">Option 2</option>
               <option value="Option 1">Option 3</option>
           </select>
        </div>
   
    </div>

    <hr className='w-full border-t border-gray4 my-6' />

    <div className="w-full">
        <h3 className='text-base text-gray1 font-medium mb-3'>WMS integration</h3>
        <div className="w-full flex items-center sm:justify-between justify-center sm:gap-5 gap-3 flex-wrap bg-black1 rounded-lg border border-gray4 p-4 ">
        <p className='text-sm text-gray1 font-medium'>Connect Warehouse Management System</p>
        <Button className='flex items-center gap-1'>
        Connect
        <Plug size={18} />
        </Button>
        </div>
    </div>

    <hr className='w-full border-t border-gray4 my-6' />
    
    <div className="w-full">
        <h3 className='text-base text-gray1 font-medium mb-3'>Products</h3>
        <div className="w-full flex items-center sm:justify-between justify-center sm:gap-5 gap-3 flex-wrap bg-black1 rounded-lg border border-gray4 p-4 ">
        <div className="flex items-center gap-2">
        <Info size={22} weight='fill' className='text-gray2' />
        <p className='text-sm text-gray1 font-medium'>Products is handled by Shopify</p>
        </div>
        <Button className='flex items-center gap-1 text-blue1 !bg-transparent shadow-none'>
        View connected products
        </Button>
        </div>

    </div>
   
   <Button type='submit' className='w-full h-10 md:mt-36 mt-10'>
   Update
   </Button>



    </div>
    </form>
    </div>
  )
}

export default LocationsEditView