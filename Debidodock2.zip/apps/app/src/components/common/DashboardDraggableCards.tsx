import React, { Fragment } from "react";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  useSensors,
  useSensor,
} from "@dnd-kit/core";
import { SortableContext, useSortable, arrayMove } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { DotsSixVertical } from "@phosphor-icons/react";
import DashboardPayoutsCard from "./DashboardPayoutsCard";
import DashboardRevenueCard from "./DashboardRevenueCard";

const DraggableHandle: React.FC = () => (
  <button className="text-gray-2 transition-all cursor-grab active:cursor-grabbing duration-300 hover:text-gray-1 w-[30px] h-[30px] flex items-center justify-center">
    <DotsSixVertical size={20} />
  </button>
);

const Card = ({ id, children }: { id: string; children?: React.ReactNode }) => {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      role="div"
      className="bg-gray-800 text-white relative rounded-md shadow-md flex justify-between items-center"
    >
      <Fragment>{children}</Fragment>
      <div {...listeners} className="absolute top-2 right-3">
        <DraggableHandle />
      </div>
    </div>
  );
};

const PayoutsComponent = () => <DashboardPayoutsCard />;
const RevenueComponent = () => <DashboardRevenueCard />;

const DashboardDraggableCards = () => {
  const [items, setItems] = React.useState([
    { id: "1", content: <PayoutsComponent /> },
    { id: "2", content: <RevenueComponent /> },
  ]);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor)
  );

  const handleDragEnd = (event) => {
    const { active, over } = event;

    if (active.id !== over.id) {
      setItems((prevItems) => {
        const oldIndex = prevItems.findIndex((item) => item.id === active.id);
        const newIndex = prevItems.findIndex((item) => item.id === over.id);
        return arrayMove(prevItems, oldIndex, newIndex);
      });
    }
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragEnd={handleDragEnd}
    >
      <SortableContext items={items.map((item) => item.id)}>
        <div className="w-full grid lg:grid-cols-2 grid-cols-1 gap-2 my-2">
          {items.map((item) => (
            <Fragment key={item.id}>
              <Card id={item.id}>{item.content}</Card>
            </Fragment>
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
};

export default DashboardDraggableCards;
