import { Button } from '@debido/ui/components/button';
import { ArrowUp, X } from '@phosphor-icons/react';
import { useGlobalContext } from '../../context/GlobalContext';
import SwiperChart from '../charts/SwiperChart';

const chartsData = [
  {
    name: "Revenue",
    price: "439k",
    percentage: "12%",
    increment: "+130k",
    chartData: {
      label: "Revenue",
      dataset: [
        { Revenue: 186 },
        { Revenue: 305 },
        { Revenue: 237 },
        { Revenue: 173 },
        { Revenue: 209 },
        { Revenue: 444 },
      ],
    },
  },
];

const SavedWidgetPanel = () => {
  const { setSavedWidgetPopup } = useGlobalContext();

  return (
    <div className="p-5 pb-0 pt-10 relative">
      <Button
        onClick={() => setSavedWidgetPopup(false)}
        className="absolute !bg-transparent right-2 top-1" >
        <X size={16} />
      </Button>
      <div className="w-full">
        <h3 className="text-lg mb-8 text-center">Widget Added (Finance)</h3>

        {chartsData.map((chart, index) => (
          <div
            key={`${chart.name}-${index}`}
            className="w-full bg-black3 rounded-xl border border-gray4 mb-3"
          >
            <div className="p-6 pb-0">
              <h4 className="text-sm text-gray2 font-medium">{chart.name}</h4>
              <div className="flex items-center justify-between gap-6 flex-wrap">
                <h2 className="md:text-3xll text-2xl font-semibold text-gray1 my-2">
                  {chart.price}
                </h2>
                <div className="flex items-center gap-2">
                  <div className="flex items-center justify-center font-medium gap-0.5 bg-green2 text-green1 rounded-md p-1.5 text-xs">
                    <ArrowUp size={14} />
                    <span>{chart.percentage}</span>
                  </div>
                  <span className="text-gray2 text-xs font-medium">
                    {chart.increment}
                  </span>
                </div>
              </div>
            </div>

            {/* Chart Component */}
            <div className="chart-card">
              <SwiperChart chartData={chart.chartData} />
            </div>
          </div>
        ))}
      </div>
          <div className="w-ful flex items-center justify-end pb-4">
      <Button
        onClick={() => setSavedWidgetPopup(false)}
        className="px-6" >
        Ok
      </Button>
      </div>
    </div>
  );
};

export default SavedWidgetPanel;
