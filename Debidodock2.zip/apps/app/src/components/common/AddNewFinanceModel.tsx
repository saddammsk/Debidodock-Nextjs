import { Button } from '@debido/ui/components/button'
import PopupModel from './PopupModel'
import {X } from '@phosphor-icons/react'


interface ModelProps{
    addNewFinance: boolean,
    setAddNewFinance: (addNewFinance: boolean) => void

}


const AddNewFinanceModel = ({addNewFinance, setAddNewFinance}:ModelProps ) => {

    
    
  return (
    <PopupModel
    showModel={addNewFinance}
    hideModel={setAddNewFinance}
    panelClass="max-w-[508px] bg-black2 overflow-hidden">
    <div className="w-full">
         {/* Model Head */}
         <div className="w-full px-6 flex items-center py-6">
        <h2 className="text-base text-gray1">Adobe</h2>
        <Button onClick={()=>setAddNewFinance(false)}  className="!bg-transparent ml-auto px-1 text-gray2 hover:text-gray1">
          <X size={14} />
        </Button>
        </div>

        {/*Model Body */}
        <div className="w-full px-6">
            <form >
                <div className="w-full">
                    <div className="w-full mb-4">
                    <label htmlFor="Costname" className='mb-1.5 block text-xs text-gray2'>Cost name</label>
                    <input type="text" id='Costname' placeholder='Adobe' className='h-10 text-gray1 placeholder:text-gray1 text-sm rounded-md border border-gray7 w-full px-4' />
                    </div>
                    <div className="w-full flex items-center">
                    <div className="w-full mb-4">
                    <label htmlFor="Amount" className='mb-1.5 block text-xs text-gray2'>Amount</label>
                    <input type="text" id='Amount' placeholder='399' className='h-10 text-gray1 placeholder:text-gray1 text-sm rounded-md border border-gray7 w-full px-4' />
                    </div>
                    <div className="flex gap-2">
                        <p className='text-xs whitespace-nowrap'>Includes VAT</p>
                        <input type="checkbox" />
                    </div>
                    </div>
                </div>

            </form>
        </div>
    </div>
    </PopupModel>
  )
}

export default AddNewFinanceModel