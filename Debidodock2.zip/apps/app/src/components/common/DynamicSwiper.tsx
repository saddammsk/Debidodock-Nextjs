import { ArrowUp } from "@phosphor-icons/react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import SwiperChart from "../charts/SwiperChart";

const chartsData = [
  {
    id: 1,
    name: "Revenue",
    price: "439k",
    percentage: "12%",
    increment: "+130k",
    chartData: {
      label: "Revenue",
      dataset: [
        { Revenue: 186 },
        { Revenue: 305 },
        { Revenue: 237 },
        { Revenue: 173 },
        { Revenue: 209 },
        { Revenue: 444 },
      ],
    },
  },
  {
    id: 2,
    name: "Revenue",
    price: "439k",
  },
  {
    id: 3,
    name: "Net profit",
    price: "49k",
    percentage: "15%",
    increment: "+30k",
    chartData: {
      label: "NetProfit",
      dataset: [
        { NetProfit: 186 },
        { NetProfit: 305 },
        { NetProfit: 237 },
        { NetProfit: 463 },
        { NetProfit: 209 },
        { NetProfit: 214 },
      ],
    },
  },
  {
    id: 4,
    name: "Revenue",
    price: "439k",
    percentage: "15%",
    increment: "+130k",
    chartData: {
      label: "Revenue",
      dataset: [
        { Revenue: 186 },
        { Revenue: 305 },
        { Revenue: 237 },
        { Revenue: 753 },
        { Revenue: 209 },
        { Revenue: 514 },
      ],
    },
  },
 
];

const DynamicSwiper = () => {
  return (
    <>
      <Swiper
        className="chart-swiper !flex !pb-14"
        modules={[Pagination, Navigation]}
        navigation={true}
        pagination={{
          clickable: true,
        }}
        slidesPerView={1}
      >
        {chartsData.map((chart, index) => (
          <SwiperSlide key={`${chart.id + index}`} className="m-auto">
            {chart?.chartData ? (
              <div className="w-full max-w-[343px] mx-auto">
                <div className="w-full bg-black3 rounded-xl border border-gray4">
                  <div className="3xl:p-6 p-4 pb-0">
                    <h4 className="text-sm text-gray2 font-medium">
                      {chart?.name}
                    </h4>
                    <div className="flex items-center justify-between gap-6 flex-wrap">
                      <h2 className="text-2xl font-semibold text-gray1 my-2">
                        {chart?.price}
                      </h2>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center justify-center font-medium gap-0.5 bg-green2 text-green1 rounded-md p-1.5 text-xs">
                          <ArrowUp size={14} />
                          <span>{chart?.percentage}</span>
                        </div>
                        <span className="text-gray2 text-xs font-medium">
                          {chart?.increment}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Chart Component */}
                  {chart?.chartData && (
                    <div className="chart-card">
                      <SwiperChart chartData={chart?.chartData} />
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="w-full max-w-[343px] m-auto ">
                <div className="w-full flex flex-col bg-black3 py-10  rounded-xl border border-gray4">
                  <div className="3xl:p-6 p-4 pb-0 w-full flex flex-col h-full">
                    <h4 className="text-sm text-gray2 text-center font-medium">
                      Revenue
                    </h4>
                    <div className="flex items-center my-auto justify-between gap-6 flex-wrap">
                      <h2 className="text-3xl text-center mx-auto font-semibold text-gray1 my-2">
                        439k
                      </h2>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </SwiperSlide>
        ))}
      </Swiper>
    </>
  );
};

export default DynamicSwiper;
