import PopupModel from './PopupModel'
import { Button } from '@debido/ui/components/button'
import { CalendarBlank, X } from '@phosphor-icons/react'

interface ModelProps{
    showImportBankModel: boolean,
    setShowImportBankModel: (showImportBankModel: boolean) => void

}

 const BankData = [
    {labelName: 'A', title: 'Adobe Creative', kr: '968 kr', date: '22 Jun 2024' },
    {labelName: 'G', title: 'Google', kr: '968 kr', date: '24 Jun 2024' },
    {labelName: 'A', title: 'Adobe', kr: '938 kr', date: '22 Jun 2024' },
    {labelName: 'A', title: 'Adobe Creative', kr: '968 kr', date: '25 Jun 2024' },
    {labelName: 'A', title: 'Adobe Creative', kr: '948 kr', date: '22 Jun 2024' },
    {labelName: 'A', title: 'Adobe Creative', kr: '968 kr', date: '27 Jun 2024' },
    {labelName: 'A', title: 'Adobe Creative', kr: '968 kr', date: '22 Jun 2025' },
 ]



const ImportBankModel = ({showImportBankModel, setShowImportBankModel}:ModelProps ) => {
  return (
    <PopupModel
    showModel={showImportBankModel}
    hideModel={setShowImportBankModel}
    panelClass="max-w-[978px] bg-black2 overflow-hidden"
    >
      <div className="w-full pb-[70px]">
        {/* Model Head */}
        <div className="w-full px-8 flex items-center py-6">
        <h2 className="text-base text-gray1">Import transactions from bank</h2>
        <div className="flex items-center gap-4 ml-10">
        <Button className="!bg-transparent border border-gray5 text-gray2 text-xs px-2 gap-1.5 font-medium">
        <CalendarBlank size={16} />
         Start date
        </Button>
        <Button className="!bg-transparent border border-gray5 text-gray2 text-xs px-2 gap-1.5 font-medium">
        <CalendarBlank size={16} />
         End date
        </Button>
        </div>
        <Button onClick={()=>setShowImportBankModel(false)}  className="!bg-transparent ml-auto px-1 text-gray2 hover:text-gray1">
          <X size={14} />
        </Button>
        </div>

        {/* Model Body */}
        <div className="w-full">

            <table className='w-full border-t border-gray4'>
                <tbody>
                    {BankData.map((data) => (

                    <tr key={`$${data.title}`} className='px-6 py-3 border-b border-gray4 w-full'>
                        <td className='py-3 px-6'>
                        <div className="flex items-center gap-2">
                        <span className='w-7 h-7 bg-gray3 text-gray2 flex items-center justify-center text-sm rounded'>
                          {data?.labelName}
                        </span>
                        <h4 className='text-sm text-gray1'>{data?.title}</h4>
                        </div>
                        </td>
                        <td className='py-3 px-2'>
                            <div className="flex items-center justify-center">
                            <p className='text-sm text-gray1'>{data?.kr}</p>
                            </div>
                        </td>
                        <td className='py-3 px-2'>
                            <div className="flex items-center justify-center">
                            <p className='text-sm text-gray2'>{data?.date}</p>
                            </div>
                        </td>
                        <td className='py-3 px-2 pr-6'>
                            <div className="flex items-center justify-end">
                            <Button>
                            Add
                            </Button>
                            </div>
                         
                        </td>
                    </tr>
                    )) }
                </tbody>
            </table>
          
        </div>

      </div>
    </PopupModel>
  )
}

export default ImportBankModel