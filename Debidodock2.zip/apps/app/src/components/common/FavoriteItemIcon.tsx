import { FavoriteType } from "@debido/server";
import {
  GearSix,
  IconProps,
  Layout,
  Package,
  Tag,
} from "@phosphor-icons/react";

type MainMenuFavoriteIconProps = {
  type: FavoriteType;
  props: IconProps;
};

export default function FavoriteItemIcon({
  type,
  props,
}: MainMenuFavoriteIconProps) {
  if (type === "PRODUCT") {
    return <Tag {...props} />;
  } else if (type === "PURCHASE_ORDER") {
    return <Package {...props} />;
  } else if (type === "BOARD") {
    return <Layout {...props} />;
  } else {
    return <GearSix {...props} />;
  }
}
