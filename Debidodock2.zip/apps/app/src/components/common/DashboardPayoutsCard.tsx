import {DotsThree, Table, ToggleRight } from '@phosphor-icons/react'

const DashboardPayoutsCard = () => {
  return (
    <div className="w-full bg-black3 rounded-xl border border-gray4 h-full">
    {/* Payouts head */}
    <div className="w-full flex items-center justify-between gap-6 px-3 py-2.5 border-b border-gray4">
    <div className="text-sm text-gray2 flex items-center gap-2 font-medium ">
        <Table size={18} />
        <p>Payouts</p>
    </div>
    <div className="flex items-center gap-3">
        <button className="text-gray2 transition-all duration-300 hover:text-gray1 w-[18px] h-[18px] flex items-center justify-center">
        <DotsThree size={20} />
        </button>
        <div className="w-6 h-6"></div>
    </div>
    </div>

    <ul>
    <li className="px-4 py-2 flex items-center justify-between border-b border-gray4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
        <ToggleRight size={20} className="text-green1" />
        <h4 className="text-sm text-gray1 font-medium">
            Google
        </h4>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
        <div className="rounded-full inline-flex items-center border border-gray4">
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 border-r border-gray5">
            <div className="bg-blue2 rounded-full w-2 h-2"></div>
            <p className="text-xs text-gray2 font-medium">
                Recurring
            </p>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1.5">
            <p className="text-xs text-gray2 font-medium">
                Monthly
            </p>
            </div>
        </div>
        <div className="rounded-full inline-flex px-2.5 py-1.5 items-center border border-gray4">
            <p className="text-xs text-gray2 font-medium">
            399 kr
            </p>
        </div>

        <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">
            <div className="bg-green1 rounded-full w-2 h-2"></div>
            <p className="text-xs text-gray2 font-medium">
            399 kr
            </p>
        </div>
        </div>
    </li>
    <li className="px-4 py-2 flex items-center justify-between border-b border-gray4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
        <ToggleRight size={20} className="text-green1" />
        <h4 className="text-sm text-gray1 font-medium">
            Adobe Creative
        </h4>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
        <div className="rounded-full inline-flex items-center border border-gray4">
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 border-r border-gray5">
            <div className="bg-blue2 rounded-full w-2 h-2"></div>
            <p className="text-xs text-gray2 font-medium">
                Recurring
            </p>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1.5">
            <p className="text-xs text-gray2 font-medium">
                Monthly
            </p>
            </div>
        </div>
        <div className="rounded-full inline-flex px-2.5 py-1.5 items-center border border-gray4">
            <p className="text-xs text-gray2 font-medium">
            399 kr
            </p>
        </div>

        <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">
            <div className="bg-green1 rounded-full w-2 h-2"></div>
            <p className="text-xs text-gray2 font-medium">
            399 kr
            </p>
        </div>
        </div>
    </li>
    <li className="px-4 py-2 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
        <ToggleRight size={20} className="text-green1" />
        <h4 className="text-sm text-gray1 font-medium">
            Shopify
        </h4>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
        <div className="rounded-full inline-flex items-center border border-gray4">
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 border-r border-gray5">
            <div className="bg-blue2 rounded-full w-2 h-2"></div>
            <p className="text-xs text-gray2 font-medium">
                Recurring
            </p>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1.5">
            <p className="text-xs text-gray2 font-medium">
                Monthly
            </p>
            </div>
        </div>
        <div className="rounded-full inline-flex px-2.5 py-1.5 items-center border border-gray4">
            <p className="text-xs text-gray2 font-medium">
            399 kr
            </p>
        </div>

        <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">
            <div className="bg-green1 rounded-full w-2 h-2"></div>
            <p className="text-xs text-gray2 font-medium">
            399 kr
            </p>
        </div>
        </div>
    </li>
    </ul>
</div>
  )
}

export default DashboardPayoutsCard