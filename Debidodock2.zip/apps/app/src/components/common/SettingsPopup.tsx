import PopupModel from '../common/PopupModel'



interface ModelProps{
    showPopup: boolean,
    setShowPopup: (showPopup: boolean) => void,
    children: React.ReactNode
}

const SettingsPopup = ({showPopup, setShowPopup, children}:ModelProps ) => {


    
  return (
    <PopupModel
    showModel={showPopup}
    hideModel={setShowPopup}
    panelClass="max-w-[510px] bg-black2 md:min-h-[calc(100vh_-_16px)] overflow-hidden md:ml-auto md:mb-auto m-2">
    <div className="w-full h-full">
    <div className="w-full bg-black2 h-full">
    <div className="w-full h-full md:pl-6 py-5 px-3 md:pr-4">
        {children}
    </div>
    </div>  
    </div>
    </PopupModel>
  )
}

export default SettingsPopup