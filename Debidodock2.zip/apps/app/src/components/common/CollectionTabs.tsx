import { Button, Tab, TabGroup, TabList, TabPanel, TabPanels } from "@headlessui/react";
import { ArrowRight, MagnifyingGlass, X } from "@phosphor-icons/react";
import SearchField from "./SearchField";
import DynamicSwiper from "./DynamicSwiper";
import { useGlobalContext } from "../../context/GlobalContext";

const FinanceData = [
  {
    id: 1,
    name: "Recent",
    shortdes: "All income",
    category: "Finance",
    posts: [
      {
        id: 1,
        name: "Revenue",
        price: "439k",
        percentage: "15%",
        increment: "+130k",
      },
    
    ],
  },
  {
    id: 2,
    name: "Popular",
    shortdes: "All costs - income",
    category: "Finance",
    posts: [
      {
        id: 2,
        name: "Revenue",
        price: "439k",
        percentage: "15%",
        increment: "+130k",
      },
     
    ],
  },
  {
    id: 3,
    name: "Trending",
    shortdes: "All costs - income",
    category: "Purchase orders",
    posts: [
      {
        id: 3,
        name: "Revenue",
        price: "439k",
        percentage: "15%",
        increment: "+130k",
      },
   
    ],
  },
  {
    id: 4,
    name: "Trending",
    shortdes: "All costs - income",
    category: "Purchase orders",
    posts: [
      {
        id: 4,
        name: "Revenue",
        price: "439k",
        percentage: "15%",
        increment: "+130k",
      },
   
    ],
  },
  {
    id: 5,
    name: "Trending",
    shortdes: "All costs - income",
    category: "Purchase orders",
    posts: [
      {
        id: 5,
        name: "Revenue",
        price: "439k",
        percentage: "15%",
        increment: "+130k",
      },
   
    ],
  },
];

const PurchaseData = [
  {
    id: 1,
    name: "Purchase orders",
    shortdes: "All purchase orders",
    category: "Purchase-orders",
    preview:'/images/purchase-orders-preview.png',
  },
  {
    id: 2,
    name: "Purchase orders",
    shortdes: "All purchase orders",
    category: "Purchase-orders",
    preview:'/images/purchase-orders-preview.png',
  },
 
];

const BankBalanceData = [
  {
    id: 1,
    name: "Bank Balance",
    shortdes: "All Bank Balance",
    category: "Bank Balance",
    preview:'/images/bank-balance-chart-preview.png',
  
  },
  {
    id: 2,
    name: "Bank Balance",
    shortdes: "All Bank Balance",
    category: "Bank Balance",
    preview:'/images/bank-balance-chart-preview.png',
  
  },
 
 
];

const PayoutsData = [
  {
    id: 1,
    name: "Payouts",
    shortdes: "Payouts List",
    category: "Payouts",
    preview:'/images/payouts-preview.png',
  
  },
  {
    id: 2,
    name: "Payouts",
    shortdes: "Payouts List",
    category: "Payouts",
    preview:'/images/payouts-preview.png',
  
  },
 
];

const RevenueData = [
  {
    id: 1,
    name: "Revenue",
    shortdes: "Revenue List",
    category: "Revenue",
    preview:'/images/revenue-preview.png',
  
  },
  {
    id: 2,
    name: "Revenue",
    shortdes: "Revenue List",
    category: "Revenue",
    preview:'/images/revenue-preview.png',
  
  },
 
];

export default function CollectionTabs() {
  const {setShowPopup, setIsAddedWidget} = useGlobalContext()

  const handleShowPopup = () => {
    setShowPopup(false)
    setIsAddedWidget(true)
  }

  return (
    <TabGroup>
      <div className="w-full grid md:grid-cols-2 grid-cols-1 md:gap-9 gap-0 relative">
        <Button onClick={()=>setShowPopup(false)} className="absolute md:hidden right-3 top-2">
        <X size={16} />
        </Button>
        <div className="md:py-7 py-10 md:pl-6 px-3  md:pr-0.5">
          {/* search field */}
          <SearchField
            placeholder="Search for widget"
            classInput="pl-9"
            icon={<MagnifyingGlass size={16} />} />
            <div className="w-full max-h-[85vh] mt-3 overflow-y-auto">
            <h3 className="text-sm text-gray2 font-medium mt-5 mb-4">
              Finance
            </h3>
              <TabList className="flex flex-col gap-2 max-h-[370px] overflow-y-auto items-start text-start">
                {FinanceData.map(({ id,name, shortdes }) => (
                  <Tab
                    key={id}
                    className="hover:bg-blue2 w-full flex items-center bg-gray9 border border-gray4 text-start text-sm !outline-none !right-0 transition-all duration-300 justify-between rounded-lg px-5 3xl:py-4 py-2.5 focus:outline-none data-[selected]:bg-blue2">
                    <div>
                      <h3 className="text-sm font-medium mb-0.5">{name}</h3>
                      <p className="text-xs font-normal text-gray8">
                        {shortdes}
                      </p>
                    </div>
                    <ArrowRight size={16} />
                  </Tab>
                ))}
              </TabList>

              <h3 className="text-sm text-gray2 font-medium mt-8 mb-4">
                Purchase orders
              </h3>
              <TabList className="flex flex-col gap-2 max-h-[370px] overflow-y-auto items-start text-start">
                  {PurchaseData.map(({ id,name, shortdes }) => (
                    <Tab
                      key={id}
                      className="hover:bg-blue2 w-full flex items-center bg-gray9 border border-gray4 text-start text-sm !outline-none !right-0 transition-all duration-300 justify-between rounded-lg px-5 3xl:py-4 py-2.5 focus:outline-none data-[selected]:bg-blue2">
                      <div>
                        <h3 className="text-sm font-medium mb-0.5">{name}</h3>
                        <p className="text-xs font-normal text-gray8">
                          {shortdes}
                        </p>
                      </div>
                      <ArrowRight size={16} />
                    </Tab>
                  ))}
              </TabList>

              <h3 className="text-sm text-gray2 font-medium mt-8 mb-4">
              Bank Balance
              </h3>

              <TabList className="flex flex-col gap-2 max-h-[370px] overflow-y-auto items-start text-start">
                  {BankBalanceData.map(({ id,name, shortdes }) => (
                    <Tab
                      key={id}
                      className="hover:bg-blue2 w-full flex items-center bg-gray9 border border-gray4 text-start text-sm !outline-none !right-0 transition-all duration-300 justify-between rounded-lg px-5 3xl:py-4 py-2.5 focus:outline-none data-[selected]:bg-blue2">
                      <div>
                        <h3 className="text-sm font-medium mb-0.5">{name}</h3>
                        <p className="text-xs font-normal text-gray8">
                          {shortdes}
                        </p>
                      </div>
                      <ArrowRight size={16} />
                    </Tab>
                  ))}
              </TabList>

              <h3 className="text-sm text-gray2 font-medium mt-8 mb-4">
              Payouts
              </h3>
              <TabList className="flex flex-col gap-2 max-h-[370px] overflow-y-auto items-start text-start">
                  {PayoutsData.map(({ id,name, shortdes }) => (
                    <Tab
                      key={id}
                      className="hover:bg-blue2 w-full flex items-center bg-gray9 border border-gray4 text-start text-sm !outline-none !right-0 transition-all duration-300 justify-between rounded-lg px-5 3xl:py-4 py-2.5 focus:outline-none data-[selected]:bg-blue2">
                      <div>
                        <h3 className="text-sm font-medium mb-0.5">{name}</h3>
                        <p className="text-xs font-normal text-gray8">
                          {shortdes}
                        </p>
                      </div>
                      <ArrowRight size={16} />
                    </Tab>
                  ))}
              </TabList>

              <h3 className="text-sm text-gray2 font-medium mt-8 mb-4">
              Bank balance
              </h3>
              <TabList className="flex flex-col gap-2 max-h-[370px] overflow-y-auto items-start text-start">
                  {RevenueData.map(({ id,name, shortdes }) => (
                    <Tab
                      key={id}
                      className="hover:bg-blue2 w-full flex items-center bg-gray9 border border-gray4 text-start text-sm !outline-none !right-0 transition-all duration-300 justify-between rounded-lg px-5 3xl:py-4 py-2.5 focus:outline-none data-[selected]:bg-blue2">
                      <div>
                        <h3 className="text-sm font-medium mb-0.5">{name}</h3>
                        <p className="text-xs font-normal text-gray8">
                          {shortdes}
                        </p>
                      </div>
                      <ArrowRight size={16} />
                    </Tab>
                  ))}
              </TabList>
            </div>
         </div>

          <TabPanels className="w-full bg-black2 rounded-xl border border-gray4">
            {FinanceData.map(({ id,name, shortdes, posts }) => (
              <TabPanel key={id} className="h-full">
                  {posts.map((post) => (
                    <div key={post.id}>
                        <div className="w-full flex flex-col">
                        <div className="md:p-8 p-4">
                         <h3 className="text-base font-medium text-gray1 mb-1">{name}</h3>
                         <p className="text-xs text-gray2 font-normal" >{shortdes}</p>
                         </div>
                         <div className="w-full 3xl:my-36 md:my-16 py-8 md:px-11 px-4">
                            <DynamicSwiper/>
                         </div>
                         <Button onClick={handleShowPopup} className="w-[calc(100%_-_32px)] text-xs text-gray1 rounded-md border border-gray5 shadow-dropdown hover:bg-blue2 transition-all duration-300 font-medium mx-auto py-3.5 bg-gray3 text-center mb-5">
                         Add widget
                         </Button>
                         </div>
                    </div>))}
              </TabPanel>
            ))}
            {PurchaseData.map(({id,name, shortdes, preview }) => (
          <TabPanel key={id} className="h-full">
              <div className="w-full flex flex-col h-full">
                    <div className="md:p-8 p-4">
                      <h3 className="text-base font-medium text-gray1 mb-1">{name}</h3>
                      <p className="text-xs text-gray2 font-normal" >{shortdes}</p>
                      </div>
                      <div className="w-full 3xl:my-36 md:my-16 py-8 px-4">
                      <img src={preview} alt="preview" className="w-full h-[200px] object-cover object-left"/>
                      </div>
                      <Button onClick={handleShowPopup} className="w-[calc(100%_-_32px)] mt-auto text-xs text-gray1 rounded-md border border-gray5 shadow-dropdown hover:bg-blue2 transition-all duration-300 font-medium mx-auto py-3.5 bg-gray3 text-center mb-5">
                      Add widget
                      </Button>
                      </div>
          </TabPanel>
            ))}
            {BankBalanceData.map(({ id,name, shortdes, preview }) => (
            <TabPanel key={id} className="h-full">
                <div className="w-full flex flex-col h-full">
                      <div className="md:p-8 p-4">
                        <h3 className="text-base font-medium text-gray1 mb-1">{name}</h3>
                        <p className="text-xs text-gray2 font-normal" >{shortdes}</p>
                        </div>
                        <div className="w-full 3xl:my-36 md:my-16 py-8 px-4">
                        <img src={preview} alt="preview" className="w-full h-auto object-contain object-center"/>
                        </div>
                        <Button onClick={handleShowPopup} className="w-[calc(100%_-_32px)] mt-auto text-xs text-gray1 rounded-md border border-gray5 shadow-dropdown hover:bg-blue2 transition-all duration-300 font-medium mx-auto py-3.5 bg-gray3 text-center mb-5">
                        Add widget
                        </Button>
                        </div>
            </TabPanel>
            ))}
            {PayoutsData.map(({id ,name, shortdes, preview }) => (
          <TabPanel key={id} className="h-full">
              <div className="w-full flex flex-col h-full">
                    <div className="md:p-8 p-4">
                      <h3 className="text-base font-medium text-gray1 mb-1">{name}</h3>
                      <p className="text-xs text-gray2 font-normal" >{shortdes}</p>
                      </div>
                      <div className="w-full 3xl:my-36 md:my-16 py-8 px-4">
                      <img src={preview} alt="preview" className="w-full h-auto object-contain object-center"/>
                      </div>
                      <Button onClick={handleShowPopup} className="w-[calc(100%_-_32px)] mt-auto text-xs text-gray1 rounded-md border border-gray5 shadow-dropdown hover:bg-blue2 transition-all duration-300 font-medium mx-auto py-3.5 bg-gray3 text-center mb-5">
                      Add widget
                      </Button>
                      </div>
          </TabPanel>
            ))}
            {RevenueData.map(({id ,name, shortdes, preview }) => (
              <TabPanel key={id} className="h-full">
                  <div className="w-full flex flex-col h-full">
                        <div className="md:p-8 p-4">
                         <h3 className="text-base font-medium text-gray1 mb-1">{name}</h3>
                         <p className="text-xs text-gray2 font-normal" >{shortdes}</p>
                         </div>
                         <div className="w-full 3xl:my-36 md:my-16 py-8 px-4">
                          <img src={preview} alt="preview" className="w-full h-auto object-contain object-center"/>
                         </div>
                         <Button onClick={handleShowPopup} className="w-[calc(100%_-_32px)] mt-auto text-xs text-gray1 rounded-md border border-gray5 shadow-dropdown hover:bg-blue2 transition-all duration-300 font-medium mx-auto py-3.5 bg-gray3 text-center mb-5">
                         Add widget
                         </Button>
                         </div>
              </TabPanel>
            ))}
          </TabPanels>
        </div>
    </TabGroup>
  );
}
