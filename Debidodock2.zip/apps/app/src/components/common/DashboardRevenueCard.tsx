import { DotsThree, Coins } from "@phosphor-icons/react";
import { RevenueChart } from "../charts/RevenueChart";

const DashboardRevenueCard = () => {
  return (
    <>
      {/* Revenue Chart */}
      <div className="w-full bg-black3 rounded-xl border border-gray4 h-full">
        {/* Chart head */}
        <div className="w-full flex items-center justify-between gap-6 px-3 py-2.5 border-b border-gray4">
          <div className="text-sm text-gray2 flex items-center gap-2 font-medium ">
            <Coins size={18} />
            <p>Cost breakdown</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="text-gray2 transition-all duration-300 hover:text-gray1 w-[18px] h-[18px] flex items-center justify-center">
              <DotsThree size={20} />
            </button>

            <div className="w-6 h-6"></div>
          </div>
        </div>

        <div className="w-full flex items-center justify-center">
          <RevenueChart />
        </div>
      </div>
    </>
  );
};

export default DashboardRevenueCard;
