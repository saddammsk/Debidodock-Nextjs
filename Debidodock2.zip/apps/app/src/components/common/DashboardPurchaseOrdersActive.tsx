import {
  DotsThree,
  Package,
} from "@phosphor-icons/react";
import RangeCalendarChart from "./RangeCalendarChart";

const DashboardPurchaseOrdersActive = () => {
  return (
    <div className="w-full bg-black3 rounded-xl border border-gray4 my-2">
      <div className="w-full">
        {/* head */}
        <div className="w-full flex items-center justify-between gap-6 px-3 py-2.5 border-b border-gray4">
          <div className="text-sm text-gray2 flex items-center gap-2 font-medium ">
            <Package size={20} />
            <p>Purchase orders - Active</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="text-gray2 transition-all duration-300 hover:text-gray1 w-[18px] h-[18px] flex items-center justify-center">
              <DotsThree size={20} />
            </button>

            <div className="w-6 h-6"></div>
          </div>
        </div>
      </div>
      
      <RangeCalendarChart/>
   
    </div>
  );
};

export default DashboardPurchaseOrdersActive;
