"use client";
import { useState } from "react";
import { format } from "date-fns";
import { Button } from "../ui/button";
import { Calendar } from "../ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "../ui/popover";
import { CalendarBlank } from "@phosphor-icons/react";

interface DatePickerProps {
  onDateChange?: (date: Date | undefined) => void; 
  dateLabel?: string;
  classBtn?: string; 
}

export function DatePicker({ onDateChange, dateLabel, classBtn="" }: DatePickerProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);

  function handleDateSelect(date: Date | undefined) {
    setSelectedDate(date);
    if (onDateChange) {
      onDateChange(date);
    }
  }

  return (
    <div className="flex flex-col">
      <Popover>
        <PopoverTrigger asChild>
          <Button
            className={`${classBtn}` + ` inline-flex w-fit border text-gray2 text-xs border-gray5 ${
              !selectedDate ? "text-gray2" : "text-gray1"
            }`}
          >
            <CalendarBlank size={16}/>
            {selectedDate ? format(selectedDate, "MM/dd/yyyy") : `${dateLabel}`}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0 bg-gray6" align="start">
          <Calendar
            mode="single"
            selected={selectedDate} 
            onSelect={handleDateSelect}
            disabled={(date) =>
              date > new Date() || date < new Date("1900-01-01")
            }
            initialFocus
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
