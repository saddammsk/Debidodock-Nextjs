import { Button, Tab, TabGroup, TabList, TabPanel, TabPanels } from "@headlessui/react";
import { ArrowRight, MagnifyingGlass, X } from "@phosphor-icons/react";
import SearchField from "./SearchField";
import DynamicSwiper from "./DynamicSwiper";
import { useGlobalContext } from "../../context/GlobalContext";

const categories = [
  {
    name: "Recent",
    shortdes: "All income",
    category: "Finance",
    posts: [
      {
        id: 1,
        name: "Revenue",
        price: "439k",
        percentage: "15%",
        increment: "+130k",
      },
    
    ],
  },
  {
    name: "Popular",
    shortdes: "All costs - income",
    category: "Finance",
    posts: [
      {
        id: 2,
        name: "Revenue",
        price: "439k",
        percentage: "15%",
        increment: "+130k",
      },
     
    ],
  },
  {
    name: "Trending",
    shortdes: "All costs - income",
    category: "Purchase orders",
    posts: [
      {
        id: 3,
        name: "Revenue",
        price: "439k",
        percentage: "15%",
        increment: "+130k",
      },
   
    ],
  },
];

export default function CollectionTabsFullWidth() {
  const {setShowPopup} = useGlobalContext()
  const {setchartFlag}= useGlobalContext();

  const handleShowPopup = () => {
    setShowPopup(false);
    setchartFlag(false);
  }



  return (
    <TabGroup>
      <div className="w-full grid md:grid-cols-1 grid-cols-1 gap-0 relative md:px-6 px-3">
        <Button onClick={()=>setShowPopup(false)} className="absolute md:hidden right-3 top-2">
        <X size={20} />
        </Button>
        <div className="md:py-7 py-10">
          {/* search field */}
          <SearchField
            placeholder={"Search for widget"}
            classInput="pl-9"
            icon={<MagnifyingGlass size={16} />}
          />

              <h3 className="text-sm text-gray2 font-medium mt-8 mb-4">
                Finance
              </h3>
              <TabList className="flex flex-col gap-2 items-start text-start">
                {categories.map(({ name, shortdes }) => (
                  <Tab
                    key={name}
                    className="hover:bg-blue2 w-full flex items-center bg-gray9 border border-gray4 text-start text-sm !outline-none !right-0 transition-all duration-300 justify-between rounded-lg px-5 py-2.5 focus:outline-none data-[selected]:bg-blue2"
                  >
                    <div>
                      <h3 className="text-sm font-medium mb-0.5">{name}</h3>
                      <p className="text-xs font-normal text-gray8">
                        {shortdes}
                      </p>
                    </div>
                    <ArrowRight size={16} />
                  </Tab>
                ))}
              </TabList>
        </div>

          <TabPanels className="w-full bg-black2 rounded-xl border border-gray4">
            {categories.map(({ name,shortdes, posts }) => (
              <TabPanel key={name}>
                  {posts.map((post) => (
                    <div key={post.id}>
                        <div className="w-full flex flex-col">
                        <div className="md:p-8 p-4">
                         <h3 className="text-base font-medium text-gray1 mb-1">{name}</h3>
                         <p className="text-xs text-gray2 font-normal" >{shortdes}</p>
                         </div>
                         <div className="w-full p-8 pt-0 max-w-[520px] mx-auto">
                            <DynamicSwiper/>
                         </div>

                         <Button onClick={handleShowPopup} className="w-[calc(100%_-_32px)] text-xs text-gray1 rounded-md border border-gray5 shadow-dropdown hover:bg-blue2 transition-all duration-300 font-medium mx-auto py-3.5 bg-gray3 text-center mb-5">
                         Add widget
                         </Button>

                         </div>
                    </div>
                  ))}
              </TabPanel>
            ))}
          </TabPanels>
        </div>
    </TabGroup>
  );
}
