import {Select } from '@headlessui/react'
import { CaretDown } from '@phosphor-icons/react'
import clsx from 'clsx'

interface OptionData {
    selectClass: string
    children: React.ReactNode
}



export default function SelectOption({selectClass, children}: OptionData) {
  return (
        <div className="relative flex items-center w-full">
          <Select
            className={clsx(
              'block min-w-fit h-9 bg-gray3 px-4 rounded-md border border-gray5 appearance-none text-gray1',
              'focus:outline-none data-[focus]:outline-0 data-[focus]:-outline-offset-0',
                `${selectClass}`
            )}
          >
           {children}
          </Select>
          <CaretDown
            className="group pointer-events-none absolute right-3 size-4"
            aria-hidden="true"
          />
        </div>
  )
}
