import { cn } from '@debido/ui/lib/utils';
import { 
  ArrowLeft, UserCircle, Storefront, UsersThree, ChartLine, 
  Package, Bank, Truck, MapPin, Factory, HandCoins, 
  PuzzlePiece, Swatches, Receipt 
} from '@phosphor-icons/react';
import { useLocation, useNavigate } from '@tanstack/react-router';
import { useGlobalContext } from '../../context/GlobalContext';

const menuSections = [
  {
    title: "Settings Links",
    items: [
      { path: "/settings/profile", label: "Profile", icon: UserCircle },
      { path: "/settings/store", label: "Store", icon: Storefront },
      { path: "/settings/members", label: "Members", icon: UsersThree },
    ],
  },
  {
    title: "Inventory Management",
    items: [
      { path: "/settings/inventory", label: "Inventory", icon: ChartLine },
      { path: "/settings/purchase-orders", label: "Purchase Orders", icon: Package },
      { path: "/settings/bank", label: "Bank", icon: Bank },
      { path: "/settings/shipping", label: "Shipping", icon: Truck },
      { path: "/settings/locations", label: "Locations", icon: MapPin },
      { path: "/settings/vendors", label: "Vendors", icon: Factory },
      { path: "/settings/gateways", label: "Gateways", icon: HandCoins },
      { path: "/settings/integrations", label: "Integrations", icon: PuzzlePiece },
    ],
  },
  {
    title: "Plans and Billing",
    items: [
      { path: "/settings/plans", label: "Plans", icon: Swatches },
      { path: "/settings/billing", label: "Billing", icon: Receipt },
    ],
  },
];

const SettingsSidebar = () => {
  const { pathname } = useLocation();
  const { setToggleSidebar } = useGlobalContext();
  const navigate = useNavigate();

  return (
    <div className="h-screen pt-6 px-2 pb-8">
      <div className="overflow-y-auto h-[calc(100vh-44px)]">
        <div className="w-full">
          {/* Back Button */}
          <div
            onClick={() => {
              navigate({ to: '/' });
              setToggleSidebar(false);
            }}
            className="flex cursor-pointer transition-all duration-300 hover:text-gray1 items-center text-sm text-gray2 font-medium gap-3 mb-8 px-2"
          >
            <ArrowLeft size={14} />
            <span>Settings</span>
          </div>

          {/* Dynamic Menu Sections */}
          {menuSections.map((section, sectionIndex) => (
            <div key={sectionIndex} className="w-full min-w-[222px]">
              <ul className="w-full flex flex-col gap-1.5">
                {section.items.map((item, itemIndex) => (
                  <li key={itemIndex}>
                    <div
                      onClick={() => {
                        navigate({ to: item.path });
                        setToggleSidebar(false);
                      }}
                      className={cn(
                        "flex items-center relative text-sm gap-2 py-2 px-2 w-full cursor-pointer transition-all duration-100 rounded hover:bg-gray10 text-muted hover:text-gray1 group",
                        pathname.includes(item.path) && "bg-gray10 text-gray1"
                      )}
                    >
                      <item.icon size={20} />
                      {item.label}
                    </div>
                  </li>
                ))}
              </ul>
              {sectionIndex < menuSections.length - 1 && (
                <hr className="w-[calc(100%_-_8px)] mx-auto border-t border-gray3 my-4" />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SettingsSidebar;
