import {
    CaretRight,
    Pulse,
    SpinnerGap,
  } from "@phosphor-icons/react";
  import CalendarChart from "../charts/CalendarChart";

const RangeCalendarChart = () => {
  return (
    <div className="w-full flex lg:gap-10 gap-6 lg:flex-row flex-col bg-black1">
    <div className="w-full max-w-[278px] bg-black3">
      <div className="w-ful h-11 lg:block hidden border-b boredr-gray4"></div>
      <ul className="flex flex-col items-center">
        <li className="w-full flex items-center gap-1.5 border-b border-gray4 md:pl-5 md:pr-4 px-3 py-4">
          <a
            href="#"
            className="flex whitespace-nowrap items-center gap-1.5 text-gray2 text-sm font-medium"
          >
            <SpinnerGap size={20} className="text-orange" />
            <span>Winter order</span>
            <CaretRight size={14} />
          </a>
          <p className="sm:text-sm text-xs text-gray1 font-medium lg:whitespace-nowrap lg:truncate lg:max-w-[113px]">
            Xiemen Manufacturer Lettbutikk
          </p>
        </li>
        <li className="w-full flex items-center gap-1.5 border-b border-gray4 md:pl-5 md:pr-4 px-3 py-4">
          <a
            href="#"
            className="flex whitespace-nowrap items-center gap-1.5 text-gray2 text-sm font-medium"
          >
            <Pulse size={20} className="text-blue2" />
            <span>Winter order</span>
            <CaretRight size={14} />
          </a>
          <p className="sm:text-sm text-xs text-gray1 font-medium lg:whitespace-nowrap lg:truncate lg:max-w-[113px]">
            Xiemen Manufacturer Lettbutikk
          </p>
        </li>
        <li className="w-full flex items-center gap-1.5 border-b border-transparent md:pl-5 md:pr-4 px-3 py-4">
          <a
            href="#"
            className="flex whitespace-nowrap items-center gap-1.5 text-gray2 text-sm font-medium"
          >
            <SpinnerGap size={20} className="text-orange" />
            <span>Winter order</span>
            <CaretRight size={14} />
          </a>
          <p className="sm:text-sm text-xs text-gray1 font-medium lg:whitespace-nowrap lg:truncate lg:max-w-[113px]">
            Xiemen Manufacturer Lettbutikk
          </p>
        </li>
      </ul>
    </div>
    <div className="w-full overflow-hidden">
      <CalendarChart />
    </div>
  </div>
  )
}

export default RangeCalendarChart