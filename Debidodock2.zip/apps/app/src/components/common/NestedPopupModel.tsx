import { Dialog, DialogPanel, } from '@headlessui/react'
import { useEffect } from 'react'

interface DialogProps{
    showModel: boolean;
    hideModel: (value: boolean) => void;
    children: React.ReactNode;
    panelClass?: string;  

}

export default function NestedPopupModel({showModel, hideModel, children, panelClass=""}:DialogProps) {

    useEffect(() => {
        if (showModel)  hideModel(true);
    },[showModel])

  function close() {
    hideModel(false)
  }


  return (
    <>
      <Dialog open={showModel} as="div" className="relative z-[60] focus:outline-none" onClose={close}>
        <div className="fixed inset-0 z-[60px] w-screen overflow-y-auto bg-black4">
          <div className="flex min-h-full items-center justify-center">
            <DialogPanel
              transition className={panelClass + " w-full rounded-xl border border-gray4 bg-black1 backdrop-blur-2xl duration-300 ease-out data-[closed]:transform-[scale(95%)] data-[closed]:opacity-0"}>
                {children}
            </DialogPanel>
          </div>
        </div>
      </Dialog>
    </>
  )
}
