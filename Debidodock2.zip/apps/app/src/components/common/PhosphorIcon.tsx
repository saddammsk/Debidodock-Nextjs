import React from "react";
import * as PhosphorIcons from "phosphor-react";
import { IconProps } from "@phosphor-icons/react";

export type PhosphorIconName = keyof typeof PhosphorIcons;

interface PhosphorIconProps {
  name: PhosphorIconName;
  size?: number;
  weight?: IconProps["weight"];
  className?: string;
}

const PhosphorIcon: React.FC<PhosphorIconProps> = ({
  name,
  size = 18,
  weight = "fill",
  className,
}) => {
  const IconComponent = PhosphorIcons[name] as React.ElementType;

  if (!IconComponent) {
    return null;
  }

  return <IconComponent size={size} weight={weight} className={className} />;
};

export default PhosphorIcon;
