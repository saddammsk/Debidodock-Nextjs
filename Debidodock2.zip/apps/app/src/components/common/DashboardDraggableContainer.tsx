import React, { Fragment } from 'react';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  useSensors,
  useSensor,
} from '@dnd-kit/core';
import { SortableContext, useSortable, arrayMove } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { DotsSixVertical } from '@phosphor-icons/react';
import DashboardDraggableCards from './DashboardDraggableCards';
import DashboardPurchaseOrdersActive from './DashboardPurchaseOrdersActive';
import { BankBalanceChart } from '../charts/BankBalanceChart';
import OverviewCards from './OverviewCards';

const DraggableHandle: React.FC = () => (
  <button
    className="text-gray-2 cursor-grab active:cursor-grabbing transition-all duration-300 hover:text-gray-1 w-[30px] h-[30px] flex items-center justify-center"
    aria-label="Drag handle" 
  >
    <DotsSixVertical size={20} />
  </button>
);

const DraggableCard = ({ id, children }: { id: string; children: React.ReactNode }) => {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition: transition || 'transform 0.2s ease', 
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      role="div"
      className="bg-gray-800 text-white relative rounded-md shadow-md flex justify-between items-center"
    >
      <Fragment>{children}</Fragment>
      <div {...listeners} id={`handle-${id}`} className="absolute top-4 right-3">
        <DraggableHandle />
      </div>
    </div>
  );
};

const DashboardDraggableContainer = () => {
  const [items, setItems] = React.useState([
    { id: '1', content:  <OverviewCards /> },
    { id: '2', content: <BankBalanceChart /> },
    { id: '3', content: <DashboardDraggableCards /> },
    { id: '4', content: <DashboardPurchaseOrdersActive /> },
  ]);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor)
  );

  const handleDragEnd = (event: any) => {
    const { active, over } = event;

    if (active.id !== over.id) {
      setItems((prevItems) => {
        const oldIndex = prevItems.findIndex((item) => item.id === active.id);
        const newIndex = prevItems.findIndex((item) => item.id === over.id);
        return arrayMove(prevItems, oldIndex, newIndex);
      });
    }
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragEnd={handleDragEnd}
    >
      <SortableContext items={items.map((item) => item.id)}>
        <div className="w-full">
          {items.map((item) => (
            <Fragment key={item.id}>
              <DraggableCard id={item.id}>{item.content}</DraggableCard>
            </Fragment>
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
};

export default DashboardDraggableContainer;
