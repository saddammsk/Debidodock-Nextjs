import * as React from "react";
import { ArrowUp, DotsSixVertical } from "@phosphor-icons/react";
import OverviewChart from "../charts/OverviewChart";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  useSensors,
  useSensor,
} from "@dnd-kit/core";
import { SortableContext, useSortable, arrayMove } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";


const DraggableHandle: React.FC = () => (
  <button
    className="text-gray-2 cursor-grab active:cursor-grabbing transition-all duration-300 hover:text-gray-1 w-[30px] h-[30px] flex items-center justify-center"
    aria-label="Drag handle" 
  >
    <DotsSixVertical size={20} />
  </button>
);


// Chart Data
const chartsData = [
  {
    name: "Revenue",
    price: "439k",
    percentage: "12%",
    increment: "+130k",
    chartData: {
      label: "Revenue",
      dataset: [
        { Revenue: 186 },
        { Revenue: 305 },
        { Revenue: 237 },
        { Revenue: 173 },
        { Revenue: 209 },
        { Revenue: 444 },
      ],
    },
  },
  {
    name: "Net profit",
    price: "49k",
    percentage: "20%",
    increment: "+30k",
    chartData: {
      label: "NetProfit",
      dataset: [
        { NetProfit: 186 },
        { NetProfit: 305 },
        { NetProfit: 237 },
        { NetProfit: 463 },
        { NetProfit: 209 },
        { NetProfit: 214 },
      ],
    },
  },
  {
    name: "Revenue",
    price: "439k",
    percentage: "15%",
    increment: "+130k",
    chartData: {
      label: "Revenue",
      dataset: [
        { Revenue: 186 },
        { Revenue: 305 },
        { Revenue: 237 },
        { Revenue: 753 },
        { Revenue: 209 },
        { Revenue: 514 },
      ],
    },
  },
  {
    name: "Revenue",
    price: "439k",
    percentage: "15%",
    increment: "+200k",
    chartData: {
      label: "Revenue",
      dataset: [
        { Revenue: 136 },
        { Revenue: 305 },
        { Revenue: 237 },
        { Revenue: 243 },
        { Revenue: 659 },
        { Revenue: 614 },
      ],
    },
  },
];

const Card = ({ id, children }: { id: string; children?: React.ReactNode }) => {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      role="div"
      className="bg-black3 text-white relative rounded-xl shadow-md"
    >
     <React.Fragment>{children}</React.Fragment>
          <div {...listeners} id={`handle-${id}`} className="absolute top-2 right-2">
            <DraggableHandle />
      </div>
    </div>
  );
};

const OverviewCards = () => {
  const [items, setItems] = React.useState(
    chartsData.map((chart, index) => ({
      id: `${chart.name}-${index}`,
      content: (
        <div className="w-full bg-black3 rounded-xl border border-gray4">
          <div className="p-6 pb-0">
            <h4 className="text-sm text-gray2 font-medium">{chart.name}</h4>
            <div className="flex items-center justify-between gap-6 flex-wrap">
              <h2 className="md:text-3xll text-2xl font-semibold text-gray1 my-2">
                {chart.price}
              </h2>
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center font-medium gap-0.5 bg-green2 text-green1 rounded-md p-1.5 text-xs">
                  <ArrowUp size={14} />
                  <span>{chart.percentage}</span>
                </div>
                <span className="text-gray2 text-xs font-medium">
                  {chart.increment}
                </span>
              </div>
            </div>
          </div>

          {/* Chart Component */}
          <div className="chart-card">
            <OverviewChart chartData={chart.chartData} />
          </div>
        </div>
      ),
    }))
  );

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor)
  );

  const handleDragEnd = (event: any) => {
    const { active, over } = event;

    if (active.id !== over.id) {
      setItems((prevItems) => {
        const oldIndex = prevItems.findIndex((item) => item.id === active.id);
        const newIndex = prevItems.findIndex((item) => item.id === over.id);
        return arrayMove(prevItems, oldIndex, newIndex);
      });
    }
  };

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={items.map((item) => item.id)}>
        <div className="w-full grid lg:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-3">
          {items.map((item) => (
            <div key={item.id}>
              <Card id={item.id}>{item.content}</Card>
            </div>
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
};

export default OverviewCards;
