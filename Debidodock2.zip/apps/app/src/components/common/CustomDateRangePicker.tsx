import * as React from "react";
import { format, subDays, startOfDay, endOfDay } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { DateRange } from "react-day-picker";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useRouter } from "@tanstack/react-router";

export function CustomDateRangePicker({
  className,
}: React.HTMLAttributes<HTMLDivElement>) {
  const router = useRouter();
  const [date, setDate] = React.useState<DateRange | undefined>();
  const [selectedRange, setSelectedRange] = React.useState<string | null>(null);

  const setPredefinedRange = (range: "today" | "yesterday" | "last7" | "last30" | "last90") => {
    const today = startOfDay(new Date());
    let from: Date, to: Date;

    switch (range) {
      case "today":
        from = today;
        to = endOfDay(today);
        break;
      case "yesterday":
        from = startOfDay(subDays(today, 1));
        to = endOfDay(subDays(today, 1));
        break;
      case "last7":
        from = startOfDay(subDays(today, 7));
        to = endOfDay(today);
        break;
      case "last30":
        from = startOfDay(subDays(today, 30));
        to = endOfDay(today);
        break;
      case "last90":
        from = startOfDay(subDays(today, 90));
        to = endOfDay(today);
        break;
    }

    setDate({ from, to });
    setSelectedRange(range);
    updateQueryParams(from, to); 
  };

  const resetSelection = () => {
    setDate(undefined);
    setSelectedRange(null);
    updateQueryParams(null, null); 
  };

  const updateQueryParams = (from: Date | null, to: Date | null) => {
    const fromDate = from ? format(from, "yyyy-MM-dd") : null;
    const toDate = to ? format(to, "yyyy-MM-dd") : null;

    router.navigate({
      to: "/dashboard",
      search: {
        from: fromDate,
        to: toDate,
      },
      replace: true, 
    });
  };

  const handleDateSelect = (selectedDate: DateRange) => {
    if (selectedDate && selectedDate.from) {
      if (!selectedDate.to) {
        setDate({ from: selectedDate.from, to: undefined });
        return;
      }

      setDate(selectedDate);
      updateQueryParams(selectedDate.from, selectedDate.to);
    } else {
      console.error("Invalid date range selected:", selectedDate); 
    }
  };

  return (
    <div className={cn("grid gap-2", className)}>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn(
              "w-fit justify-start text-xs text-left px-3 h-9 font-normal bg-gray3",
              !date && "text-muted-foreground"
            )}
          >
            <CalendarIcon className="mr-2" />
            {date?.from ? (
              date.to ? (
                <>
                  {format(date.from, "LLL dd, y")} - {format(date.to, "LLL dd, y")}
                </>
              ) : (
                format(date.from, "LLL dd, y")
              )
            ) : (
              <span>Custom</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-2 bg-gray3" align="start">
          <div className="flex flex-row space-y-2">
            <div className="flex text-start pt-6 flex-col">
              <Button
                className={cn(
                  "w-fit justify-start text-xs text-left px-3 h-auto font-normal !bg-gray3",
                  selectedRange === "today" ? "text-gray1" : "text-gray2 hover:text-gray1"
                )}
                onClick={() => setPredefinedRange("today")}
              >
                Today
              </Button>
              <Button
                className={cn(
                  "w-fit justify-start text-xs text-left px-3 h-auto font-normal !bg-gray3",
                  selectedRange === "yesterday" ? "text-gray1" : "text-gray2 hover:text-gray1"
                )}
                onClick={() => setPredefinedRange("yesterday")}
              >
                Yesterday
              </Button>
              <Button
                className={cn(
                  "w-fit justify-start text-xs text-left px-3 h-auto font-normal !bg-gray3",
                  selectedRange === "last7" ? "text-gray1" : "text-gray2 hover:text-gray1"
                )}
                onClick={() => setPredefinedRange("last7")}
              >
                Last 7 Days
              </Button>
              <Button
                className={cn(
                  "w-fit justify-start text-xs text-left px-3 h-auto font-normal !bg-gray3",
                  selectedRange === "last30" ? "text-gray1" : "text-gray2 hover:text-gray1"
                )}
                onClick={() => setPredefinedRange("last30")}
              >
                Last 30 Days
              </Button>
              <Button
                className={cn(
                  "w-fit justify-start text-xs text-left px-3 h-auto font-normal !bg-gray3",
                  selectedRange === "last90" ? "text-gray1" : "text-gray2 hover:text-gray1"
                )}
                onClick={() => setPredefinedRange("last90")}
              >
                Last 90 Days
              </Button>
              <Button
                className="w-fit mt-auto justify-start text-xs text-left text-gray2 hover:text-gray1 px-3 h-auto font-normal !bg-gray3"
                onClick={resetSelection}
              >
                Reset
              </Button>
            </div>
            <Calendar
              initialFocus
              mode="range"
              defaultMonth={date?.from}
              selected={date}
              onSelect={handleDateSelect}
              numberOfMonths={2}
            />
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
