import { Button, Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/react';
import { DotsThreeVertical } from '@phosphor-icons/react';
import { useRouter } from '@tanstack/react-router';
import { startOfDay, subDays, endOfDay, format } from 'date-fns';
import React from 'react';

export default function RangeCalendarDropdown() {
  const router = useRouter();
  const [selectedRange, setSelectedRange] = React.useState<string | null>(null);

  const updateQueryParams = (from: Date | null, to: Date | null) => {
    const fromDate = from ? format(from, 'yyyy-MM-dd') : null;
    const toDate = to ? format(to, 'yyyy-MM-dd') : null;

    router.navigate({
      to: '/dashboard', 
      search: {
        from: fromDate,
        to: toDate,
      },
      replace: true,
    });
  };

  const setPredefinedRange = (range: string) => {
    const today = startOfDay(new Date());
    let from: Date, to: Date;

    switch (range) {
      case '7d':
        from = startOfDay(subDays(today, 7));
        to = endOfDay(today);
        break;
      case '2W':
        from = startOfDay(subDays(today, 14));
        to = endOfDay(today);
        break;
      case '1W':
        from = startOfDay(subDays(today, 7));
        to = endOfDay(today);
        break;
      case 'Q1':
        from = startOfDay(new Date(today.getFullYear(), 0, 1));
        to = endOfDay(new Date(today.getFullYear(), 2, 31)); 
        break;
      case 'Q2':
        from = startOfDay(new Date(today.getFullYear(), 3, 1));
        to = endOfDay(new Date(today.getFullYear(), 5, 30)); 
        break;
      case 'Q3':
        from = startOfDay(new Date(today.getFullYear(), 6, 1));
        to = endOfDay(new Date(today.getFullYear(), 8, 30));
        break;
      case 'Q4':
        from = startOfDay(new Date(today.getFullYear(), 9, 1)); 
        to = endOfDay(new Date(today.getFullYear(), 11, 31)); 
        break;
      case 'H1':
        from = startOfDay(new Date(today.getFullYear(), 0, 1));
        to = endOfDay(new Date(today.getFullYear(), 5, 30)); 
        break;
      case 'H2':
        from = startOfDay(new Date(today.getFullYear(), 6, 1)); 
        to = endOfDay(new Date(today.getFullYear(), 11, 31));
        break;
      case 'YTD':
        from = startOfDay(new Date(today.getFullYear(), 0, 1)); 
        to = endOfDay(today);
        break;
      default:
        return; 
    }

    setSelectedRange(range);

    updateQueryParams(from, to);
  };

  return (
    <Menu as="ul" className="items-center relative rounded-md border bg-black1 border-gray5 lg:hidden flex p-1">
      <MenuButton>
        <DotsThreeVertical size={20} />
      </MenuButton>
      <MenuItems as="li" className="absolute z-50 top-8 overflow-hidden flex flex-col items-center bg-gray3 rounded-md border border-gray5">
        {['7d', '2W', '1W', 'Q1', 'Q2', 'Q3', 'Q4', 'H1', 'H2', 'YTD'].map((range) => (
          <MenuItem key={range} as="li" className="w-full">
            <Button
              className={`bg-transparent p-2 w-full px-3 rounded-lg text-xs font-medium uppercase ${selectedRange === range ? 'text-gray1 border-gray5' : 'text-gray2 border-transparent'} hover:text-gray1 hover:bg-black2 border ${selectedRange === range ? 'bg-black2' : 'bg-transparent'}`}
              onClick={() => setPredefinedRange(range)}
            >
              {range}
            </Button>
          </MenuItem>
        ))}
      </MenuItems>
    </Menu>
  );
}
