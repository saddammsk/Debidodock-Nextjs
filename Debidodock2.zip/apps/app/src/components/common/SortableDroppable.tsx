/* eslint-disable @typescript-eslint/no-explicit-any */
import React from "react";
import {
  SortableContext,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";

type SortableDroppableProps = {
  children: React.ReactNode;
  items: any[];
};

export default function SortableDroppable({
  children,
  items,
}: SortableDroppableProps) {
  return (
    <SortableContext items={items} strategy={verticalListSortingStrategy}>
      {children}
    </SortableContext>
  );
}
