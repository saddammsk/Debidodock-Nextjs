import { ReactNode } from 'react';

interface SearchProps{
  placeholder: string;
  classInput?: string;
  classIcon?: string;
  icon?: ReactNode;
  
}


const SearchField = ({placeholder, classInput='', classIcon='', icon}: SearchProps) => {


  return (
    <form>
    <label htmlFor="search-input" className="relative block h-full overflow-hidden">
      {icon && <span className={classIcon + "absolute top-1/2 -translate-y-1/2 left-2.5"}>{icon}</span>}
    <input type="text" id="search-input" placeholder={placeholder} className={classInput + " text-xs border placeholder:text-gray2 rounded-md bg-gray6 focus:border-blue4 font-normal placeholder:font-light placeholder:text-xs w-full h-9 outline-none ring-0 text-gray2"} />
    </label>
  </form>
  )
}

export default SearchField