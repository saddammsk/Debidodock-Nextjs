import { Dialog, DialogPanel, } from '@headlessui/react'

interface DialogProps{
    showModel: boolean;
    hideModel: (value: boolean) => void;
    children: React.ReactNode;
    panelClass?: string;  

}

export default function PopupModel({showModel, hideModel, children, panelClass=""}:DialogProps) {

  if (!showModel) return null;

  function close() {
    hideModel(false)
  }


  return (
    <>
      <Dialog open={showModel} as="div" className="relative z-50 focus:outline-none" onClose={close}>
        <div className="fixed inset-0 z-50 w-screen overflow-y-auto bg-black4">
          <div className="flex min-h-full items-center justify-center p-2">
            <DialogPanel
              transition className={panelClass + " w-full rounded-xl border border-gray4 bg-black1 backdrop-blur-2xl duration-300 ease-out data-[closed]:transform-[scale(95%)] data-[closed]:opacity-0"}>
                {children}
            </DialogPanel>
          </div>
        </div>
      </Dialog>
    </>
  )
}
