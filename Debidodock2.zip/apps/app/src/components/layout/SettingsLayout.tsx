import { Button } from "@debido/ui/components/button";
import { useGlobalContext } from "../../context/GlobalContext";
import { useEffect } from "react";
import { List } from "@phosphor-icons/react";

interface SettingsProps{
    children: React.ReactNode;
}

const SettingsLayout = ({children}: SettingsProps) => {

    
    const {toggleSidebar,setToggleSidebar} = useGlobalContext();

    useEffect(()=>{
      (toggleSidebar)?document.body.classList.add("overflow-hidden"): document.body.classList.remove("overflow-hidden");
    },[toggleSidebar])


  return (
    <div className="min-h-screen w-full flex bg-black1 text-white">
         <section className="bg-black2 w-full rounded-lg border border-gray4 mt-2 lg:mr-2">
         <div className="w-full max-w-[768px] mx-auto">
         <div className="w-full lg:py-10 p-4">
         <div className="w-full flex items-center justify-end">
          <Button onClick={()=> setToggleSidebar(true)} className="bg-transparent lg:hidden flex hover:bg-transparent px-0.5 mb-6">
          <List size={20} />
         </Button>
          </div>
        {children}
        </div>
        </div>
        </section>
    </div>
  )
}

export default SettingsLayout