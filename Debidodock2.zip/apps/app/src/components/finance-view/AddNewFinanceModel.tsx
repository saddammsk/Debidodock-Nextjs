import { Button } from "@debido/ui/components/button";
import PopupModel from "../common/PopupModel";
import { X } from "@phosphor-icons/react";
import AddNewForm from "./AddNewForm";

interface ModelProps {
  addNewFinance: boolean;
  setAddNewFinance: (addNewFinance: boolean) => void;
}

const AddNewFinanceModel = ({
  addNewFinance,
  setAddNewFinance,
}: ModelProps) => {
  return (
    <PopupModel
      showModel={addNewFinance}
      hideModel={setAddNewFinance}
      panelClass="max-w-[510px] bg-black2 overflow-hidden"
    >
      <div className="w-full">
        {/* Model Head */}
        <div className="w-full md:px-6 px-4 flex items-center py-6">
          <h2 className="text-base text-gray1">Adobe</h2>
          <Button
            onClick={() => setAddNewFinance(!addNewFinance)}
            className="!bg-transparent -mt-3  ml-auto px-1 text-gray2 hover:text-gray1"
          >
            <X size={14} />
          </Button>
        </div>

        {/*Model Body */}
        <div className="w-full md:px-6 px-3">
          <AddNewForm />
        </div>
      </div>
    </PopupModel>
  );
};

export default AddNewFinanceModel;
