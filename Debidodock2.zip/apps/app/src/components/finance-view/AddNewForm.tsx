"use client";

import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { DatePicker } from '../common/DatePicker'
import { Button } from "@debido/ui/components/button";

export default function AddNewForm() {
  const [formData, setFormData] = useState({
    costName: "",
    amount: "",
    currency: "NOK",
    includesVAT: false,
    recurrence: "Weekly",
    startDate: null,
    endDate: null,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { id, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [id]: type === "checkbox" ? checked : value,
    }));
  };


  const handleRecurrenceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prevData) => ({
      ...prevData,
      recurrence: e.target.id,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation logic
    const errors = [];
    if (!formData.costName) errors.push("Cost name is required.");
    if (!formData.amount || isNaN(Number(formData.amount))) errors.push("Valid amount is required.");
    if (!formData.startDate) errors.push("Start date is required.");
    if (!formData.endDate) errors.push("End date is required.");
    if (errors.length > 0) {
      console.error("Form validation failed:", errors);
      alert(`Validation errors:\n- ${errors.join("\n- ")}`);
      return;
    }

    console.log("Form submitted successfully with data:", formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="w-full">
        {/* Cost Name */}
        <div className="w-full mb-4">
          <label htmlFor="costName" className="mb-1.5 block text-xs text-gray2">
            Cost name
          </label>
          <input
            type="text"
            id="costName"
            placeholder="Adobe"
            className="h-10 text-gray1 bg-gray6 placeholder:text-gray1 text-sm rounded-md border border-gray7 w-full px-4"
            value={formData.costName}
            onChange={handleInputChange}
          />
        </div>

        {/* Amount */}
        <div className="w-full flex gap-5 items-center">
          <div className="w-full mb-4">
            <label htmlFor="amount" className="mb-1.5 block text-xs text-gray2">
              Amount
            </label>
            <div className="relative flex items-center">
              <input
                type="text"
                id="amount"
                placeholder="399"
                className="h-10 text-gray1 bg-gray6 placeholder:text-gray1 text-sm rounded-md border border-gray7 w-full px-4"
                value={formData.amount}
                onChange={handleInputChange}
              />
              <div className="flex items-center absolute right-2">
                <select
                  id="currency"
                  className="text-gray2 px-2 inline-flex justify-center items-center bg-gray6 text-xs font-medium"
                  value={formData.currency}
                  onChange={handleInputChange}
                >
                  <option value="NOK">NOK</option>
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                </select>
              </div>
            </div>
          </div>

          {/* Includes VAT */}
          <div className="flex gap-2">
            <p className="text-xs text-gray2 font-medium whitespace-nowrap">Includes VAT</p>
            <label htmlFor="includesVAT" className="relative flex items-center">
              <input
                type="checkbox"
                id="includesVAT"
                className="peer bg-blue2 border border-blue5 appearance-none w-7 h-4 rounded-full m-0 p-0"
                checked={formData.includesVAT}
                onChange={handleInputChange}
              />
              <span className="w-3 h-3 bg-white peer-checked:translate-x-3.5 translate-x-0.5 block rounded-full absolute top-1/2 -translate-y-1/2 transition-transform"></span>
            </label>
          </div>
        </div>

        {/* Recurrence */}
        <div className="w-full overflow-auto">
          <p className="text-xs text-gray2 mb-1.5">Recurrence</p>
          <div
            className="inline-flex items-center gap-1 bg-black1 border border-gray5 rounded-md"
            role="group"
            aria-label="Recurrence"
          >
            {["Weekly", "Monthly", "Yearly", "Once", "Per order"].map((recurrence) => (
              <div key={recurrence}>
                <input
                  type="radio"
                  className="peer btn-check appearance-none hidden"
                  name="recurrence"
                  id={recurrence}
                  checked={formData.recurrence === recurrence}
                  onChange={handleRecurrenceChange}
                />
                <label
                  className="peer-checked:bg-black2 cursor-pointer peer-checked:text-gray1 hover:text-gray1 peer-checked:border-gray5 transition-all duration-300 hover:bg-black2 hover:border-gray5 rounded-md border border-transparent whitespace-nowrap text-gray2 text-xs font-medium sm:px-5 px-2 py-2 sm:py-3 block"
                  htmlFor={recurrence}
                >
                  {recurrence}
                </label>
              </div>
            ))}
          </div>
        </div>

        {/* Date Picker */}
        <div className="w-full mt-4">
          <p className="text-xs text-gray2 mb-1.5">Date</p>
          <div className="flex items-center gap-3">
            <DatePicker
              dateLabel="Start date"
              classBtn="px-2 h-8 !bg-transparent"
            />
            <ArrowRight size={16} />
            <DatePicker
              dateLabel="End date"
              classBtn="px-2 h-8 !bg-transparent"
            />
          </div>
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          className="w-full bg-blue6 text-xs text-white py-5 mt-10 mb-5"
        >
          Create
        </Button>
      </div>
    </form>
  );
}
