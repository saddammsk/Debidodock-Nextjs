import CostsTab from "./tabs-view/CostsTab";
import InvestmentsTab from "./tabs-view/InvestmentsTab";
import LoansTab from "./tabs-view/LoansTab";
import FinanceSidebar from "./FinanceSidebar";

interface TabsViewProps{
tabState: string;
fadeState: boolean;
}

const FinanceTabsListsView = ({tabState, fadeState}: TabsViewProps) => {


return (
<div className="w-full flex h-full border-t md:border-none">
<div className="w-full h-full">

    {/* Costs Panel */}
    {tabState==="costs-tab" &&
    <CostsTab fadeState={fadeState}/>
    }

    {/* Loans Cost Panel */}
    {tabState==="loans-tab" &&
    <LoansTab fadeState={fadeState}/>
    }

    {/* Investments Panel */}
    {tabState==="investments-tab" &&
    <InvestmentsTab fadeState={fadeState}/>
    }

</div>

{/* Finance Sidebar */}
<FinanceSidebar/>


</div>
)}

export default FinanceTabsListsView