import { CaretDown, Path, PencilSimple, ToggleRight } from "@phosphor-icons/react";
import CostsTab from "./tabs-view/CostsTab";
import { Button } from "@debido/ui/components/button";
import InvestmentsTab from "./tabs-view/InvestmentsTab";
import LoansTab from "./tabs-view/LoansTab";
import { useGlobalContext } from "../../context/GlobalContext";

interface TabsViewProps{
tabState: string;
fadeState: boolean;
}

const TabsListsView = ({tabState, fadeState}: TabsViewProps) => {
    const {toggleEditSidebar} = useGlobalContext();


return (
<div className="w-full flex  h-full">
<div className="w-full h-full">

    {/* Costs Panel */}
    {tabState==="costs-tab" &&
    <CostsTab fadeState={fadeState}/>
    }

    {/* Loans Cost Panel */}
    {tabState==="loans-tab" &&
    <LoansTab fadeState={fadeState}/>
    }

    {/* Investments Panel */}
    {tabState==="investments-tab" &&
    <InvestmentsTab fadeState={fadeState}/>
    }

</div>
<div className={`${toggleEditSidebar ? "block" : "hidden"}` + " w-full max-w-[363px] bg-black2 border border-gray4 h-full"}>
    <div className="w-full pl-6 py-5 pr-4">
    <div className="w-full flex justify-between">
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
    <ToggleRight size={20} className="text-green1" />
    <h2>Adobe Creative</h2>
    </div>
    <Button className="text-gray2 !bg-transparent shadow-none text-xs gap-1 font-medium">
    <PencilSimple size={16}/>
        Edit
    </Button>
    </div>

    <ul className="w-full mt-[30px] flex items-start justify-center gap-4 flex-col mb-6">
        <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">Recurrence</p>
            <p className="border border-gray4 text-xs text-gray2 px-2.5 py-1.5 rounded-full">Monthly</p>
        </li>
        <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">Amount</p>
            <p className="border border-gray4 text-xs text-gray2 px-2.5 py-1.5 rounded-full">399</p>
        </li>
        <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">Status</p>
            <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4"><div className="bg-green1 rounded-full w-2 h-2"></div><p className="text-xs text-gray2 font-medium">Active</p></div>
        </li>
        <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">Currency</p>
            <p className="border border-gray4 text-xs text-gray2 px-2.5 py-1.5 rounded-full">NOK</p>
        </li>
    </ul>
    </div>
    {/* Timeline */}

    <div className="w-full pl-6 py-4 pr-4 border-t border-gray4">
    <div className="w-full flex justify-between">
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
    <Path size={20} className="text-gray2" />
    <h2>Timeline</h2>
    </div>
    <Button className="text-gray2 !bg-transparent shadow-none text-xs gap-1 font-medium">
    <CaretDown size={16}/>
    </Button>
    </div>

    <ul className="flex flex-col gap-8 list-disc text-gray2 pl-7">
        <li className="relative">
            <p className="text-xs text-gray1 font-medium">SO-03 sent from Xiemen Manufacturer</p>
            <p className="text-xs text-gray2 font-medium">25 Jan 2024, 16:30</p>
        </li>
        <li className="flex borde-l w-[1px] -ml-4 -mt-9 -mb-7 border-gray2 opacity-20 bg-gray2 h-10">

        </li>
        <li>
            <p className="text-xs text-gray1 font-medium">SO-03 sent from Xiemen Manufacturer</p>
            <p className="text-xs text-gray2 font-medium">25 Jan 2024, 16:30</p>
        </li>
    </ul>



    </div>

</div>

</div>
)}

export default TabsListsView