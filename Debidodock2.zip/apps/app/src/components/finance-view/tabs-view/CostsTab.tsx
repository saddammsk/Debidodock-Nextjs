import { Button } from "@debido/ui/components/button";
import { CaretUpDown, ToggleRight, XCircle } from "@phosphor-icons/react";
import { useGlobalContext } from "../../../context/GlobalContext";
const CostsTab = ({fadeState}:{fadeState:boolean}) => {

  const {setToggleEditSidebar} = useGlobalContext();

  

  return (
    <div className={`${fadeState ? "opacity-0" : "opacity-100"}` + " w-full transition-opacity duration-200 "}>
    <ul>
      {/* Head | Sorting */}
      <li className="bg-black1 flex items-center justify-between px-6 py-2 h-auto border-b border-gray4"> 
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <ToggleRight size={20} className="text-green1" />
        <h2>Active</h2>
        </div>
        <Button className="flex bg-transparent hover:bg-transparent shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center gap-2 text-xs font-medium text-gray2">
        <CaretUpDown size={14}  />
        <h2>Sort</h2>
        </Button>
      </li>
      <Button onClick={()=>setToggleEditSidebar(true)} className="!bg-black2 gap-3 w-full flex flex-wrap sm:flex-row flex-col items-start sm:items-center justify-between px-6 py-2 h-auto border-b border-gray4"> 
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <ToggleRight size={20} className="text-green1" />
        <h2>Google</h2>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
            <div className="rounded-full inline-flex items-center border border-gray4">
              <div className="flex items-center gap-1.5 px-2.5 py-1.5 border-r border-gray5">
                <div className="bg-blue2 rounded-full w-2 h-2"></div>
                <p className="text-xs text-gray2 font-medium">Recurring</p>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1.5">
              <p className="text-xs text-gray2 font-medium">Monthly</p>
              </div>
            </div>
            <div className="rounded-full inline-flex px-2.5 py-1.5 items-center border border-gray4">
              <p className="text-xs text-gray2 font-medium">399 kr</p>
              </div>

              <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">
              <div className="bg-green1 rounded-full w-2 h-2"></div>
              <p className="text-xs text-gray2 font-medium">Active</p>
              </div>
          </div>
      </Button>
      <Button onClick={()=>setToggleEditSidebar(true)} className="!bg-black2 gap-3 w-full flex flex-wrap sm:flex-row flex-col items-start sm:items-center justify-between px-6 py-2 h-auto border-b border-gray4"> 
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <ToggleRight size={20} className="text-green1" />
        <h2>Adobe Creative</h2>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
            <div className="rounded-full inline-flex items-center border border-gray4">
              <div className="flex items-center gap-1.5 px-2.5 py-1.5 border-r border-gray5">
                <div className="bg-blue2 rounded-full w-2 h-2"></div>
                <p className="text-xs text-gray2 font-medium">Recurring</p>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1.5">
              <p className="text-xs text-gray2 font-medium">Monthly</p>
              </div>
            </div>
            <div className="rounded-full inline-flex px-2.5 py-1.5 items-center border border-gray4">
              <p className="text-xs text-gray2 font-medium">399 kr</p>
              </div>

              <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">
              <div className="bg-green1 rounded-full w-2 h-2"></div>
              <p className="text-xs text-gray2 font-medium">Active</p>
              </div>
          </div>
      </Button>
      <Button onClick={()=>setToggleEditSidebar(true)} className="!bg-black2 gap-3 w-full flex flex-wrap sm:flex-row flex-col items-start sm:items-center justify-between px-6 py-2 h-auto border-b border-gray4"> 
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <ToggleRight size={20} className="text-green1" />
        <h2>Shopify</h2>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
            <div className="rounded-full inline-flex items-center border border-gray4">
              <div className="flex items-center gap-1.5 px-2.5 py-1.5 border-r border-gray5">
                <div className="bg-blue2 rounded-full w-2 h-2"></div>
                <p className="text-xs text-gray2 font-medium">Recurring</p>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1.5">
              <p className="text-xs text-gray2 font-medium">Monthly</p>
              </div>
            </div>
            <div className="rounded-full inline-flex px-2.5 py-1.5 items-center border border-gray4">
              <p className="text-xs text-gray2 font-medium">399 kr</p>
              </div>

              <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">
              <div className="bg-green1 rounded-full w-2 h-2"></div>
              <p className="text-xs text-gray2 font-medium">Active</p>
              </div>
          </div>
      </Button>
    </ul>
    {/* Ended list */}
    <ul>
      <li className="bg-black1 flex items-center justify-between px-6 py-2 h-auto border-b border-gray4"> 
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <XCircle weight="fill" size={20} className="text-gray2" />
        <h2>Ended</h2>
        </div>
        <Button className="flex bg-transparent hover:bg-transparent shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center gap-2 text-xs font-medium text-gray2">
        <CaretUpDown size={14}  />
        <h2>Sort</h2>
        </Button>
      </li>
      <Button onClick={()=>setToggleEditSidebar(true)} className="!bg-black2 w-full flex flex-wrap sm:flex-row flex-col gap-3 items-start sm:items-center justify-between px-6 py-2 h-auto border-b border-gray4"> 
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <XCircle weight="fill" size={20} className="text-gray2" />
        <h2>Google</h2>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
            <div className="rounded-full inline-flex items-center border border-gray4">
              <div className="flex items-center gap-1.5 px-2.5 py-1.5 border-r border-gray5">
                <div className="bg-blue2 rounded-full w-2 h-2"></div>
                <p className="text-xs text-gray2 font-medium">Recurring</p>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1.5">
              <p className="text-xs text-gray2 font-medium">Monthly</p>
              </div>
            </div>
            <div className="rounded-full inline-flex px-2.5 py-1.5 items-center border border-gray4">
              <p className="text-xs text-gray2 font-medium">399 kr</p>
              </div>

              <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">
              <div className="bg-red1 rounded-full w-2 h-2"></div>
              <p className="text-xs text-gray2 font-medium">Ended</p>
              </div>
          </div>
      </Button>
      
    </ul>
  </div>
  )
}

export default CostsTab