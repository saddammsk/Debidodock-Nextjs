import ProductsTab from "./tabs-view/ProductsTab";
import InventoryTab from "../products-view/tabs-view/InventoryTab";
import ProductsSidebar from "./ProductsSidebar";

interface TabsViewProps{
tabState: string;
fadeState: boolean;
}

const ProductsTabsListsView = ({tabState, fadeState}: TabsViewProps) => {


return (
    
    <div className="w-full flex h-full">
    <div className="w-full h-full">
    {/* Products Panel */}
    {tabState==="products-tab" &&
    <ProductsTab fadeState={fadeState} />
    }

    {/* Inventory Panel */}
    {tabState==="inventory-tab" &&
    <InventoryTab fadeState={fadeState} />
    }
    </div>

    {/* Right sidebar */}

    <ProductsSidebar/>
   
    </div>
)}

export default ProductsTabsListsView