import { Button } from "@debido/ui/components/button";
import { CaretUpDown, Check, MapPin, Warning } from "@phosphor-icons/react";
import { useEffect, useState } from "react";


const invertoryHjelsengliaData = [
    {id: '1',name:'Winter order', userImg: '/images/inventory-user-img.png', warning:true, warningfill: 'text-yellow1', sku:'VELO-M-DHD', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50', UnitCost: '50', MOQ: '0'},
    {id: '2',name:'Winter order', userImg: '/images/inventory-user-img.png', warning:false, warningfill: 'text-yellow1', sku:'VELO-M-DHD', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50', UnitCost: '50', MOQ: '0'},
    {id: '3',name:'Winter order', userImg: '/images/inventory-user-img.png', warning:false, warningfill: 'text-red1', sku:'VELO-M-DHD', Instock: '20', OnOrder: '30', DaysofStock: '40 days', LeadTime: '50', UnitCost: '50', MOQ: '0'},
    {id: '4',name:'Winter order', userImg: '/images/inventory-user-img.png', warning:true, warningfill: 'text-red1', sku:'VELO-M-DHD', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50', UnitCost: '50', MOQ: '0'},
    {id: '5',name:'Winter order', userImg: '/images/inventory-user-img.png', warning:false, warningfill: 'text-yellow1', sku:'VELO-M-DHD', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50', UnitCost: '50', MOQ: '0'},
    {id: '6',name:'Winter order', userImg: '/images/inventory-user-img.png', warning:true, warningfill: 'text-red1', sku:'VELO-M-DHD', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50', UnitCost: '50', MOQ: '0'},
 ]



const HjelsengliaTable = () => {

    const [isMasterChecked, setIsMasterChecked] = useState<boolean>(false);

    useEffect(() => {
      const masterCheckbox = document.getElementById('variants-checkbox-2') as HTMLInputElement;
      const checkboxes = document.querySelectorAll('#tbody1 input[type="checkbox"]') as NodeListOf<HTMLInputElement>;
  
      if (masterCheckbox && checkboxes) {
        checkboxes.forEach((checkbox) => {
          checkbox.checked = isMasterChecked;
        });
      }
    }, [isMasterChecked]);
  
    const handleMasterCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setIsMasterChecked(e.target.checked);
    };


  return (
    <div>
    <div className="flex bg-black1 items-center justify-between lg:px-6 px-4 h-11 border-b border-gray4"> 
    <div className="flex items-center gap-1 py-2.5 px-2 text-xs font-medium text-gray1">
    <MapPin weight="fill" size={16} className="text-gray2" />
    <h2 className="text-xs text-gray1">Hjelsenglia lager</h2>
    </div>
    <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent gap-2 shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
    <CaretUpDown size={16} />
    Sort
    </Button>
  </div>

  <div className="w-full overflow-x-auto">
    <table className="w-full">
      <thead className="w-full">
        <tr className="w-full border-b border-gray4">
          <th className="text-xs text-gray2 font-medium px-2 py-2.5">
            <div className="flex items-center gap-2">
              <label htmlFor="variants-checkbox-2" className="relative flex items-center justify-center">
            <input
             onChange={handleMasterCheckboxChange}
             checked={isMasterChecked}
             type="checkbox" id="variants-checkbox-2" className="peer rounded checked:bg-blue2 bg-transparent w-4 h-4 border border-gray5  appearance-none" />
            <Check size={10} className="peer-checked:block text-gray1 hidden absolute" />
            </label>
            Variants
            </div>
            </th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">SKU</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">In stock</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">On order</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">Days of stock</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">Lead time</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">Unit cost</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">MOQ</th>
        </tr>
        </thead>
        <tbody id="tbody1">
          {invertoryHjelsengliaData&&invertoryHjelsengliaData.map((item)=>(
              <tr key={item?.id} className="bg-black2 border-b border-gray4">
              <td scope="row" className="px-2 py-2.5">
                <div className="flex items-center gap-2">
                <label htmlFor={`${item?.id}`+'-checkbox-1'} className="relative flex items-center justify-center">
              <input type="checkbox" id={`${item?.id}`+'-checkbox-1'} className="peer rounded checked:bg-blue2 bg-transparent w-4 h-4 border border-gray5  appearance-none" />
              <Check size={10} className="peer-checked:block text-gray1 hidden absolute" />
              </label>
              <img src={item.userImg} alt="avator" className="w-6 h-6 rounded bg-cover" />
              <h3 className="lg:text-sm text-xs text-gray2 font-medium ml-1">{item?.name}</h3>
              {item?.warning&&
                <Warning size={16} weight="fill" className={`${item?.warningfill}`}/>
              }
                </div>
                </td>
                <td className="px-2 py-2.5">
                <h3 className="lg:text-sm text-xs text-gray2 font-medium uppercase whitespace-nowrap">{item?.sku}</h3>
                </td>
                <td className="px-2 py-2.5">
                <h3 className="lg:text-sm text-xs text-gray1 font-medium uppercase">{item?.Instock}</h3>
                </td>
                <td className="px-2 py-2.5">
                <h3 className={"lg:text-sm text-xs text-gray2 font-medium uppercase " + `${item?.OnOrder > '0' && 'underline' }`}>{item?.OnOrder}</h3>
                </td>
                <td className="px-2 py-2.5">
                <h3 className="lg:text-sm text-xs text-gray1 font-medium uppercase whitespace-nowrap">{item?.DaysofStock}</h3>
                </td>
                <td className="px-2 py-2.5">
                  <div className="bg-gray6 rounded-md inline-flex py-2 gap-5  items-center px-3">
                <h3 className="text-xs text-gray1 font-medium uppercase">{item?.LeadTime}</h3>
                <h3 className="text-xs text-gray2 font-medium">days</h3>
                </div>
                </td>
                <td className="px-2 py-2.5">
                  <div className="bg-gray6 rounded-md inline-flex py-2 gap-3 pr-8  items-start px-3">
                <h3 className="text-xs text-gray2 font-medium">€</h3>
                <h3 className="text-xs text-gray1 font-medium uppercase">{item?.UnitCost}</h3>
                </div>
                </td>
                <td className="px-2 py-2.5">
                  <div className="bg-gray6 rounded-md inline-flex py-2 gap-5 items-start px-3">
                <h3 className="text-xs text-gray1 font-medium">{item?.MOQ}</h3>
                <h3 className="text-xs text-gray2 font-medium uppercase">MOQ</h3>
                </div>
                </td>
              </tr>
          )) }
      
         
        </tbody>
    </table>
  </div>
  </div>
  )
}

export default HjelsengliaTable