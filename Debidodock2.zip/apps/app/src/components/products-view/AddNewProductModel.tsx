import { Button } from '@debido/ui/components/button'
import PopupModel from '../common/PopupModel'
import { CaretDown, CloudArrowUp, Factory, Package, Path, Tag, X } from '@phosphor-icons/react'



interface ModelProps{
    showPopup: boolean,
    setShowPopup: (showPopup: boolean) => void

}

const AddNewProductModel = ({showPopup, setShowPopup}:ModelProps ) => {

    
  return (
    <PopupModel
    showModel={showPopup}
    hideModel={setShowPopup}
    panelClass="max-w-[510px] bg-black2 overflow-hidden md:ml-auto md:mb-auto md:my-0 my-4">
    <div className="w-full">
     
    <div className="w-full">
    <div className="w-full bg-black2 border border-gray4 h-full">
    <div className="w-full pl-6 pt-5 pr-4">
    <div className="w-full flex justify-between">
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
    <img src="/images/inventory-user-img.png" className="w-6 h-6 rounded bg-cover"  alt=""/>
    <h2>Velour Hoodie Blackout</h2>
    </div>
    <Button onClick={()=>{setShowPopup(false)}} className='bg-transparent lg:hidden flex -mt-2 -mr-2'>
        <X size={16} />
    </Button>
    </div>
    <ul className="w-full mt-[30px] flex items-start justify-center gap-4 flex-col mb-6">
        <li className="flex items-center gap-8">
            <p className="text-xs text-gray2">Vendor</p>
            <div className="border border-gray4 px-2.5 py-1.5 rounded-full flex items-center text-gray2 gap-1">
                <Factory size={16} />
            <p className=" text-xs text-gray2">Lopes Carvalho</p>
            </div>
        </li>
        <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">Status</p>
            <div className="border border-gray4 flex items-center gap-2 text-gray2 px-2.5 py-1.5 rounded-full">
                <div className="w-2 h-2 rounded-full bg-green1"></div>
            <p className=" text-xs">Active</p>
            </div>
        </li>
        <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">Product MOQ</p>
            <p className="text-xs text-gray2 rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">300 pcs</p>
        </li>
        <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">On order</p>
            <div className="flex gap-1 items-center flex-wrap ">
            <div className="border border-gray4 px-2.5 py-1.5 rounded-full flex items-center text-gray2 gap-1">
                <Package size={16} />
            <p className=" text-xs text-gray2">SO-03</p>
            </div>
            <div className="border border-gray4 px-2.5 py-1.5 rounded-full flex items-center text-gray2 gap-1">
                <Package size={16} />
            <p className=" text-xs text-gray2">SO-01</p>
            </div>
            </div>
        </li>
    </ul>
    </div>

    {/* Files and notes */}
    <div className="w-full pl-6 py-4 pr-4 border-t border-gray4">
    <div className="w-full flex mb-6 justify-between">
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
    <Tag size={20} className="text-gray2" />
    <h2 className="text-xs text-gray1">Files and notes</h2>
    </div>
    <Button className="text-gray2 p-1 !bg-transparent shadow-none text-xs gap-1 font-medium">
    <CaretDown size={16}/>
    </Button>
    </div>

    <div className="w-full mb-6">
        <form id="filesForm">
        <label htmlFor="fileUpload" className="w-full h-20 cursor-pointer flex text-gray2 items-center justify-center border-dashed border border-gray5 rounded-lg flex-col">
        <input type="file" id="fileUpload" className=" appearance-none opacity-0 hidden" />
        <CloudArrowUp size={22} />
        <span className="text-sm text-gray2 font-medium mt-1">Upload file</span>
        </label>

        <ul className="flex flex-col gap-1 mt-2 mb-7 text-gray2">
        <li className="relative flex items-center justify-between border border-gray4 rounded-lg p-2.5">
            <div className="flex items-center gap-2">
            <img className="w-7 h-7 rounded bg-cover" src="/images/logo-uploaded.png" alt="" />
            <p className="text-xs text-gray2 font-medium">Logo.pdf</p>
            </div>
            <Button className="!bg-transparent shadow-none p-2 text-gray2">
                <X size={16} />
            </Button>
        </li>
        <li className="relative flex items-center justify-between border border-gray4 rounded-lg p-2.5">
            <div className="flex items-center gap-2">
            <img className="w-7 h-7 rounded bg-cover" src="/images/logo-uploaded.png" alt="" />
            <p className="text-xs text-gray2 font-medium">Logo.pdf</p>
            </div>
            <Button className="!bg-transparent shadow-none p-2 text-gray2">
                <X size={16} />
            </Button>
        </li>
     
    </ul>
    <div className="w-full">
        <h4 className="text-xs text-gray1 font-medium mb-1.5">Note</h4>
        <textarea className="w-full text-sm h-[77px] font-medium text-gray2 placeholder:text-xs placeholder:text-gray2 placeholder:font-medium border border-gray4 bg-gray6 rounded-lg px-3 py-2 focus:outline-none" 
        placeholder="Only vendor will see this note" />
        <p className="text-gray2 text-xs mt-2">Only vendor will see this note</p>
        
    </div>
    </form>
    </div>
    </div>

    {/* Variants */}
    <div className="w-full py-4 border-t border-gray4">
    <div className="w-full flex mb-3 pl-6 pr-4 justify-between">
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
    <Tag size={20} className="text-gray2" />
    <h2 className="text-xs text-gray1">Variants</h2>
    <h4 className="text-xs text-gray2 ml-2">3</h4>
    </div>
    <Button className="text-gray2 p-1 !bg-transparent shadow-none text-xs gap-1 font-medium">
    <CaretDown size={16}/>
    </Button>
    </div>

    <ul className="w-full mb-6">
        <li className="flex items-center pl-6 pr-4 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
            <div className="flex items-center gap-2">
                <img src="/images/variant-avatar.png" className="w-5 h-5 rounded bg-cover" alt="" />
                <h3 className="text-sm textgray1 font-medium">Velour Hoodie</h3>
            </div>
            <Button className="!bg-transparent shadow-none p-3 text-blue1">
            Edit
            </Button>
        </li>
        <li className="flex items-center pl-6 pr-4 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
            <div className="flex items-center gap-2">
                <img src="/images/variant-avatar.png" className="w-5 h-5 rounded bg-cover" alt="" />
                <h3 className="text-sm textgray1 font-medium">Velour Hoodie</h3>
            </div>
            <Button className="!bg-transparent shadow-none p-3 text-blue1">
            Edit
            </Button>
        </li>
        <li className="flex items-center pl-6 pr-4 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
            <div className="flex items-center gap-2">
                <img src="/images/variant-avatar.png" className="w-5 h-5 rounded bg-cover" alt="" />
                <h3 className="text-sm textgray1 font-medium">Velour Hoodie</h3>
            </div>
            <Button className="!bg-transparent shadow-none p-3 text-blue1">
            Edit
            </Button>
        </li>
        <li className="flex items-center pl-6 pr-4 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
            <div className="flex items-center gap-2">
                <img src="/images/variant-avatar.png" className="w-5 h-5 rounded bg-cover" alt="" />
                <h3 className="text-sm textgray1 font-medium">Velour Hoodie</h3>
            </div>
            <Button className="!bg-transparent shadow-none p-3 text-blue1">
            Edit
            </Button>
        </li>
        <li className="flex items-center pl-6 pr-4 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
            <div className="flex items-center gap-2">
                <img src="/images/variant-avatar.png" className="w-5 h-5 rounded bg-cover" alt="" />
                <h3 className="text-sm textgray1 font-medium">Velour Hoodie</h3>
            </div>
            <Button className="!bg-transparent shadow-none p-3 text-blue1">
            Edit
            </Button>
        </li>
    </ul>

    </div>


    {/* Timeline */}

    <div className="w-full pl-6 py-4 pr-4 border-t border-gray4 mt-5">
    <div className="w-full flex justify-between">
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
    <Path size={20} className="text-gray2" />
    <h2>Timeline</h2>
    </div>
    <Button className="text-gray2 p-1 !bg-transparent shadow-none text-xs gap-1 font-medium">
    <CaretDown size={16}/>
    </Button>
    </div>

    <ul className="flex flex-col gap-8 list-disc text-gray2 pl-7">
        <li className="relative">
            <p className="text-xs text-gray1 font-medium">SO-03 sent from Xiemen Manufacturer</p>
            <p className="text-xs text-gray2 font-medium">25 Jan 2024, 16:30</p>
        </li>
        <li className="flex borde-l w-[1px] -ml-4 -mt-9 -mb-7 border-gray2 opacity-20 bg-gray2 h-10">

        </li>
        <li>
            <p className="text-xs text-gray1 font-medium">SO-03 sent from Xiemen Manufacturer</p>
            <p className="text-xs text-gray2 font-medium">25 Jan 2024, 16:30</p>
        </li>
    </ul>



    </div>
    </div>
     
    </div>
    
    </div>
    </PopupModel>
  )
}

export default AddNewProductModel