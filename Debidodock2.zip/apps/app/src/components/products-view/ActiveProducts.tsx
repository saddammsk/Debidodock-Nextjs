import { Button } from '@debido/ui/components/button'
import { CaretRight, CaretUpDown, Check, Paperclip, Sticker, Tag } from '@phosphor-icons/react'
import { useGlobalContext } from '../../context/GlobalContext'


const activeProductsData = [
    {id: '1', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', note: true, attachedFiles: 3, isActive: true },
    {id: '2', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', note: false, attachedFiles: 2, isActive: true  },
    {id: '3', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', note: true, attachedFiles: 0, isActive: true },
    {id: '4', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', note: false, attachedFiles: 2, isActive: true },
    {id: '5', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', note: false, attachedFiles: 3, isActive: true },
    {id: '6', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', note: true, attachedFiles: 1, isActive: true },
  ]
  


const ActiveProducts = () => {
    const { setToggleEditSidebar } = useGlobalContext()


  return (
    <div>
          {/*Active Product Head */}
      <div className="flex bg-black1 items-center justify-between md:px-6 px-3 h-11 border-b border-gray4"> 
        <div className="flex items-center gap-2 py-2.5 px-2 text-xs font-medium text-gray1">
        <Tag weight="fill" size={16} className="text-gray2" />
        <h2 className="text-xs text-gray1">Active</h2>
        </div>
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent gap-2 shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <CaretUpDown size={16} />
        Sort
        </Button>
      </div>

    {/*Active Body */}
    <ul>
        {activeProductsData.map((product)=>(
             <li key={product.id} className="!bg-black2 w-full flex md:flex-row flex-col sm:flex-row sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1">
             <div className="flex items-center gap-2">
               <label htmlFor={`${product?.id}`+ 'checkbox-1'} className="relative flex items-center justify-center">
             <input type="checkbox" id={`${product?.id}`+ 'checkbox-1'} className="peer rounded checked:bg-blue2 bg-transparent w-4 h-4 border border-gray5  appearance-none" />
             <Check size={10} className="peer-checked:block text-gray1 hidden absolute" />
             </label>
             <img src={product?.imgUrl} alt="avator" className="w-6 h-6 rounded bg-cover" />
             <button onClick={()=>setToggleEditSidebar(true)}  className="flex items-center gap-2">
             <h3 className="text-sm text-gray2 font-medium ml-1">{product?.name}</h3>
               <CaretRight size={10} className="" />
               <p className="text-xs text-gray2"><span>{product?.variants}</span> variants</p>
             </button>
             </div>  
             </div>
             <div className='mx-auto sm:mx-0'>
               <ul className="flex items-center gap-1.5 flex-wrap">
                {product?.note &&
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <Sticker size={16}/>  
                   <p className="text-xs font-medium">Note</p>
                   </div>
                 </li>}
                 {product?.attachedFiles > 0 &&
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <Paperclip size={16}/>  
                   <p className="text-xs font-medium">{product?.attachedFiles}</p>
                   <p className="text-xs font-medium">Files</p>
                   </div>
                 </li>
                 }
                  {product?.isActive &&
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <div className="w-2 h-2 rounded-full bg-green1"></div>
                   <p className="text-xs font-medium">Active</p>
                   </div>
                 </li>
                 }
               </ul>
             </div>
           </li>
        ))}
     
    </ul>
    </div>
  )
}

export default ActiveProducts