import { Button } from '@debido/ui/components/button'
import { CaretRight, CaretUpDown, Check, Tag } from '@phosphor-icons/react'
import { useGlobalContext } from '../../context/GlobalContext'


const draftsData = [
  {id: '1', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', },
  {id: '2', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', },
  {id: '3', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', },
  {id: '4', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', },
  {id: '5', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', },
  {id: '6', name:'Velour Hoodie Blackout', imgUrl: '/images/inventory-user-img.png', variants: '5', },
]

const DraftsProducts = () => {
    const { setToggleEditSidebar } = useGlobalContext()


  return (
    <div>
          {/*Drafts Product Head */}
      <div className="flex bg-black1 items-center justify-between md:px-6 px-3 h-11 border-b border-gray4"> 
        <div className="flex items-center gap-2 py-2.5 px-2 text-xs font-medium text-gray1">
        <Tag weight="fill" size={16} className="text-gray2" />
        <h2 className="text-xs text-gray1">Drafts</h2>
        </div>
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent gap-2 shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <CaretUpDown size={16} />
        Sort
        </Button>
      </div>


    {/*Drafts Product Body */}
    <ul>
      {draftsData.map((item) => (
        <li key={item.id} className="!bg-black2 w-full flex sm:items-center justify-between xsm:flex-row gap-3 flex-col md:px-6 px-3 py-1.5 h-auto border-b border-gray4"> 
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <div className="flex items-center gap-2">
        <label htmlFor={`${item?.id}`+'-checkbox'} className="relative flex items-center justify-center">
        <input type="checkbox" id={`${item?.id}`+'-checkbox'} className="peer rounded checked:bg-blue2 bg-transparent w-4 h-4 border border-gray5  appearance-none" />
        <Check size={10} className="peer-checked:block text-gray1 hidden absolute" />
        </label>
        <img src={`${item?.imgUrl}`} alt="avator" className="w-6 h-6 rounded bg-cover" />
        <button onClick={()=>setToggleEditSidebar(true)}  className="flex items-center gap-2">
        <h3 className="text-sm text-start text-gray2 font-medium ml-1">{item?.name}</h3>
          <CaretRight size={10} className="" />
          <p className="text-xs text-gray2"><span>{item?.variants}</span> variants</p>
        </button>
        </div>  
        </div>
        <div className='mx-auto xsm:mx-0'>
          <ul className="flex items-center gap-1.5 flex-wrap">
            <li>
            <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
              <div className="w-2 h-2 rounded-full bg-gray2"></div>
              <p className="text-xs font-medium">Draft</p>
              </div>
            </li>
          </ul>
        </div>
      </li>
      ))}
    
    </ul>
    </div>
  )
}

export default DraftsProducts