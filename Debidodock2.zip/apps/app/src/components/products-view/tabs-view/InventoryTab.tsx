import { Button } from "@debido/ui/components/button";
import { BellSimple, FunnelSimple } from "@phosphor-icons/react";
// import { useGlobalContext } from "../../../context/GlobalContext";
import LettbutikkTable from "../../products-view/LettbutikkTable";
import HjelsengliaTable from "../../products-view/HjelsengliaTable";





const InventoryTab = ({fadeState}:{fadeState:boolean}) => {
  // const {setToggleEditSidebar} = useGlobalContext();
 

  return (
    <div className={`${fadeState ? "opacity-0" : "opacity-100"}` + " w-full transition-opacity duration-200 mb-8"}>
    <div>
      {/* Head | Sorting */}
      <div className="flex items-center justify-between lg:px-6 px-3 py-1.5 border-b border-gray4"> 
        <div className="flex items-center gap-1 py-2.5 px-2 text-xs font-medium text-gray1">
        <FunnelSimple size={16} className="text-gray2" />
        <h2 className="text-xs text-gray2">Filter</h2>
        </div>
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <BellSimple size={16}  weight="fill" />
        </Button>
      </div>

    {/*Invertory Lettbutikk Table */}
    <LettbutikkTable/>

     {/*Invertory Hjelsenglia Table */}
     <HjelsengliaTable/>

    </div>

  </div>
  )
}

export default InventoryTab