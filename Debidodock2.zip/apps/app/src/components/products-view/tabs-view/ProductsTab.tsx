import { Button } from "@debido/ui/components/button";
import { BellSimple, FunnelSimple} from "@phosphor-icons/react";
import ActiveProducts from "../ActiveProducts";
import DraftsProducts from "../DraftsProducts";


const ProductsTab = ({fadeState}:{fadeState:boolean}) => {


  return (
    <div className={`${fadeState ? "opacity-0" : "opacity-100"}` + " w-full transition-opacity duration-200 mb-8"}>

        {/* Head */}
      <div className="flex items-center justify-between px-6 py-1.5 border-b border-gray4"> 
        <div className="flex items-center gap-1 py-2.5 px-2 text-xs font-medium text-gray1">
        <FunnelSimple size={16} className="text-gray2" />
        <h2 className="text-xs text-gray2">Filter</h2>
        </div>
        <div className="flex items-center gap-4">
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <BellSimple size={16}  weight="fill" />
        </Button>

        {/* <ul className="flex items-center bg-black1 rounded-md border border-gray4">
          <li>
            <Button className="text-gray2 hover:bg-black2 hover:border-gray4 hover:text-gray1 border border-transparent bg-transparent shadow-none">
              <List size={18} />
            </Button>
          </li>
          <li>
            <Button className="text-gray2 hover:bg-black2 hover:border-gray4 hover:text-gray1 border border-transparent bg-transparent shadow-none">
              <Kanban size={18} />
            </Button>
          </li>
          <li>
            <Button className="text-gray2 hover:bg-black2 hover:border-gray4 hover:text-gray1 border border-transparent bg-transparent shadow-none">
              <MapTrifold size={18} />
            </Button>
          </li>
        </ul> */}
        </div>
      </div>

      {/* Active Product List */}
      <ActiveProducts/>

      {/* Drafts Product List */}

      <DraftsProducts/>


   
  </div>
  )
}

export default ProductsTab