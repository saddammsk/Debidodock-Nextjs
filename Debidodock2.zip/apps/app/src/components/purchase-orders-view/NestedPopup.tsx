import NestedPopupModel from "../common/NestedPopupModel"



interface ModelProps{
  showNested: boolean,
    panelClass: string,
    setShowNestedPopup: (showNested: boolean) => void,
    children: React.ReactNode
}

const NestedPopup = ({showNested, setShowNestedPopup, panelClass= "", children}:ModelProps ) => {

    
  return (
    <NestedPopupModel
    showModel={showNested}
    hideModel={setShowNestedPopup}
    panelClass={`${panelClass}` + " bg-black2 overflow-hidden m-2"}>
    <div className="w-full h-full">
    <div className="w-full bg-black2 h-full">
      {children}
    </div>  
    </div>
    </NestedPopupModel>
  )
}

export default NestedPopup