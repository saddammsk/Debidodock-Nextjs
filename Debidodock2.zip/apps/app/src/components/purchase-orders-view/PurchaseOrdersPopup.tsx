import PopupModel from "../common/PopupModel"



interface ModelProps{
    showPopup: boolean,
    panelClass: string,
    setShowPopup: (showPopup: boolean) => void,
    children: React.ReactNode
}

const PurchaseOrdersPopup = ({showPopup, setShowPopup, panelClass= "", children}:ModelProps ) => {

    
  return (
    <PopupModel
    showModel={showPopup}
    hideModel={setShowPopup}
    panelClass={`${panelClass}` + " bg-black2 overflow-hidden m-2"}>
    <div className="w-full h-full">
    <div className="w-full bg-black2 h-full">
        {children}
    </div>  
    </div>
    </PopupModel>
  )
}

export default PurchaseOrdersPopup