import { ArrowRight, CaretDown, Factory, Path, SpinnerGap, Tag, X } from "@phosphor-icons/react"
import { useGlobalContext } from "../../context/GlobalContext"
import { Button } from "@debido/ui/components/button"

const PurchaseOrdersSidebar = () => {
    const {toggleEditSidebar, setToggleEditSidebar} = useGlobalContext()

  return (
    <>
    {toggleEditSidebar && <div onClick={()=>setToggleEditSidebar(false)} className="w-screen lg:hidden fixed min-h-screen left-0 top-0 bg-black1 opacity-50"></div>}

    <div
      className={
        `${toggleEditSidebar ? "block" : "hidden"}` +
        " w-full pb-8 lg:max-w-[363px] lg:rounded-none rounded-xl max-w-[90%] z-10 lg:static fixed top-8 lg:left-auto left-1/2 lg:translate-x-0 -translate-x-1/2 bg-black2 border border-gray4"
      }
    >
      <div className="w-full md:pl-6 pt-5 px-3 md:pr-4">
        <div className="w-full flex justify-between">
          <div className="flex items-center flex-wrap gap-2 text-xs font-medium text-gray1">
            <SpinnerGap size={20} className="text-yellow1" />
            <h2 className="text-sm text-gray1 flex items-center flex-wrap gap-1">
              Xiemen Manufacturer <ArrowRight size={12} /> <span>Lettbutikk</span>
            </h2>
          </div>
          <Button onClick={()=>setToggleEditSidebar(false)} className="!bg-transparent  lg:hidden -mt-2 -mr-2">
            <X size={16} />
          </Button>
        </div>
      </div>
      <div className="w-full lg:max-h-max max-h-[80vh] overflow-y-auto">
      <ul className="flex items-start w-full md:pl-6 py-5 px-3 md:pr-4 justify-center gap-4 flex-col">
          <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">Warehouse</p>
            <div className="border border-gray4 px-2.5 py-1.5 flex items-center gap-1.5 rounded-full ">
              <img src="/images/ongoing-symbol.svg" className="w-4" alt="" />
              <p className="text-xs text-gray2">PO77</p>
            </div>
          </li>
          <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">Status</p>
            <div className="border text-gray2 border-gray4 px-2.5 py-1.5 flex items-center gap-1.5 rounded-full ">
              <Factory size={16} />
              <p className="text-xs text-gray2">PO77</p>
            </div>
          </li>
          <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">SKU’s</p>
            <div className="rounded-full inline-flex gap-2 px-2.5 py-1.5 items-center border border-gray4">
              <div className="bg-green1 rounded-full w-2 h-2"></div>
              <p className="text-xs text-gray2 font-medium">Active</p>
            </div>
          </li>
          <li className="flex items-center gap-8">
            <p className="text-xs text-gray2 ">ETA</p>
            <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
              <div className="flex items-center justify-center gap-1.5">
                <div className="w-2 h-2 flex rounded-full bg-yellow1"></div>
                <p className="text-xs font-medium py-1.5">Est delivery</p>
              </div>
              <div className="border-r"></div>
              <p className="text-xs font-medium py-1.5">12 Jun 24</p>
            </div>
          </li>
        </ul>

      <div className="w-full py-4 border-t border-gray4">
        <div className="w-full flex mb-3 md:pl-6 md:pr-4 px-3 justify-between">
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <Tag size={20} className="text-gray2" />
        <h2 className="text-xs text-gray1">Products</h2>
        <h4 className="text-xs text-gray2 ml-2">3</h4>
        </div>
        <Button className="text-gray2 p-1 !bg-transparent shadow-none text-xs gap-1 font-medium">
        <CaretDown size={16}/>
        </Button>
        </div>

        <ul className="w-full mb-6">
            <li className="flex items-center px-6 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
                <div className="flex items-center gap-2">
                    <img src="/images/active-product-img-1.png" className="w-5 h-5 rounded bg-cover" alt="" />
                    <h3 className="text-sm textgray1 font-medium">Velour Hoodie</h3>
                </div>
                <div className="flex items-center gap-10 ">
                    <p className="text-sm text-gray2 line-through">32</p>
                    <p className="text-sm text-gray1">34</p>
                </div>
              
            </li>
            <li className="flex items-center px-6 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
                <div className="flex items-center gap-2">
                    <img src="/images/active-product-img-2.png" className="w-5 h-5 rounded bg-cover" alt="" />
                    <h3 className="text-sm textgray1 font-medium">Velour Caps</h3>
                </div>
                <div className="flex items-center gap-10 ">
                    <p className="text-sm text-gray2 line-through">32</p>
                    <p className="text-sm text-gray1">34</p>
                </div>
            </li>
            <li className="flex items-center px-6 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
                <div className="flex items-center gap-2">
                    <img src="/images/active-product-img-3.png" className="w-5 h-5 rounded bg-cover" alt="" />
                    <h3 className="text-sm textgray1 font-medium">Velour Caps</h3>
                </div>
                <div className="flex items-center gap-10 ">
                    <p className="text-sm text-gray2 line-through">32</p>
                    <p className="text-sm text-gray1">34</p>
                </div>
            </li>
            <li className="flex items-center px-6 justify-between gap-5 py-3 border-b border-gray4 flex-wrap">
                <div className="flex items-center gap-2">
                    <img src="/images/variant-avatar.png" className="w-5 h-5 rounded bg-cover" alt="" />
                    <h3 className="text-sm textgray1 font-medium">Velour Hoodie</h3>
                </div>
                <div className="flex items-center gap-10 ">
                    <p className="text-sm text-gray2 line-through">32</p>
                    <p className="text-sm text-gray1">34</p>
                </div>
            </li>
            <li className="flex items-center px-6 justify-between gap-5 py-3 flex-wrap">
                <div className="flex items-center gap-2">
                    <img src="/images/variant-avatar.png" className="w-5 h-5 rounded bg-cover" alt="" />
                    <h3 className="text-sm textgray1 font-medium">Velour Hoodie</h3>
                </div>
                <div className="flex items-center gap-10 ">
                    <p className="text-sm text-gray2 line-through">32</p>
                    <p className="text-sm text-gray1">34</p>
                </div>
            </li>
        </ul>

      </div>

        {/* Timeline */}

        <div className="w-full md:pl-6 py-4 md:pr-4 px-3 border-t border-gray4">
          <div className="w-full flex justify-between">
            <div className="flex items-center gap-2 text-xs font-medium text-gray1">
              <Path size={20} className="text-gray2" />
              <h2>Timeline</h2>
            </div>
            <Button className="text-gray2 !bg-transparent shadow-none text-xs gap-1 font-medium">
              <CaretDown size={16} />
            </Button>
          </div>

          <ul className="flex flex-col gap-8 list-disc text-gray2 pl-7">
            <li className="relative">
              <p className="text-xs text-gray1 font-medium">
                SO-03 sent from Xiemen Manufacturer
              </p>
              <p className="text-xs text-gray2 font-medium">25 Jan 2024, 16:30</p>
            </li>
            <li className="flex borde-l w-[1px] -ml-4 -mt-9 -mb-7 border-gray2 opacity-20 bg-gray2 h-10"></li>
            <li>
              <p className="text-xs text-gray1 font-medium">
                SO-03 sent from Xiemen Manufacturer
              </p>
              <p className="text-xs text-gray2 font-medium">25 Jan 2024, 16:30</p>
            </li>
          </ul>
        </div>
        </div>
    </div>
    </>
  );
}

export default PurchaseOrdersSidebar