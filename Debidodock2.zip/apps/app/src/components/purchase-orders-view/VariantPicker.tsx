import { Button } from "@debido/ui/components/button";
import { Check, FunnelSimple, MagnifyingGlass, MapPin, Warning, X } from "@phosphor-icons/react";
import { useEffect, useState } from "react";
import SelectOption from "../common/SelectOption";


const invertoryLettbutikkData = [
    {id: '1',name:'Velour Caps', userImg: '/images/inventory-user-img.png', warning:false, warningfill: 'text-yellow1', location:'Lettbutikk', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50'},
    {id: '2',name:'Velour Caps', userImg: '/images/inventory-user-img.png', warning:true, warningfill: 'text-yellow1', location:'Lettbutikk', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50'},
    {id: '3',name:'Velour Caps', userImg: '/images/inventory-user-img.png', warning:false, warningfill: 'text-red1', location:'Lettbutikk', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50'},
    {id: '4',name:'Velour Caps', userImg: '/images/inventory-user-img.png', warning:true, warningfill: 'text-yellow1', location:'Lettbutikk', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50'},
    {id: '5',name:'Velour Caps', userImg: '/images/inventory-user-img.png', warning:true, warningfill: 'text-yellow1', location:'Lettbutikk', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50'},
    {id: '6',name:'Velour Caps', userImg: '/images/inventory-user-img.png', warning:true, warningfill: 'text-red1', location:'Lettbutikk', Instock: '20', OnOrder: '0', DaysofStock: '40 days', LeadTime: '50'},
 ]

 interface ModelProps{
    setShowNestedPopup: (showNested: boolean) => void,
  }


const VariantPicker = ({setShowNestedPopup}: ModelProps) => {

    const [isMasterChecked, setIsMasterChecked] = useState<boolean>(false);

    useEffect(() => {
      const masterCheckbox = document.getElementById('variants-checkbox2') as HTMLInputElement;
      const checkboxes = document.querySelectorAll('#tbody2 input[type="checkbox"]') as NodeListOf<HTMLInputElement>;
  
      if (masterCheckbox && checkboxes) {
        checkboxes.forEach((checkbox) => {
          checkbox.checked = isMasterChecked;
        });
      }
    }, [isMasterChecked]);
  
    const handleMasterCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setIsMasterChecked(e.target.checked);
    };


  return (
    <div className="w-full">
    <div className="flex items-center justify-between md:p-6 p-4 pb-3 border-b border-gray4"> 
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
        <form className="Search-variant-search-form">
            <label htmlFor="Search-variant" className="sm:flex relative items-center hidden">
                <MagnifyingGlass size={16}  className="absolute left-2.5"/>
            <input type="text" id="Search-variant" placeholder="Search for variant" className="md:w-[263px] w-[180px] pl-8 pr-3 placeholder:text-gray2 placeholder:text-xs text-xs font-medium  bg-gray6 h-9 border border-gray7 rounded-md" />
            </label>

            <Button className="!bg-transparent bg-gray3 border border-gray5 text-gray2 md:hidden flex">
            <MagnifyingGlass size={18} />
            </Button>
        </form>
        <SelectOption selectClass="w-fit pr-10">
        <>
        <option value="" defaultValue="All locations" selected disabled>All locations</option>
        <option value="paused">Location 1</option>
        <option value="delayed">Location 2</option>
        <option value="canceled">Location 3</option>
        </>
        </SelectOption>
        <div className="flex sm:ml-2 gap-1.5 w-full">
        <Button className="bg-gray3 border border-gray5 h-9 ">
            <FunnelSimple size={18} />
        </Button>
       
        </div>
        
    </div>
    <Button onClick={()=>setShowNestedPopup(false)} className="flex -mt-3 -mr-3 bg-transparent hover:bg-transparent gap-2 shadow-none border border-transparent hover:text-gray1 items-center text-xs font-medium text-gray2">
    <X size={16} />
    </Button>
  </div>

  <div className="w-full pb-12 overflow-auto">
    <table className="w-full min-w-[700px]">
      <thead className="w-full">
        <tr className="w-full border-b border-gray4">
          <th className="text-xs text-gray2 font-medium px-2 py-2.5">
            <div className="flex items-center gap-2">
              <label htmlFor="variants-checkbox2" className="relative flex items-center justify-center">
            <input
             onChange={handleMasterCheckboxChange}
             checked={isMasterChecked}
             type="checkbox" id="variants-checkbox2" className="peer rounded checked:bg-blue2 bg-transparent w-4 h-4 border border-gray5  appearance-none" />
            <Check size={10} className="peer-checked:block text-gray1 hidden absolute" />
            </label>
            Variants
            </div>
            </th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">Location</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">In stock</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">On order</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">Days of stock</th>
          <th className="text-xs text-gray2 font-medium px-2 py-2.5 text-start">Lead time</th>
  
        </tr>
        </thead>
        <tbody id="tbody2">
          {invertoryLettbutikkData&&invertoryLettbutikkData.map((item)=>(
              <tr key={item.id} className="bg-black2 last:border-b-0 border-b border-gray4">
              <td scope="row" className="px-2 py-2.5">
                <div className="flex items-center gap-2">
                <label htmlFor={`${item?.id}`+'-checkbox3'} className="relative flex items-center justify-center">
              <input type="checkbox" id={`${item?.id}`+'-checkbox3'} className="peer rounded checked:bg-blue2 bg-transparent w-4 h-4 border border-gray5  appearance-none" />
              <Check size={10} className="peer-checked:block text-gray1 hidden absolute" />
              </label>
              <img src={item.userImg} alt="avator" className="w-6 h-6 rounded bg-cover" />
              <h3 className="text-sm text-gray1 font-medium ml-1">{item?.name}</h3>
              {item?.warning&&
                <Warning size={16} weight="fill" className={`${item?.warningfill}`}/>
              }
                </div>
                </td>
                <td className="px-2 py-2.5">
                <h3 className="text-sm text-gray2 font-medium gap-1.5 flex items-center">
                    <MapPin weight="fill" size={14}/>
                    <span>{item?.location}</span>
                </h3>
                </td>
                <td className="px-2 py-2.5">
                <h3 className="text-sm text-gray1 font-medium uppercase">{item?.Instock}</h3>
                </td>
                <td className="px-2 py-2.5">
                <h3 className={"text-sm text-gray2 font-medium uppercase " + `${item?.OnOrder > '0' && 'underline' }`}>{item?.OnOrder}</h3>
                </td>
                <td className="px-2 py-2.5">
                <h3 className="text-sm text-gray1 font-medium uppercase">{item?.DaysofStock}</h3>
                </td>
                <td className="px-2 py-2.5">
                  <div className="inline-flex gap-1 items-center">
                <h3 className="text-sm text-gray1 font-medium uppercase">{item?.LeadTime}</h3>
                <h3 className="text-sm text-gray1 font-medium">days</h3>
                </div>
                </td>
             
              </tr>
          )) }
      
         
        </tbody>
    </table>
  </div>
  </div>
  )
}

export default VariantPicker