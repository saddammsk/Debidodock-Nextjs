import { RadialChart } from './charts/RadialChart'

const StaticChartViewTop = () => {
  return (
    <div className='2xl:w-fit grid md:px-12 px-4 2xl:grid-cols-4 xsm:grid-cols-2 grid-cols-1 2xl:gap-20 lg:gap-10 gap-6 justify-center items-center w-full mb-8'>
        <div className="w-full flex sm:flex-row flex-col-reverse text-center sm:text-start items-center sm:gap-4 gap-2 md:justify-center">
        <div className=''>
          <p className='sm:text-sm text-xs text-gray2 font-medium mb-1'>Sales vs estimated</p>
          <div className="">
            <h2 className='sm:text-3xl text-2xl font-semibold text-gray1'>32k <span className='sm:text-xl text-base text-gray2'>/233k</span></h2>
          </div>
          </div>
          <RadialChart SalesValue={58} EstimatedValue={-150}   />
          </div>
          <div className="w-full flex sm:flex-row flex-col-reverse text-center sm:text-start items-center gap-4">
        <div className=''>
          <p className='sm:text-sm text-xs text-gray2 font-medium mb-1'>Gross profit vs estimated</p>
          <div className="">
            <h2 className='sm:text-3xl text-2xl font-semibold text-gray1'>-2k  <span className='sm:text-xl text-base text-gray2'>/33k</span></h2>
          </div>
          </div>
          <RadialChart  SalesValue={58} EstimatedValue={-150} />
          </div>
          <div className="w-full flex sm:flex-row flex-col-reverse text-center sm:text-start items-center sm:gap-4 gap-2 md:justify-center">
        <div className=''>
          <p className='sm:text-sm text-xs text-gray2 font-medium mb-1'>Est breakeven revenue</p>
          <div className="">
            <h2 className='sm:text-3xl text-2xl font-semibold text-gray1'>34k <span className='sm:text-xl text-base text-gray2'>/ 34k</span></h2>
          </div>
          </div>
          <RadialChart  SalesValue={100} EstimatedValue={-300}/>
          </div>
          <div className="w-full flex sm:flex-row flex-col-reverse text-center sm:text-start items-center gap-4">
        <div className=''>
          <p className='sm:text-sm text-xs text-gray2 font-medium mb-1'>Est breakeven revenue</p>
          <div className="">
            <h2 className='sm:text-3xl text-2xl font-semibold text-gray1'>32k <span className='sm:text-xl text-base text-gray2'>/34k</span></h2>
          </div>
          </div>
          <RadialChart SalesValue={58} EstimatedValue={-150}/>
          </div>

    </div>
  )
}

export default StaticChartViewTop