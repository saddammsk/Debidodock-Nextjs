import { Button } from "@debido/ui/components/button";
import { MagicWand, MagnifyingGlass, Plus, X } from "@phosphor-icons/react";
import CreatePOTable from "./CreatePOTable";
import POTableChart from "./charts/POTableChart";
import { useGlobalContext } from "../../context/GlobalContext";
import NestedPopup from "./NestedPopup";
import VariantPicker from "./VariantPicker";
import { useState } from "react";
import VariantForecast from "./VariantForecast";
import PreviewOrderView from "./PreviewOrderView";
import Dropdown from "./Dropdown";

const CreatePOView = () => {
  const { showNestedPopup, setShowNestedPopup, setShowPopup } =
    useGlobalContext();
  const [showVariantForecastModel, setShowVariantForecastModel] =
    useState<boolean>(false);
  const [showPerviewOrderModel, setShowPerviewOrderModel] =
    useState<boolean>(false);

  return (
    <div className="w-full">
      {/* Head */}
      <div className="flex items-center justify-between border-b pt-5 pb-4 lg:px-6 px-3 border-gray4">
        <div className="flex items-center gap-2 text-xs font-medium text-gray1">
          <form className="order-nam-search-form">
            <input
              type="text"
              id="ordername"
              placeholder="Order name"
              className="md:w-[251px] md:block hidden w-[150px] md:px-5 px-4 placeholder:text-gray2 placeholder:text-xs text-xs font-medium  bg-gray6 h-9 border border-gray7 rounded-md"
            />
            <Button className="!bg-transparent bg-gray3 border border-gray5 text-gray2 md:hidden flex">
              <MagnifyingGlass size={18} />
            </Button>
          </form>
          {/* For Mobile Options */}
          <div className="md:hidden block">
            <Dropdown />
          </div>

          <div className="md:flex items-center hidden">
            <Button className="bg-gray3 border border-gray5 h-9 md:text-sm text-xs">
              Add Products
            </Button>
            <div className="flex ml-2 gap-1.5 w-full">
              <Button
                onClick={() => setShowVariantForecastModel(true)}
                className="bg-gray3 border border-gray5 h-9"
              >
                <MagicWand size={18} />
              </Button>

              {/* Variant forecast Model */}
              <NestedPopup
                showNested={showVariantForecastModel}
                setShowNestedPopup={setShowVariantForecastModel}
                panelClass="max-w-[520px]"
              >
                <VariantForecast
                  setShowNestedPopup={setShowVariantForecastModel}
                />
              </NestedPopup>

              <Button
                onClick={() => setShowNestedPopup(true)}
                className="bg-gray3 border border-gray5 h-9 ">
                <Plus size={18} />
              </Button>
            </div>

            {/* Variant Picker  Model*/}
            <NestedPopup
              showNested={showNestedPopup}
              setShowNestedPopup={setShowNestedPopup}
              panelClass="max-w-[847px]"
            >
              <VariantPicker setShowNestedPopup={setShowNestedPopup} />
            </NestedPopup>
          </div>
        </div>
        <div className="inline-flex gap-1.5">
          <Button className="flex bg-transparent h-9 py-2.5 px-2 gap-2 shadow-none border border-gray5 hover:text-gray1 items-center text-xs font-medium text-gray1">
            Save draft
          </Button>

          <Button
            onClick={() => setShowPerviewOrderModel(true)}
            className="h-9 md:text-sm text-xs"
          >
            Preview order
          </Button>

          <Button onClick={() => setShowPopup(false)}
            className="h-9 !bg-transparent p-2 -mt-2.5 -mr-2 sm:ml-2 lg:hidden flex">
            <X size={14} />
          </Button>
          {/* Preview Order Model */}
          <NestedPopup
            showNested={showPerviewOrderModel}
            setShowNestedPopup={setShowPerviewOrderModel}
            panelClass="max-w-[1098px] my-12"
          >
            <PreviewOrderView setShowNestedPopup={setShowPerviewOrderModel} />
          </NestedPopup>
        </div>
      </div>

      {/* Create PO Table */}
      <CreatePOTable />

      <POTableChart />
    </div>
  );
};

export default CreatePOView;
