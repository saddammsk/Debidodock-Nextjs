import { Button } from '@debido/ui/components/button'
import {CaretUpDown, Package, Pulse, SpinnerGap, Truck } from '@phosphor-icons/react'
import { useGlobalContext } from '../../context/GlobalContext'

const ActiveOrders = () => {
  const {setShowActiveOrder, setToggleEditSidebar} = useGlobalContext()

  return (
    <div>
        <div className="flex bg-black1 items-center justify-between px-6 h-11 border-b border-gray4"> 
        <div className="flex items-center gap-2 py-2.5 text-xs font-medium text-gray1">
        <Package size={16} className="text-gray2" />
        <h2 className="text-xs text-gray1">Sub orders</h2>
        </div>
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent gap-2 shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <CaretUpDown size={16} />
        Sort
        </Button>
      </div>

        {/*Active Body */} 
        <ul>
             <li className="!bg-black2 w-full flex md:flex-row flex-col sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 md:w-fit w-full">
             <button onClick={()=>setToggleEditSidebar(true)} className="flex items-center flex-wrap gap-2">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">SO-01</h3>
             <SpinnerGap size={18} className='text-yellow1' />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray1 ">Xiemen Manufacturer Lettbutikk</p>
             </div>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <Truck size={18} />
                   <p className="text-xs font-medium">In delivery</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-yellow1"></div>
                   <p className="text-xs font-medium py-1.5">Est delivery</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">12 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                 <button className="inline-flex ml-2 items-center justify-center whitespace-nowrap rounded-md transition-colors duration-300 focus-visible:outline-none focus:outline-none disabled:pointer-events-none disabled:opacity-50 shadow-btn-default active:shadow-btn-default-active hover:shadow-btn-default-hover hover:bg-primary/95 h-8 bg-gray3 text-gray1 sm:text-xs text-[10px] border sm:px-2 px-1.5 py-3 border-gray5 font-medium gap-1">
                 Mark as delivered
                 </button>
                 </li>
               </ul>
             </div>
           </li>

           <li className="!bg-black2 w-full flex md:flex-row flex-col sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 md:w-fit w-full">
             <button onClick={()=>setShowActiveOrder(true)} className="flex items-center gap-2 flex-wrap">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">SO-03</h3>
             <Pulse size={18} className='text-blue2' />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray1 ">Xiemen Manufacturer Lettbutikk</p>
             </div>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
               <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <img src='/images/ongoing-symbol.svg' className='w-5'  alt=''/>
                   <p className="text-xs font-medium">PO77</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <Truck size={18} />
                   <p className="text-xs font-medium">In delivery</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-yellow1"></div>
                   <p className="text-xs font-medium py-1.5">Est delivery</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">12 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                 <button className="inline-flex ml-2 items-center justify-center whitespace-nowrap rounded-md transition-colors duration-300 focus-visible:outline-none focus:outline-none disabled:pointer-events-none disabled:opacity-50 shadow-btn-default active:shadow-btn-default-active hover:shadow-btn-default-hover hover:bg-primary/95 h-8 bg-gray3 text-gray1 sm:text-xs text-[10px] border sm:px-2 px-1.5 py-3 border-gray5 font-medium gap-1">
                 Mark as delivered
                 </button>
                 </li>
               </ul>
             </div>
           </li>

           <li className="!bg-black2 w-full flex md:flex-row flex-col sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 md:w-fit w-full">
             <button onClick={()=>setShowActiveOrder(true)} className="flex items-center flex-wrap gap-2">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">SO-03</h3>
             <Pulse size={18} className='text-blue2' />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray1 ">Xiemen Manufacturer Lettbutikk</p>
             </div>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
               <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <img src='/images/shiphero.png' className='w-4'  alt=''/>
                   <p className="text-xs font-medium">#147</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <Truck size={18} />
                   <p className="text-xs font-medium">In delivery</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-yellow1"></div>
                   <p className="text-xs font-medium py-1.5">Est delivery</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">12 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                 <button className="inline-flex ml-2 items-center justify-center whitespace-nowrap rounded-md transition-colors duration-300 focus-visible:outline-none focus:outline-none disabled:pointer-events-none disabled:opacity-50 shadow-btn-default active:shadow-btn-default-active hover:shadow-btn-default-hover hover:bg-primary/95 h-8 bg-gray3 text-gray1 sm:text-xs text-[10px] border sm:px-2 px-1.5 py-3 border-gray5 font-medium gap-1">
                 Mark as delivered
                 </button>
                 </li>
               </ul>
             </div>
           </li>
         
     
        </ul>

    </div>
  )
}

export default ActiveOrders