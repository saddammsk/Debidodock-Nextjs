import { Button } from '@debido/ui/components/button'
import {CaretRight, CaretUpDown, Package, Tag } from '@phosphor-icons/react'
import { useGlobalContext } from '../../context/GlobalContext'

const ActiveProductsOrders = () => {
  const {setShowActiveOrder} = useGlobalContext()


  return (
    <div>
        <div className="flex bg-black1 items-center justify-between px-6 h-11 border-b border-gray4"> 
        <div className="flex items-center gap-2 py-2.5 text-xs font-medium text-gray1">
        <Tag size={16} className="text-gray2" />
        <h2 className="text-xs text-gray1">Products</h2>
        </div>
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent gap-2 shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <CaretUpDown size={16} />
        Sort
        </Button>
      </div>


        {/*Active Body */} 
        <ul>
             <li className="!bg-black2 w-full flex flex-wrap sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 sm:w-fit w-full">
             <button onClick={()=>setShowActiveOrder(true)} className="flex items-center gap-2 flex-wrap">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-01</h3>
             <img src="/images/active-product-img-1.png" className='w-5 h-5 rounded bg-cover object-cover' alt="" />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray1 ">Velour Hoodie</p>
               <CaretRight size={10}  className='text-gray2' />
               <p className="text-sm text-gray2 ">5 variants</p>
               
             </div>
             </button>  
             </div>
             <div className='sm:w-fit w-full ml-auto'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                  <Package size={16} />
                   <p className="text-xs font-medium">SO-03</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                  <Package size={16} />
                   <p className="text-xs font-medium">SO-01</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <p className="text-xs text-gray2 font-medium">250 items</p>
                   </div>
                 </li>
            
                 <li>
                 <p className="text-xs text-gray2 font-medium">12 Apr 24</p>
                 </li>
               </ul>
             </div>
           </li>

           <li className="!bg-black2 w-full flex flex-wrap sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 sm:w-fit w-full">
             <button onClick={()=>setShowActiveOrder(true)} className="flex items-center gap-2 flex-wrap">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-01</h3>
             <img src="/images/active-product-img-1.png" className='w-5 h-5 rounded bg-cover object-cover' alt="" />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray1 ">Velour Hoodie</p>
               <CaretRight size={10}  className='text-gray2' />
               <p className="text-sm text-gray2 ">5 variants</p>
               
             </div>
             </button>  
             </div>
             <div className='sm:w-fit w-full ml-auto'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                  <Package size={16} />
                   <p className="text-xs font-medium">SO-03</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                  <Package size={16} />
                   <p className="text-xs font-medium">SO-01</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <p className="text-xs text-gray2 font-medium">250 items</p>
                   </div>
                 </li>
            
                 <li>
                 <p className="text-xs text-gray2 font-medium">12 Apr 24</p>
                 </li>
               </ul>
             </div>
           </li>

           <li className="!bg-black2 w-full flex flex-wrap sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 sm:w-fit w-full">
             <button onClick={()=>setShowActiveOrder(true)} className="flex items-center gap-2 flex-wrap">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-01</h3>
             <img src="/images/active-product-img-1.png" className='w-5 h-5 rounded bg-cover object-cover' alt="" />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray1 ">Velour Hoodie</p>
               <CaretRight size={10}  className='text-gray2' />
               <p className="text-sm text-gray2 ">5 variants</p>
               
             </div>
             </button>  
             </div>
             <div className='sm:w-fit w-full ml-auto'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                  <Package size={16} />
                   <p className="text-xs font-medium">SO-03</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                  <Package size={16} />
                   <p className="text-xs font-medium">SO-01</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <p className="text-xs text-gray2 font-medium">250 items</p>
                   </div>
                 </li>
            
                 <li>
                 <p className="text-xs text-gray2 font-medium">12 Apr 24</p>
                 </li>
               </ul>
             </div>
           </li>

     
     
        </ul>


    </div>
  )
}

export default ActiveProductsOrders