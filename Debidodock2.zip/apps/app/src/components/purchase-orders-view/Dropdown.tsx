import { Button, Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/react'
import {DotsThreeVertical, MagicWand, Plus } from '@phosphor-icons/react'
import NestedPopup from './NestedPopup'
import VariantForecast from './VariantForecast'
import { useGlobalContext } from '../../context/GlobalContext';
import { useState } from 'react';
import VariantPicker from './VariantPicker';

export default function Dropdown() {

    const { showNestedPopup, setShowNestedPopup } = useGlobalContext();
    const [showVariantForecastModel, setShowVariantForecastModel ] = useState<boolean>(false);

    return (
        <>
      <Menu as="div" className="relative z-10">
        <MenuButton>
            <DotsThreeVertical size={20} />
        </MenuButton>
        <MenuItems as='div' className="absolute flex items-center bg-gray3 rounded-md border border-gray5">
          <MenuItem>
          <Button className="!bg-transparent text-sm whitespace-nowrap px-3 py-2 border-r border-gray5">
            Add Products
        </Button>
          </MenuItem>
          <MenuItem>
        <Button onClick={()=>setShowVariantForecastModel(true)}  className="!bg-transparent text-sm whitespace-nowrap px-3 py-2 border-r border-gray5">
        <MagicWand size={18} />
        </Button>
          </MenuItem>
          <MenuItem>
          <Button onClick={()=>setShowNestedPopup(true)} className="!bg-transparent text-sm whitespace-nowrap px-3 py-2 border-r border-gray5">
          <Plus size={18} />
        </Button>
          </MenuItem>
        </MenuItems>
      </Menu>

           {/* Variant forecast Model */}
           <NestedPopup
          showNested={showVariantForecastModel}
          setShowNestedPopup={setShowVariantForecastModel}
          panelClass="max-w-[520px]"
          >
          <VariantForecast setShowNestedPopup={setShowVariantForecastModel}/>

          </NestedPopup>


              {/* Variant Picker  Model*/}
        <NestedPopup
        showNested={showNestedPopup}
        setShowNestedPopup={setShowNestedPopup}
        panelClass="max-w-[847px]"
        >
        <VariantPicker setShowNestedPopup={setShowNestedPopup}/>

        </NestedPopup>

    </>
    )
  }