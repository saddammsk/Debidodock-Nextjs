import { Button } from '@debido/ui/components/button'
import {ArrowRight, CaretUpDown, Coin } from '@phosphor-icons/react'
import { useGlobalContext } from '../../context/GlobalContext'

const ActivePaymentsOrders = () => {
  const {setShowActiveOrder} = useGlobalContext()


  return (
    <div>
        <div className="flex bg-black1 items-center justify-between px-6 h-11 border-b border-gray4"> 
        <div className="flex items-center gap-2 py-2.5 text-xs font-medium text-gray1">
        <Coin size={16} className="text-gray2" />
        <h2 className="text-xs text-gray1">Payments</h2>
        </div>
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent gap-2 shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <CaretUpDown size={16} />
        Sort
        </Button>
      </div>


        {/*Active Body */} 
        <ul>
             <li className="!bg-black2 w-full flex md:flex-row flex-col sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 md:w-fit w-full">
             <button onClick={()=>setShowActiveOrder(true)} className="flex items-center flex-wrap gap-2">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-01</h3>
             <Coin size={18} className='text-gray2' />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray2 ">Xiemen Manufacturer</p>
               <ArrowRight size={14} weight="bold" className='text-gray1' />
               <p className="text-sm text-gray1 ">19 489 NOK</p>
               
             </div>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">19 489 NOK</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">1 705 USD</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                <svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 8.37867C2 9.70784 2.36565 11.0105 3.05558 12.1392C3.74552 13.2679 4.73219 14.1777 5.90398 14.7656C7.07576 15.3535 8.38589 15.596 9.68612 15.4657C10.9864 15.3354 12.2248 14.8375 13.2613 14.0284C14.2979 13.2193 15.0911 12.1311 15.5513 10.8872C16.0116 9.64318 16.1204 8.293 15.8655 6.98937C15.6106 5.68574 15.0022 4.4807 14.109 3.51059C13.2159 2.54048 12.0737 1.84401 10.8117 1.5" stroke="#1E59FF" strokeWidth="3" strokeLinecap="round"/>
                </svg>
                <p className="text-xs text-gray2 font-medium">1/3 - Xiemen Manufacturer</p>
                   </div>
                 </li>
            
                 <li>
                 <p className="text-xs text-gray2 font-medium">12 Apr 24</p>
                 </li>
               </ul>
             </div>
           </li>

           <li className="!bg-black2 w-full flex md:flex-row flex-col sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 md:w-fit w-full">
             <button onClick={()=>setShowActiveOrder(true)} className="flex items-center flex-wrap gap-2">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-01</h3>
             <Coin size={18} className='text-gray2' />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray2 ">Xiemen Manufacturer</p>
               <ArrowRight size={14} weight="bold" className='text-gray1' />
               <p className="text-sm text-gray1 ">19 489 NOK</p>
               
             </div>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">19 489 NOK</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">1 705 USD</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                <svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 8.37867C2 9.70784 2.36565 11.0105 3.05558 12.1392C3.74552 13.2679 4.73219 14.1777 5.90398 14.7656C7.07576 15.3535 8.38589 15.596 9.68612 15.4657C10.9864 15.3354 12.2248 14.8375 13.2613 14.0284C14.2979 13.2193 15.0911 12.1311 15.5513 10.8872C16.0116 9.64318 16.1204 8.293 15.8655 6.98937C15.6106 5.68574 15.0022 4.4807 14.109 3.51059C13.2159 2.54048 12.0737 1.84401 10.8117 1.5" stroke="#1E59FF" strokeWidth="3" strokeLinecap="round"/>
                </svg>
                <p className="text-xs text-gray2 font-medium">2/3 - Xiemen Manufacturer</p>
                   </div>
                 </li>
            
                 <li>
                 <p className="text-xs text-gray2 font-medium">12 Apr 24</p>
                 </li>
               </ul>
             </div>
           </li>

           <li className="!bg-black2 w-full flex md:flex-row flex-col sm:items-center justify-between md:px-6 px-3 py-1.5 gap-3 border-b border-gray4"> 
             <div className="flex items-center gap-2 text-xs font-medium text-gray1 md:w-fit w-full">
             <button onClick={()=>setShowActiveOrder(true)} className="flex items-center gap-2 flex-wrap">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-01</h3>
             <Coin size={18} className='text-gray2' />
             <div  className="flex items-center gap-2">
               <p className="text-sm text-gray2 ">Xiemen Manufacturer</p>
               <ArrowRight size={14} weight="bold" className='text-gray1' />
               <p className="text-sm text-gray1 ">19 489 NOK</p>
               
             </div>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
               <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">Shipping</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">19 489 NOK</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">935 USD</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                <svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 8.37867C2 9.70784 2.36565 11.0105 3.05558 12.1392C3.74552 13.2679 4.73219 14.1777 5.90398 14.7656C7.07576 15.3535 8.38589 15.596 9.68612 15.4657C10.9864 15.3354 12.2248 14.8375 13.2613 14.0284C14.2979 13.2193 15.0911 12.1311 15.5513 10.8872C16.0116 9.64318 16.1204 8.293 15.8655 6.98937C15.6106 5.68574 15.0022 4.4807 14.109 3.51059C13.2159 2.54048 12.0737 1.84401 10.8117 1.5" stroke="#1E59FF" strokeWidth="3" strokeLinecap="round"/>
                </svg>
                <p className="text-xs text-gray2 font-medium">3/3 - Xiemen Manufacturer</p>
                   </div>
                 </li>
            
                 <li>
                 <p className="text-xs text-gray2 font-medium">12 Apr 24</p>
                 </li>
               </ul>
             </div>
           </li>
     
        </ul>


    </div>
  )
}

export default ActivePaymentsOrders