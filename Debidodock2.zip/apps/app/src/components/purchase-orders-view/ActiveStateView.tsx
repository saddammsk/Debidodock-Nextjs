import RangeCalendarChart from '../common/RangeCalendarChart'
import ActivePaymentsOrders from './ActivePaymentsOrders'
import ActiveProductsOrders from './ActiveProductsOrders'
import ActiveSubOrders from './ActiveSubOrders'
import EstimatedChart from './charts/EstimatedChart'
import PurchaseOrdersSidebar from './PurchaseOrdersSidebar'
import StaticChartViewTop from './StaticChartViewTop'

const ActiveStateView = () => {
  return (
    <div className=' flex lg:pb-44 pb-10 w-full h-full'>
        <div className="w-full pt-10">
        <StaticChartViewTop/>

          <EstimatedChart /> 

          <RangeCalendarChart />  

          <ActiveSubOrders />   

          <ActivePaymentsOrders/>

          <ActiveProductsOrders/>    
            
        </div>

        <PurchaseOrdersSidebar/>
    </div>
  )
}

export default ActiveStateView