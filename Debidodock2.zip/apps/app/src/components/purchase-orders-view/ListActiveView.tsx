import { BellSimple, FunnelSimple, Kanban, List, MapTrifold } from "@phosphor-icons/react";
import { Button } from "@debido/ui/components/button";
import ActiveOrders from "./ActiveOrders";
import OnOrders from "./OnOrders";
import DraftsOrders from "./DraftsOrders";


const ListActiveView = () => {


return (
    
    <div className="w-full flex  h-full">
    <div className="w-full h-full pb-8">
    
    
        {/* Head */}
        <div className="flex items-center justify-between md:px-6 px-4 py-1.5 border-b border-gray4"> 
        <div className="flex items-center gap-1 py-2.5 text-xs font-medium text-gray1">
        <FunnelSimple size={16} className="text-gray2" />
        <h2 className="text-xs text-gray2">Filter</h2>
        </div>
        <div className="flex items-center gap-4">
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <BellSimple size={16}  weight="fill" />
        </Button>

        <ul className="flex items-center bg-black1 rounded-md border border-gray4">
          <li>
            <Button className={"bg-black2 hover:bg-black2 border border-gray4 text-gray1 shadow-none"}>
              <List size={18} />
            </Button>
          </li>
          <li>
            <Button className="text-gray2 hover:bg-black2 hover:border-gray4 hover:text-gray1 border border-transparent bg-transparent shadow-none">
              <Kanban size={18} />
            </Button>
          </li>
          <li>
            <Button className="text-gray2 hover:bg-black2 hover:border-gray4 hover:text-gray1 border border-transparent bg-transparent shadow-none">
              <MapTrifold size={18} />
            </Button>
          </li>
        </ul>
        </div>
      </div>


    <ActiveOrders/>

    <OnOrders/>

    <DraftsOrders/>


    </div>


   
    </div>
)}

export default ListActiveView