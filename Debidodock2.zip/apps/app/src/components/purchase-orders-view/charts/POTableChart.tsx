import {
    XAxis,
    ResponsiveContainer,
    YAxis,
    AreaChart,
    Area,
    ReferenceLine,
  } from "recharts";
  
  const data = [
    { name: "12 JUN", Revenue: 50 },
    { name: "17 JUN", Revenue: 70 },
    { name: "23 JUN", Revenue: 40 },
    { name: "28 JUN", Revenue: 80 },
    { name: "31 JUN", Revenue: 60 },
    { name: "5 JUL", Revenue: 100 },
    { name: "8 JUL", Revenue: 90 },
    { name: "13 JUL", Revenue: 120 },
    { name: "16 JUL", Revenue: 140 },
    { name: "14 JUL", Revenue: 260 },
    { name: "12 JUL", Revenue: 130 },
    { name: "19 JUL", Revenue: 210 },
    { name: "20 JUL", Revenue: 300 },
  ];
  
  const thresholds = [
    { value: 100, color: "rgba(255, 203, 17, 0.6)" },
    { value: 260, color: "rgba(38, 199, 150, 0.6)" },
    { value: 0, color: "rgba(0, 112, 255, 0.6)" }, 
  ];
  
  const chartConfig = {
    label: "Revenue",
    color: "hsl(var(--chart-1))",
  };
  
  const CustomXAxisTick = ({ x, y, payload }) => {
    return (
      <>
        <line
          x1={x - 20}
          y1={y - 5}
          x2={x - 20}
          y2={y - 10}
          stroke="rgba(255, 255, 255, 0.2)"
          strokeWidth={1}
        />
        <text
          x={x - 20}
          y={y + 10}
          fill="#B3B3B3"
          fontSize={10}
          textAnchor="middle"
        >
          {payload.value}
        </text>
      </>
    );
  };
  
  const POTableChart = () => {
    return (
      <div className="bg-black flex md:flex-row flex-col-reverse py-2 xl:pl-7 md:pl-4 px-1 text-white rounded-lg">
        <ResponsiveContainer width="100%" height={186}>
          <AreaChart
            data={data}
            margin={{
              top: 0,
              right: 0,
              left: 0,
              bottom: 0,
            }}
          >
            {/* Gradient Definitions */}
            <defs>
              <linearGradient id={chartConfig.label} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={chartConfig.color} stopOpacity={0.2} />
                <stop offset="60%" stopColor={chartConfig.color} stopOpacity={0.05} />
              </linearGradient>
            </defs>
  
            {thresholds.map((threshold, index) => (
              <ReferenceLine
                key={index}
                x={data.find((d) => d.Revenue >= threshold.value)?.name}
                stroke={threshold.color}
                strokeDasharray="4 4"
                strokeWidth={1}
                label={{
                  position: "top",
                  value: `${threshold.value}k`,
                  fontSize: 10,
                  fill: threshold.color,
                }}
              />
            ))}
  
            {/* Area with gradient */}
            <Area
              dataKey="Revenue"
              type="natural"
              fill={`url(#${chartConfig.label})`} 
              fillOpacity={1}
              stroke={chartConfig.color} 
            />
            <XAxis
              dataKey="name"
              tick={CustomXAxisTick}
              axisLine={false}
              tickLine={false}
              tickMargin={10}
            />
            <YAxis hide />
          </AreaChart>
        </ResponsiveContainer>
  
        {/* Additional Chart Details */}
        <div className="grid grid-cols-2 w-full items-center justify-center xl:max-w-[413px] xl:py-7 md:py-5 p-4 xl:px-16 md:px-6 xl:gap-5 gap-4 sm:justify-between">
          <div>
            <p className="text-xs text-gray2 font-medium mb-1">Revenue</p>
            <p className="text-2xl font-semibold text-gray1">230k</p>
          </div>
          <div>
            <p className="text-xs text-gray2 font-medium mb-1">Gross profit</p>
            <p className="text-2xl font-semibold text-gray1">73k</p>
          </div>
          <div>
            <p className="text-xs text-gray2 font-medium mb-1">Order cost</p>
            <p className="text-2xl font-semibold text-gray1">73k</p>
          </div>
          <div>
            <p className="text-xs text-gray2 font-medium mb-1">Breakeven revenue</p>
            <p className="text-2xl font-semibold text-gray1">73k</p>
          </div>
        </div>
      </div>
    );
  };
  
  export default POTableChart;
  