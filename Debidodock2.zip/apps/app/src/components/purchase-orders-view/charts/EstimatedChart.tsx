import { Area, AreaChart, CartesianGrid, ReferenceLine, XAxis, ReferenceArea } from "recharts";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "../../ui/chart";


const chartData = [
  { date: "10 APR", Balance: 261 },
  { date: "11 APR", Balance: 327 },
  { date: "12 APR", Balance: 292 },
  { date: "13 APR", Balance: 342 },
  { date: "14 APR", Balance: 137 },
  { date: "15 APR", Balance: 120 },
  { date: "16 APR", Balance: 138 },
  { date: "17 APR", Balance: 446 },
  { date: "18 APR", Balance: 364 },
  { date: "19 APR", Balance: 243 },
  { date: "20 APR", Balance: 89 },
  { date: "03 MAY", Balance: 247 },
  { date: "04 MAY", Balance: 385 },
  { date: "10 MAY", Balance: 293 },
  { date: "11 MAY", Balance: 335 },
  { date: "12 MAY", Balance: 197 },
  { date: "13 MAY", Balance: 197 },
  { date: "14 MAY", Balance: 448 },
  { date: "15 MAY", Balance: 473 },
  { date: "16 MAY", Balance: 338 },
  { date: "17 MAY", Balance: 499 },
  { date: "18 MAY", Balance: 315 },
  { date: "19 MAY", Balance: 235 },
  { date: "20 MAY", Balance: 177 },
  { date: "21 MAY", Balance: 82 },
  { date: "22 MAY", Balance: 81 },
  { date: "23 MAY", Balance: 252 },
  { date: "24 MAY", Balance: 294 },
  { date: "25 MAY", Balance: 201 },
  { date: "26 MAY", Balance: 213 },
  { date: "27 MAY", Balance: 420 },
  { date: "28 MAY", Balance: 233 },
  { date: "02 JUN", Balance: 470 },
  { date: "03 JUN", Balance: 103 },
  { date: "04 JUN", Balance: 439 },
  { date: "05 JUN", Balance: 88 },
  { date: "06 JUN", Balance: 294 },
  { date: "07 JUN", Balance: 323 },
  { date: "08 JUN", Balance: 385 },
  { date: "09 JUN", Balance: 438 },
  { date: "10 JUN", Balance: 155 },
  { date: "30 JUL", Balance: 580 },
];


const chartConfig = {
  Balance: {
    label: "Balance",
    color: "hsl(var(--chart-1))",
  },
};

const thresholds = [
  { value: 385, color: "rgba(255, 203, 17, 0.6)" },
  { value: 473, color: "rgba(38, 199, 150, 0.6)" },
  { value: 280, color: "rgba(0, 112, 255, 0.6)" },
  { value: 570, color: "rgba(255, 0, 0, 0.6)" },
];

const CustomXAxisTick = ({ x, y, payload }) => {
  return (
    <>
      <line
        x1={x - 20}
        y1={y - 5}
        x2={x - 20}
        y2={y - 10}
        stroke="rgba(255, 255, 255, 0.2)"
        strokeWidth={1}
      />
      <text x={x - 20} y={y + 10} fill="#B3B3B3" fontSize={10} textAnchor="middle">
        {payload.value}
      </text>
    </>
  );
};

export default function EstimatedChart() {
  return (
    <ChartContainer config={chartConfig} className="aspect-auto md:h-[469px] h-[300px] w-full pb-3">
      <AreaChart data={chartData}>
        <defs>
          <linearGradient id="fillBalance" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-Balance)" stopOpacity={0.2} />
            <stop offset="60%" stopColor="var(--color-Balance)" stopOpacity={0.05} />
          </linearGradient>

          {/* Dynamic gradient for area between thresholds */}
          <linearGradient id="gradientBetweenThresholds" x1="0" y1="1" x2="1" y2="1">
            <stop offset="0%" stopColor={thresholds[2].color} stopOpacity={0.1} />
            <stop offset="40%" stopColor={thresholds[2].color} stopOpacity={0} />
          </linearGradient>
          <linearGradient id="gradientBetweenThresholds2" x1="0" y1="1" x2="1" y2="1">
            <stop offset="0%" stopColor={thresholds[0].color} stopOpacity={0.1} />
            <stop offset="40%" stopColor={thresholds[0].color} stopOpacity={0} />
          </linearGradient>
          <linearGradient id="gradientBetweenThresholds3" x1="0" y1="1" x2="1" y2="1">
            <stop offset="0%" stopColor={thresholds[1].color} stopOpacity={0.1} />
            <stop offset="40%" stopColor={thresholds[1].color} stopOpacity={0} />
          </linearGradient>
          <linearGradient id="gradientBetweenThresholds4" x1="0" y1="1" x2="1" y2="1">
            <stop offset="0%" stopColor={thresholds[3].color} stopOpacity={0.1} />
            <stop offset="100%" stopColor={thresholds[3].color} stopOpacity={0} />
          </linearGradient>
        </defs>

        {/* Adding the dynamic gradient shading based on threshold values */}
        <ReferenceArea
          x1={chartData.find((d) => d.Balance >= thresholds[2].value)?.date}
          x2={chartData.find((d) => d.Balance >= thresholds[0].value)?.date}
          fill="url(#gradientBetweenThresholds)"
          stroke="none"
        />
        <ReferenceArea
          x1={chartData.find((d) => d.Balance >= thresholds[0].value)?.date}
          x2={chartData.find((d) => d.Balance >= thresholds[1].value)?.date}
          fill="url(#gradientBetweenThresholds2)"
          stroke="none"
        />

      <ReferenceArea
          x1={chartData.find((d) => d.Balance >= thresholds[3].value)?.date}
          x2={chartData.find((d) => d.Balance >= thresholds[1].value)?.date}
          fill="url(#gradientBetweenThresholds3)"
          stroke="none"
        />
        
      <ReferenceArea
          x1={chartData.find((d) => d.Balance >= thresholds[3].value)?.date}
          x2={chartData.find((d) => d.Balance >= thresholds[3].value)?.date}
          fill="url(#gradientBetweenThresholds4)"
          stroke="none"
        />

        {thresholds.map((threshold, index) => (
          <ReferenceLine
            key={index}
            x={chartData.find((d) => d.Balance >= threshold.value)?.date}
            stroke={threshold.color}
            strokeDasharray="4 4"
            strokeWidth={1}
            label={{
              position: "top",
              value: `${threshold.value}k`,
              fontSize: 10,
              fill: threshold.color,
            }}
          />
        ))}

        <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="var(--color-grid)" />
        <XAxis
          dataKey="date"
          tick={CustomXAxisTick}
          axisLine={false}
          tickLine={false}
          tickMargin={10}
        />

        <ChartTooltip
          content={
            <ChartTooltipContent
              labelFormatter={(value) =>
                new Date(value).toLocaleDateString("en-US", { month: "short", day: "numeric" })
              }
              indicator="dot"
            />
          }
        />
        <Area dataKey="Balance" type="natural" fill="url(#fillBalance)" stroke="var(--color-Balance)" stackId="a" />
      </AreaChart>
    </ChartContainer>
  );
}
