"use client";
import { RadialBarChart, RadialBar, PolarRadiusAxis } from "recharts";


interface ChartDataProps {
  SalesValue: number;
  EstimatedValue: number;
}

const chartData = [
  { name: "Progress", value: 58, fill: "hsl(var(--chart-2, 221, 100%, 50%))" },
];

export function RadialChart({SalesValue, EstimatedValue}: ChartDataProps) {

  return (
    <div className="relative flex justify-center items-center w-20 h-20">
      <RadialBarChart
        width={160}
        height={160}
        cx="50%"
        cy="50%"
        innerRadius="70%"
        outerRadius="100%"
        barSize={10}
        data={chartData}
        startAngle={90}
        endAngle={EstimatedValue}
      >
        <RadialBar
          dataKey="value"
          cornerRadius={10}
          background={{ fill: "hsl(var(--gray-9, 0, 0%, 10%))" }}
        />
        <PolarRadiusAxis
          type="number"
          domain={[0, 100]}
          axisLine={false}
          tick={false}
        />
      </RadialBarChart>

      <div className="absolute flex flex-col justify-center items-center">
        <span className="text-xs font-bold text-gray2">{SalesValue}%</span>
      </div>
    </div>
  );
}
