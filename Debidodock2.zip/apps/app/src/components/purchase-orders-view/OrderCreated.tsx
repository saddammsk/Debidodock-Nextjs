import { Button } from "@debido/ui/components/button";
import { Copy, Eye, X } from "@phosphor-icons/react";
import { useGlobalContext } from "../../context/GlobalContext";




 interface ModelProps{
    setShowNestedPopup: (showNested: boolean) => void,
  }


const OrderCreated = ({setShowNestedPopup}: ModelProps) => {

  const  {setShowPopup} = useGlobalContext();

  const handleAllVendors = () => {
    // This is where you would send the order to all vendors using your API
    // For demonstration purposes, I'm just logging the message
    setShowPopup(false)
    console.log("Sending order to all vendors");
  };

 
  return (
    <div className="w-full pb-10">
      <div className="w-full flex items-center justify-end md:p-6 p-4 mb-6">
        <Button onClick={()=>setShowNestedPopup(false)} className="!bg-transparent -mt-3 -mr-3">
          <X size={14} />
        </Button>
      </div>

      <div className="w-full text-center">
      <h2 className="text-2xl text-gray1 font-medium mb-3">Order created 🎉</h2>
      <p className="text-sm text-gray2 font-medium mb-4">Your orders is created! Share them with your vendors</p>
      <Button onClick={handleAllVendors}>
      Send to all vendors
      </Button>
      </div>

      <div className="w-full overflow-x-auto">
      <div className="w-full md:mt-[60px] mt-10 min-w-[460px]">
        {/* Head */}
        <div className="w-full grid grid-cols-3 md:gap-10  border border-gray4 py-3">
          <div className="px-6">
          <h3 className="text-xs text-gray2 font-medium">Vendor</h3>
          </div>
          <div className="px-6">
          <h3 className="text-xs text-gray2 font-medium">Email</h3>
          </div>
          <div className="px-6">
          </div>
        </div>

        {/* Body */}

        <div className="w-full">
          <ul className="w-full">
            <li className="w-full grid items-center md:gap-10 grid-cols-3 border-b border-gray4">
              <div className="md:pl-6 pl-3 pr-3 py-3">
                <div className="flex items-center gap-3 ">
                <h3 className="text-sm text-gray2 p-2.5 bg-black1 border border-gray4 inline-flex items-center justify-center rounded">LS</h3>
                <h4 className="text-sm text-gray1">Lopes Carvalho</h4>
              </div>
              </div>
              <div className="md:pl-6 pl-3 pr-3 py-3">
              <h4 className="text-sm text-gray2">ls@carvalho.com</h4>
              </div>
              <div className="md:pl-6 pl-3 pr-3 py-3">
              <div className="flex items-center gap-1.5">
              <Button className="bg-gray3 border border-gray4">
                <Eye size={18} />
              </Button>
              <Button className="bg-gray3 border border-gray4">
                <Copy size={18} />
              </Button>
              <Button className="">
              Send
              </Button>
             </div>
              </div>
          
            </li>
            <li className="w-full grid items-center md:gap-10 grid-cols-3 border-b border-gray4">
              <div className="md:pl-6 pl-3 pr-3 py-3">
                <div className="flex items-center gap-3 ">
                <h3 className="text-sm text-gray2 p-2.5 bg-black1 border border-gray4 inline-flex items-center justify-center rounded">LS</h3>
                <h4 className="text-sm text-gray1">Lopes Carvalho</h4>
              </div>
              </div>
              <div className="md:pl-6 pl-3 pr-3 py-3">
              <h4 className="text-sm text-gray2">ls@carvalho.com</h4>
              </div>
              <div className="md:pl-6 pl-3 pr-3 py-3">
              <div className="flex items-center gap-1.5">
              <Button className="bg-gray3 border border-gray4">
                <Eye size={18} />
              </Button>
              <Button className="bg-gray3 border border-gray4">
                <Copy size={18} />
              </Button>
              <Button className="">
              Send
              </Button>
             </div>
              </div>
          
            </li>
          
          </ul>
        </div>
        </div>

      </div>


   </div>
  )
}

export default OrderCreated