import { Button } from '@debido/ui/components/button'
import { CaretRight, CaretUpDown, Pulse } from '@phosphor-icons/react'
import { useGlobalContext } from '../../context/GlobalContext'

const ActiveOrders = () => {
  const {setShowActiveOrder} = useGlobalContext()




  return (
    <div>
        <div className="flex bg-black1 items-center justify-between lg:px-6 px-4 h-11 border-b border-gray4"> 
        <div className="flex items-center gap-2 py-2.5 text-xs font-medium text-gray1">
        <Pulse size={16} className="text-blue2" />
        <h2 className="text-xs text-gray1">Active</h2>
        </div>
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent gap-2 shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <CaretUpDown size={16} />
        Sort
        </Button>
      </div>


        {/*Active Body */} 
        <ul>
             <li className="!bg-black2 w-full flex lg:flex-row flex-col gap-3 items-center justify-between lg:px-6 px-3 py-1.5 border-b border-gray4"> 
             <div className="flex items-center lg:w-fit w-full gap-2 text-xs font-medium text-gray1">
             <button onClick={()=>setShowActiveOrder(true)} className="flex flex-wrap items-center gap-2">
             <h3 className="text-sm text-gray2 whitespace-nowrap font-medium text-start uppercase">PO-01</h3>
             <Pulse size={18} className='text-blue2' />
             <h3 className="text-sm text-gray2 font-medium whitespace-nowrap text-start">Winter order</h3>
             <div  className="flex items-center gap-2">
               <CaretRight size={10} className="text-gray2 text-start" />
             </div>
               <p className="text-sm text-gray1 ">Xiemen Manufacturer Lettbutikk</p>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                 <svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 8.37867C2 9.70784 2.36565 11.0105 3.05558 12.1392C3.74552 13.2679 4.73219 14.1777 5.90398 14.7656C7.07576 15.3535 8.38589 15.596 9.68612 15.4657C10.9864 15.3354 12.2248 14.8375 13.2613 14.0284C14.2979 13.2193 15.0911 12.1311 15.5513 10.8872C16.0116 9.64318 16.1204 8.293 15.8655 6.98937C15.6106 5.68574 15.0022 4.4807 14.109 3.51059C13.2159 2.54048 12.0737 1.84401 10.8117 1.5" stroke="#1E59FF" strokeWidth="3" strokeLinecap="round"/>
                    </svg>
                   <p className="text-xs font-medium">240/280</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-blue2"></div>
                   <p className="text-xs font-medium py-1.5">Delivered</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">12 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                   <p className="text-xs text-gray2 font-medium">12 Jun 24</p>
                 </li>
               </ul>
             </div>
           </li>
           <li className="!bg-black2 w-full flex lg:flex-row flex-col gap-3 items-center justify-between lg:px-6 px-3 py-1.5 border-b border-gray4"> 
             <div className="flex items-center lg:w-fit w-full gap-2 text-xs font-medium text-gray1">
             <button onClick={()=>setShowActiveOrder(true)} className="flex flex-wrap items-center gap-2">
             <h3 className="text-sm text-gray2 whitespace-nowrap font-medium text-start uppercase">PO-01</h3>
             <Pulse size={18} className='text-blue2' />
             <h3 className="text-sm text-gray2 font-medium whitespace-nowrap text-start">Winter order</h3>
             <div  className="flex items-center gap-2">
               <CaretRight size={10} className="text-gray2 text-start" />
             </div>
               <p className="text-sm text-gray1 ">Xiemen Manufacturer Lettbutikk</p>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                 <svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 8.37867C2 9.70784 2.36565 11.0105 3.05558 12.1392C3.74552 13.2679 4.73219 14.1777 5.90398 14.7656C7.07576 15.3535 8.38589 15.596 9.68612 15.4657C10.9864 15.3354 12.2248 14.8375 13.2613 14.0284C14.2979 13.2193 15.0911 12.1311 15.5513 10.8872C16.0116 9.64318 16.1204 8.293 15.8655 6.98937C15.6106 5.68574 15.0022 4.4807 14.109 3.51059C13.2159 2.54048 12.0737 1.84401 10.8117 1.5" stroke="#1E59FF" strokeWidth="3" strokeLinecap="round"/>
                    </svg>
                   <p className="text-xs font-medium">240/280</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-blue2"></div>
                   <p className="text-xs font-medium py-1.5">Delivered</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">12 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                   <p className="text-xs text-gray2 font-medium">12 Jun 24</p>
                 </li>
               </ul>
             </div>
           </li>
           <li className="!bg-black2 w-full flex lg:flex-row flex-col gap-3 items-center justify-between lg:px-6 px-3 py-1.5 border-b border-gray4"> 
             <div className="flex items-center lg:w-fit w-full gap-2 text-xs font-medium text-gray1">
             <button onClick={()=>setShowActiveOrder(true)} className="flex flex-wrap items-center gap-2">
             <h3 className="text-sm text-gray2 whitespace-nowrap font-medium text-start uppercase">PO-01</h3>
             <Pulse size={18} className='text-blue2' />
             <h3 className="text-sm text-gray2 font-medium whitespace-nowrap text-start">Winter order</h3>
             <div  className="flex items-center gap-2">
               <CaretRight size={10} className="text-gray2 text-start" />
             </div>
               <p className="text-sm text-gray1 ">Restock of caps</p>
             </button>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                 <svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 8.37867C2 9.70784 2.36565 11.0105 3.05558 12.1392C3.74552 13.2679 4.73219 14.1777 5.90398 14.7656C7.07576 15.3535 8.38589 15.596 9.68612 15.4657C10.9864 15.3354 12.2248 14.8375 13.2613 14.0284C14.2979 13.2193 15.0911 12.1311 15.5513 10.8872C16.0116 9.64318 16.1204 8.293 15.8655 6.98937C15.6106 5.68574 15.0022 4.4807 14.109 3.51059C13.2159 2.54048 12.0737 1.84401 10.8117 1.5" stroke="#1E59FF" strokeWidth="3" strokeLinecap="round"/>
                    </svg>
                   <p className="text-xs font-medium">240/280</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-blue2"></div>
                   <p className="text-xs font-medium py-1.5">Delivered</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">12 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                   <p className="text-xs text-gray2 font-medium">12 Jun 24</p>
                 </li>
               </ul>
             </div>
           </li>
     
        </ul>


    </div>
  )
}

export default ActiveOrders