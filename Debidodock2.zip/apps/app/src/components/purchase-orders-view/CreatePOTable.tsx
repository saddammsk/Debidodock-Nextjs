import { ArrowsLeftRight, ChartLine, Check, MapPin } from "@phosphor-icons/react";
import { useEffect, useState } from "react";

const CreatePOTable = () => {
  const [isMasterChecked, setIsMasterChecked] = useState<boolean>(false);

  useEffect(() => {
    const checkboxes = document.querySelectorAll("#tbody input[type='checkbox']") as NodeListOf<HTMLInputElement>;

    checkboxes.forEach((checkbox) => {
      checkbox.checked = isMasterChecked;
    });
  }, [isMasterChecked]);

  const handleMasterCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setIsMasterChecked(e.target.checked);
  };

  const dummyData = [
    {
      id: 1,
      imgUrl: '/images/inventory-user-img.png',
      name: "Velour Caps",
      quantity: 0,
      days: 0,
      unitCost: 50,
      moq: 0,
      revenue: "212,479 NOK",
      grossProfit: "12,479 NOK",
      margin: "16%",
      location: "Lettbutikk",
    },
    {
      id: 2,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 3,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 4,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 5,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 6,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 7,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 8,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 9,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 10,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
    {
      id: 11,
      imgUrl: '/images/inventory-user-img.png',
      name: "Cotton Shirts",
      quantity: 5,
      days: 2,
      unitCost: 30,
      moq: 10,
      revenue: "150,000 NOK",
      grossProfit: "10,000 NOK",
      margin: "10%",
      location: "Shirt Store",
    },
  ];

  return (
    <div className="w-full overflow-auto">
      <table className="w-full min-w-[1024px]">
        <thead className="w-full">
          <tr className="w-full border-b border-gray4">
            <th className="text-xs text-gray2 font-medium xl:px-4 px-3 py-2.5 border-r border-gray4">
              <div className="flex items-center gap-2">
                <label htmlFor="variants-checkbox" className="relative flex items-center justify-center">
                  <input
                    onChange={handleMasterCheckboxChange}
                    checked={isMasterChecked}
                    type="checkbox"
                    id="variants-checkbox"
                    className="peer rounded checked:bg-blue2 bg-transparent w-4 h-4 border border-gray5 appearance-none"
                  />
                  <Check size={10} className="peer-checked:block text-gray1 hidden absolute" />
                </label>
                Variants
              </div>
            </th>
            <th className="text-xs text-gray2 font-medium xl:pl-6 xl:pr-4 px-3 py-2.5 text-start">Quantity</th>
            <th className="text-xs text-gray2 font-medium xl:px-4 px-2 py-2.5 text-start">Unit cost</th>
            <th className="text-xs text-gray2 font-medium xl:px-4 px-2 py-2.5 text-start">MOQ</th>
            <th className="text-xs text-gray2 font-medium xl:px-4 px-2 py-2.5 text-start">Revenue</th>
            <th className="text-xs text-gray2 font-medium xl:px-4 px-2 py-2.5 text-start">Gross profit</th>
            <th className="text-xs text-gray2 font-medium xl:px-4 px-2 py-2.5 text-start">Gross margin</th>
            <th className="text-xs text-gray2 font-medium xl:px-4 px-2 py-2.5 text-start">Location</th>
          </tr>
        </thead>
        <tbody id="tbody">
          {dummyData.map((row) => (
            <tr key={row.id} className="bg-black2 border-b border-gray4">
              <td className="xl:px-4 px-3 py-2.5 border-r border-gray4">
                <div className="flex items-center gap-2">
                  <label htmlFor={`checkbox-${row.id}`} className="relative flex items-center justify-center">
                    <input
                      type="checkbox"
                      id={`checkbox-${row.id}`}
                      className="peer rounded checked:bg-blue2 bg-transparent w-4 h-4 border border-gray5 appearance-none"
                    />
                    <Check size={10} className="peer-checked:block text-gray1 hidden absolute" />
                  </label>
                  <img src={row.imgUrl} alt="avatar" className="w-6 h-6 rounded bg-cover" />
                  <h3 className="xl:text-sm text-xs text-gray1 font-medium ml-1">{row.name}</h3>
                  <ChartLine size={18} className="text-gray2 ml-auto" />
                </div>
              </td>
              <td className="xl:pl-6 xl:pr-4 px-3 py-2.5">
                <div className="w-full flex items-center gap-2">
                  <label htmlFor={`quantity-${row.id}`} className="bg-gray6 relative rounded-md inline-flex py-2 gap-5 h-9 border border-gray4 items-center px-3">
                    <input
                      type="number"
                      defaultValue={row.quantity}
                      id={`quantity-${row.id}`}
                      placeholder="0"
                      className="no-spin-buttons w-14 pr-9 bg-transparent outline-none text-xs text-gray1 font-medium"
                    />
                    <h3 className="text-xs text-gray1 font-medium absolute right-3 bg-gray6">items</h3>
                  </label>
                  <ArrowsLeftRight size={14} className="text-gray2" />
                  <label htmlFor={`days-${row.id}`} className="bg-gray6 relative rounded-md inline-flex py-2 gap-5 h-9 border border-gray4 items-center px-3">
                    <input
                      type="number"
                      defaultValue={row.days}
                      id={`days-${row.id}`}
                      placeholder="0"
                      className="no-spin-buttons w-14 pr-8 bg-transparent outline-none text-xs text-gray1 font-medium"
                    />
                    <h3 className="text-xs text-gray1 font-medium absolute right-3 bg-gray6">days</h3>
                  </label>
                </div>
              </td>
              <td className="xl:px-4 px-3 py-2.5">
                <div className="bg-gray6 rounded-md inline-flex py-2 gap-3 pr-8 h-9 border border-gray4 items-start px-3">
                  <h3 className="text-xs text-gray2 font-medium">€</h3>
                  <h3 className="text-xs text-gray1 font-medium uppercase">{row.unitCost}</h3>
                </div>
              </td>
              <td className="xl:px-4 px-3 py-2.5">
                <div className="bg-gray6 rounded-md inline-flex py-2 gap-5 h-9 border border-gray4 items-start px-3">
                  <h3 className="text-xs text-gray1 font-medium">{row.moq}</h3>
                  <h3 className="text-xs text-gray2 font-medium uppercase">MOQ</h3>
                </div>
              </td>
              <td className="xl:px-4 px-3 py-2.5">
                <h3 className="xl:text-sm text-xs text-gray2 font-medium uppercase">{row.revenue}</h3>
              </td>
              <td className="xl:px-4 px-3 py-2.5">
                <h3 className="text-xs text-gray1 font-medium uppercase">{row.grossProfit}</h3>
              </td>
              <td className="xl:px-4 px-3 py-2.5">
                <h3 className="xl:text-sm text-xs text-gray2 font-medium">{row.margin}</h3>
              </td>
              <td className="xl:px-4 px-3 py-2.5">
                <div className="inline-flex gap-1.5 items-center">
                  <MapPin weight="fill" className="text-gray2" size={18} />
                  <h3 className="text-xs text-gray2 font-medium">{row.location}</h3>
                </div>
              </td>
            </tr>
          ))}
             {/* Don't delete this tr */}
             <tr className="bg-black2 border-b border-gray4">
              <td scope="row" className="px-4 py-10 border-r border-gray4">
                </td>
                <td className="xl:pl-6 xl:pr-4 px-3 py-2.5">
                </td>
                <td className="xl:px-4 px-3 py-2.5">
                </td>
                <td className="xl:px-4 px-3 py-2.5">
                </td>
                <td className="xl:px-4 px-3 py-2.5">
                </td>
                <td className="xl:px-4 px-3 py-2.5">
                </td>
                <td className="xl:px-4 px-3 py-2.5">
                </td>
                <td className="xl:px-4 px-3 py-2.5">
                </td>
              </tr>
        </tbody>
      </table>
    </div>
  );
};

export default CreatePOTable;
