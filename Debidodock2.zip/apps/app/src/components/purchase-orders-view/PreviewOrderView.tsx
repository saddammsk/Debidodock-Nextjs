import { Button } from "@debido/ui/components/button";
import { ArrowLeft, X } from "@phosphor-icons/react";
import CalenderChart from "./charts/CalenderChart";
import ActiveSubOrders from "./ActiveSubOrders";
import ActivePaymentsOrders from "./ActivePaymentsOrders";
import { useState } from "react";
import NestedPopup from "./NestedPopup";
import OrderCreated from "./OrderCreated";
import PreviewOrderChart from "./charts/PreviewOrderChart";
import RangeCalendarChart from "../common/RangeCalendarChart";



 interface ModelProps{
    setShowNestedPopup: (showNested: boolean) => void,
  }


const PreviewOrderView = ({setShowNestedPopup}: ModelProps) => {

  const [showCreateedOrderModel,  setShowCreateedOrderModel] = useState<boolean>(false);


   
  return (
    <div className="w-full pb-16">
    <div className="flex items-center justify-between lg:p-6 p-4 sm:pb-10"> 
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
      <button onClick={()=>setShowNestedPopup(false)} className="flex items-center md:gap-3 gap-2 w-full">
        <ArrowLeft size={18} className="text-gray2" />
        <h4 className="text-sm text-gray1">SS22</h4>
      </button>
        
    </div>

    <div className="flex items-center md:gap-14 gap-3">
      <label htmlFor="po-wms" className="relative text-xs gap-1 hidden text-gray2 sm:flex items-center">
      Create PO in <span className="underline">WMS</span>
        <div className="relative flex items-center transition-all duration-300">
        <input type="checkbox" id="po-wms" className="peer appearance-none w-7 h-4 bg-gray4 rounded-full border border-gray5 checked:bg-blue2" />
        <span className="w-3 h-3 rounded-full bg-white block absolute left-1 peer-checked:left-3.5"></span>
        </div>
      </label>

      <div className="flex item-center gap-2">
        <Button className="bg-transparent text-xs border border-gray5 text-gray1 font-medium">
        Save draft
        </Button>
        <Button onClick={()=>setShowCreateedOrderModel(true)} className="text-xs text-gray1 font-medium">
        Create order
        </Button>
        <Button className="!bg-transparent -mr-2 -mt-2 lg:hidden flex" onClick={()=>setShowNestedPopup(false)}>
          <X size={14}/>
        </Button>

        <NestedPopup
        showNested={showCreateedOrderModel}
        setShowNestedPopup={setShowCreateedOrderModel}
        panelClass="max-w-[652px]"
        >
        <OrderCreated setShowNestedPopup={setShowCreateedOrderModel}/>

        </NestedPopup>

      </div>
    </div>

  </div>

     <div className="w-full">
     <label htmlFor="po-wms-2" className="relative text-xs gap-1 mx-6 mb-6 flex text-gray2 sm:hidden items-center">
      Create PO in <span className="underline">WMS</span>
        <div className="relative flex items-center transition-all duration-300">
        <input type="checkbox" id="po-wms-2" className="peer appearance-none w-7 h-4 bg-gray4 rounded-full border border-gray5 checked:bg-blue2" />
        <span className="w-3 h-3 rounded-full bg-white block absolute left-1 peer-checked:left-3.5"></span>
        </div>
      </label>

       {/* Additional Chart Details */}
       <ul className="grid md:grid-cols-5 grid-cols-2 w-full lg:pb-10 pb-5 lg:px-16 px-8 gap-5 justify-between">
          <li>
            <p className="text-xs text-gray2 font-medium mb-1">Revenue</p>
            <p className="lg:text-3xl text-2xl font-semibold text-gray1">230k</p>
          </li>
          <li>
            <p className="text-xs text-gray2 font-medium mb-1">Gross profit</p>
            <p className="lg:text-3xl text-2xl font-semibold text-gray1">73k</p>
          </li>
          <li>
            <p className="text-xs text-gray2 font-medium mb-1">Gross margin</p>
            <p className="lg:text-3xl text-2xl font-semibold text-gray1">36%</p>
          </li>
          <li>
            <p className="text-xs text-gray2 font-medium mb-1">Order cost</p>
            <p className="lg:text-3xl text-2xl font-semibold text-gray1">43k</p>
          </li>
          <li>
            <p className="text-xs text-gray2 font-medium mb-1">Breakeven revenue</p>
            <p className="lg:text-3xl text-2xl font-semibold text-gray1">173k</p>
          </li>
        </ul>

      <PreviewOrderChart/>

      <div className="w-full">
        <RangeCalendarChart/>
      <ActiveSubOrders/>

      <ActivePaymentsOrders/>

      </div>
  </div>
  </div>
  )
}

export default PreviewOrderView