import { Button } from "@debido/ui/components/button";
import { CaretRight,  X } from "@phosphor-icons/react";
import SalesPerDayChart from "./charts/SalesPerDayChart";



 interface ModelProps{
    setShowNestedPopup: (showNested: boolean) => void,
  }


const VariantForecast = ({setShowNestedPopup}: ModelProps) => {

   

  return (
    <div className="w-full">
    <div className="flex items-center justify-between md:p-6 p-4 pb-4"> 
    <div className="flex items-center gap-2 text-xs font-medium text-gray1">
      <div className="flex items-center gap-1.5 w-full">
        <img src="/images/inventory-user-img.png" className="w-[22px] h-[22px] rounded bg-cover" alt="" />
        <p className="text-xs text-gray2 ml-2">Velour</p>
        <CaretRight size={10} className="text-gray2" />
        <h4 className="text-sm text-gray1">Caps red</h4>
      </div>
        
    </div>
    <Button onClick={()=>setShowNestedPopup(false)} className="flex -mt-3 -mr-3 bg-transparent hover:bg-transparent gap-2 shadow-none border border-transparent hover:text-gray1 items-center text-xs font-medium text-gray2">
    <X size={16} />
    </Button>
  </div>

      <form>
     <div className="w-full">
      <h3 className="px-6 text-gray2 text-sm font-medium">Sales per day</h3>
      <SalesPerDayChart/>

      <div className="w-full sm:px-6 px-3 md:py-11 py-8">
        <div className="flex items-center justify-between sm:gap-12 gap-6 mb-8">
        <div className="w-full">
          <h3 className="text-sm text-gray1 font-medium mb-1">Avg sales per day</h3>
          <p className="text-xs text-gray2 font-medium">Calculated based on last year sales and last month sales.</p>
        </div>
          <input type="number" id="Avg-sales-per-day" name="AvgSalesDay" placeholder="0.2" className="w-full text-gray1 text-xs bg-gray6 rounded-md max-w-[166px] h-9 px-4 border border-gray4" />
        </div>

        <div className="flex items-center justify-between sm:gap-12 gap-6">
        <div className="w-full">
          <h3 className="text-sm text-gray1 font-medium mb-1">Sales growth</h3>
          <p className="text-xs text-gray2 font-medium">How much this specific variant will grow in sales</p>
        </div>
          <label htmlFor="Sales-growth" className="relative w-full flex items-center max-w-[166px]">
            <span className="absolute text-xs text-gray2 left-3">%</span>
          <input type="number" id="Sales-growth" name="Salesgrowth" placeholder="10" className="w-full text-gray1 text-xs bg-gray6 rounded-md max-w-[166px] h-9 pl-7 pr-3 border border-gray4" />
          </label>
        </div>

      </div>
  </div>
  </form>
  </div>
  )
}

export default VariantForecast