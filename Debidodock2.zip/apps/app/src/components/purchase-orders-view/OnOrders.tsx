import { Button } from '@debido/ui/components/button'
import { CaretRight, CaretUpDown, Factory, Package, SpinnerGap } from '@phosphor-icons/react'
import { useGlobalContext } from '../../context/GlobalContext'


const OnOrders = () => {

  const {setShowActiveOrder} = useGlobalContext()

  return (
    <div>
        <div className="flex bg-black1 items-center justify-between md:px-6 px-4 h-11 border-b border-gray4"> 
        <div className="flex items-center gap-2 py-2.5 px-2 text-xs font-medium text-gray1">
        <SpinnerGap size={16} className="text-yellow1" />
        <h2 className="text-xs text-gray1">on orders</h2>
        </div>
        <Button className="flex bg-transparent py-2.5 px-2 hover:bg-transparent gap-2 shadow-none border border-transparent hover:border-blue4 hover:text-gray1 items-center text-xs font-medium text-gray2">
        <CaretUpDown size={16} />
        Sort
        </Button>
      </div>

            {/*On Orders Body */}
            <ul>
             <li className="!bg-black2 w-full flex lg:flex-row flex-col gap-3 items-center justify-between lg:px-6 px-3 py-1.5 border-b border-gray4"> 
             <div className="flex items-center lg:w-fit w-full gap-2 text-xs font-medium text-gray1">
             <div  onClick={()=>setShowActiveOrder(true)}  className="flex cursor-pointer items-center gap-2 flex-wrap">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-01</h3>
             <SpinnerGap size={18} className='text-yellow1' />
             <h3 className="text-sm text-gray2 font-medium whitespace-nowrap">Winter order</h3>
             <div onClick={()=>setShowActiveOrder(true)}  className="flex items-center gap-2">
               <CaretRight size={10} className="text-gray2" />
             </div>
               <p className="text-sm text-gray1 ">Xiemen Manufacturer Lettbutikk</p>
             </div>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
               <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <Package size={18} />
                   <p className="text-xs font-medium">In delivery</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">250 items</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-yellow1"></div>
                   <p className="text-xs font-medium py-1.5">Est delivery</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">112 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                   <p className="text-xs text-gray2 font-medium">12 Jun 24</p>
                 </li>
               </ul>
             </div>
           </li>
           <li className="!bg-black2 w-full flex lg:flex-row flex-col gap-3 items-center justify-between lg:px-6 px-3 py-1.5 border-b border-gray4  "> 
             <div className="flex items-center lg:w-fit w-full gap-2 text-xs font-medium text-gray1">
             <div onClick={()=>setShowActiveOrder(true)}  className="flex cursor-pointer items-center gap-2 flex-wrap">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-01</h3>
             <SpinnerGap size={18} className='text-yellow1' />
             <h3 className="text-sm text-gray2 font-medium whitespace-nowrap">Winter order</h3>
             <div  className="flex items-center gap-2">
               <CaretRight size={10} className="text-gray2" />
             </div>
               <p className="text-sm text-gray1 ">Xiemen Manufacturer Lettbutikk</p>
             </div>  
             </div>
             <div className='md:w-fit w-full'>
               <ul className="flex items-center gap-1.5 flex-wrap justify-end">
               <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <img src="/images/ongoing-symbol.svg" className='w-4' alt=''/>
                   <p className="text-xs font-medium">PO77</p>
                   </div>
                 </li>
               <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <Factory size={18} />
                   <p className="text-xs font-medium">In production</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">250 items</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-yellow1"></div>
                   <p className="text-xs font-medium py-1.5">Est delivery</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">112 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                   <p className="text-xs text-gray2 font-medium">12 Jun 24</p>
                 </li>
               </ul>
             </div>
           </li>
      
           <li className="!bg-black2 w-full flex lg:flex-row flex-col gap-3 items-center justify-between lg:px-6 px-3 py-1.5 border-b border-gray4  "> 
             <div  className="flex items-center lg:w-fit w-full gap-2 text-xs font-medium text-gray1">
             <div  onClick={()=>setShowActiveOrder(true)}  className="flex cursor-pointer items-center gap-2 flex-wrap">
             <h3 className="text-sm text-gray2 font-medium uppercase whitespace-nowrap">PO-03</h3>
             <SpinnerGap size={18} className='text-yellow1' />
               <p className="text-sm text-gray1 ">Restock of caps</p>
             </div>  
             </div>
             <div className='md:w-fit w-full'>
             <ul className="flex items-center gap-1.5 flex-wrap justify-end">
               <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <img src="/images/shiphero.png" className='w-4' alt=''/>
                   <p className="text-xs font-medium">PO77</p>
                   </div>
                 </li>
               <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                    <Factory size={18} />
                   <p className="text-xs font-medium">In production</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">250 items</p>
                   </div>
                 </li>
                 <li>
                 <div className="rounded-full text-gray2 inline-flex gap-1.5 px-2.5 py-1.5 items-center border border-gray4">
                   <p className="text-xs font-medium">13 SKU’s</p>
                   </div>
                 </li>
                 
                 <li>
                 <div className="rounded-full relative text-gray2 inline-flex gap-1.5 px-2.5 border border-gray4">
                    <div className="flex items-center justify-center gap-1.5">
                   <div className="w-2 h-2 flex rounded-full bg-yellow1"></div>
                   <p className="text-xs font-medium py-1.5">Est delivery</p>
                   </div>
                   <div className="border-r"></div>
                   <p className="text-xs font-medium py-1.5">112 Jun 24</p>
                   </div>
                 </li>
            
                 <li>
                   <p className="text-xs text-gray2 font-medium">12 Jun 24</p>
                 </li>
               </ul>
             </div>
           </li>
           </ul>
    </div>
  )
}

export default OnOrders