import { Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/react'
import { Bell, CaretDown, Plus } from '@phosphor-icons/react'
import { Link } from '@tanstack/react-router'

function UserDetail() {
  return (
    <>
       <div className='w-full flex items-center justify-between px-2.5'>
            <div className='flex items-center '>
            <div className="w-[22px] h-[22px] bg-gray6 rounded mr-1.5 cursor-pointer">
                <img src="/images/dashboard-user-img-1.png" alt="user img" className='w-full h-full bg-cover' />
            </div>
            <div>
            <Menu>
            <MenuButton className="text-xs text-gray1 font-medium flex items-center gap-1.5"><span>Vivvoe</span>
            <CaretDown size={16} className='text-gray2' weight="bold" />
            </MenuButton>
            <MenuItems anchor="bottom" className="bg-black2 py-3 space-y-3 px-5 text-white border border-gray4 rounded-lg">
                <MenuItem>
                <a className="block text-sm hover:text-blue1 transition-all data-[focus]:bg-blue-100" href="/settings">
                    Settings
                </a>
                </MenuItem>
                <MenuItem>
                <a className="block text-sm hover:text-blue1 transition-all data-[focus]:bg-blue-100" href="/support">
                    Support
                </a>
                </MenuItem>
                <MenuItem>
                <a className="block text-sm hover:text-blue1 transition-all data-[focus]:bg-blue-100" href="/license">
                    License
                </a>
                </MenuItem>
            </MenuItems>
            </Menu>
            </div>
            </div>

            <div className='flex items-center gap-3'>
                <Link to="/dashboard/overview"><Bell size={20} weight="bold" className='text-gray2' /> </Link>
                <Link to="/dashboard/overview"><Plus size={20} weight="bold" className='text-gray2' /> </Link>
            </div>

        </div>

 
    </>
  )
}

export default UserDetail