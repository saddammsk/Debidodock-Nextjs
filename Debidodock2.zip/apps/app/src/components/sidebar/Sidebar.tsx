import React from 'react'
import UserDetail from './UserDetail'
import { CreditCard, SquaresFour, Tag } from '@phosphor-icons/react'
import { Link, useRouter } from '@tanstack/react-router'
import PurchaseOrder from './PurchaseOrder'



const Sidebar = () => {

    const router  = useRouter()
    const currentPath = router.latestLocation.pathname;  

  return (
    <aside className='w-full max-w-[222px] px-2 py-5'>
        <UserDetail/>
        <ul className='w-full mt-7 flex flex-col gap-1'>
            <li>
                <Link href="/dashboard/overview" className={`${currentPath === "/dashboard/overview" && "bg-gray6 !text-gray1"}`+
                 ' text-gray2 font-medium flex items-center gap-2 rounded p-2 text-sm transition-all duration-300 hover:bg-gray6 hover:text-gray1' }>
                <SquaresFour size={20} />
                <span>Overview</span>
                </Link>
            </li>
            <li>
            <Link href="/dashboard/finance" className={`${currentPath === "/dashboard/finance" && "bg-gray6"}`+
                 ' text-gray2 flex font-medium items-center gap-2 rounded p-2 text-sm transition-all duration-300 hover:bg-gray6 hover:text-gray1' }>
                <CreditCard size={20} />
                <span>Finance</span>
                </Link>
            </li>
            <li>
            <Link href="/dashboard/products" className={`${currentPath === "/dashboard/products" && "bg-gray6"}`+
                 ' text-gray2 flex font-medium items-center gap-2 rounded p-2 text-sm transition-all duration-300 hover:bg-gray6 hover:text-gray1' }>
               <Tag size={20} />
                <span>Products</span>
                </Link>
            </li>
            <li>
                <PurchaseOrder/>
            </li>
        </ul>
    </aside>
  )
}

export default Sidebar