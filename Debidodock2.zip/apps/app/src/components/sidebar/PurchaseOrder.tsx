import { Button } from '@debido/ui/components/button'
import { Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/react'
import { CaretDown, Circle, ListBullets, Package, Pulse, SpinnerGap, Tray } from '@phosphor-icons/react'


export default function PurchaseOrder() {
  return (
    <div className="relative w-full max-w-[222px]">
      <Menu as="div" className="relative">
      <MenuButton className="text-gray2 w-full flex font-medium items-center gap-2 rounded p-2 text-sm transition-all duration-300 hover:bg-gray6 hover:text-gray1">
      <Package size={20} />
        <span>Purchase orders</span>
        <CaretDown size={16} />
        </MenuButton>
      <MenuItems as="div"  className="text-gray2 mt-2 px-1.5 left-0 text-start border-l w-full max-w-[90%] mx-auto border-gray5">
        <MenuItem>
        <div className='flex items-center justify-between gap-5'>
          <Button className="data-[focus]:bg-blue-100 font-medium bg-transparent p-1.5 rounded transition-all duration-300 hover:text-gray1 flex items-center hover:bg-transparent text-gray2 text-xs gap-2">
          <ListBullets size={20} />
          All
          </Button>
          <span className='text-xs text-gray2'>3</span>
          </div>
        </MenuItem>
        <MenuItem>
        <div className='flex items-center justify-between gap-5'>
          <Button className="data-[focus]:bg-blue-100 font-medium bg-transparent p-1.5 rounded transition-all duration-300 hover:text-gray1 flex items-center hover:bg-transparent text-gray2 text-xs gap-2">
          <Pulse size={20} className='text-blue1' />
          Active
          </Button>
          <span className='text-xs text-gray2'>3</span>
          </div>
        </MenuItem>
        <MenuItem>
        <div className='flex items-center justify-between gap-5'>
          <Button className="data-[focus]:bg-blue-100 font-medium bg-transparent p-1.5 rounded transition-all duration-300 hover:text-gray1 flex items-center hover:bg-transparent text-gray2 text-xs gap-2">
          <SpinnerGap size={20} className='text-yellow1' />
          On order
          </Button>
          </div>
        </MenuItem>
        <MenuItem>
        <div className='flex items-center justify-between gap-5'>
          <Button className="data-[focus]:bg-blue-100 bg-transparent p-1.5 rounded transition-all duration-300 hover:text-gray1 flex items-center hover:bg-transparent text-gray2 text-xs gap-2">
          <Circle size={20} />
          Drafts
          </Button>
          </div>
        </MenuItem>
        <MenuItem>
        <div className='flex items-center justify-between gap-5'>
          <Button className="data-[focus]:bg-blue-100 bg-transparent p-1.5 rounded transition-all duration-300 hover:text-gray1 flex items-center hover:bg-transparent text-gray2 text-xs gap-2">
          <Tray size={20} />
          Archived
          </Button>
          </div>
        </MenuItem>
        
      </MenuItems>
    </Menu>
    </div>
  )
}
