import AvatarLogo from "@debido/ui/components/avatar-logo";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuPortal,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@debido/ui/components/dropdown-menu";
import {
  CaretDown,
  Desktop,
  Ghost,
  PaintBrushBroad,
  SignOut,
  Stack,
  Storefront,
  Sun,
  UserCircle,
  UserCirclePlus,
} from "@phosphor-icons/react";
import { useNavigate } from "@tanstack/react-router";
import { useTheme } from "../../hooks/useTheme";
import { useAuth } from "../../services/api/useAuth";

export default function NavMenuShopDropdown() {
  const { setTheme } = useTheme();
  const { logout } = useAuth();
  const navigate = useNavigate();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="outline-none">
        <div className="flex items-center gap-1.5 p-1 hover:bg-menu-active/50 rounded-md cursor-pointer select-none ">
          <AvatarLogo alt="Logo">SM</AvatarLogo>
          <div className="text-sm text-text font-medium select-none truncate">
            Test storess
          </div>
          <CaretDown size={12} weight="bold" className="text-muted" />
        </div>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="start">
        <DropdownMenuItem>
          <UserCircle size={18} weight="fill" className="mr-2 text-muted" />{" "}
          Edit profile
        </DropdownMenuItem>

        <DropdownMenuSub>
          <DropdownMenuSubTrigger>
            <PaintBrushBroad
              size={18}
              weight="fill"
              className="mr-2 text-muted"
            />{" "}
            Theme
          </DropdownMenuSubTrigger>
          <DropdownMenuPortal>
            <DropdownMenuSubContent>
              <DropdownMenuItem onClick={() => setTheme("light")}>
                <Sun size={18} weight="fill" className="mr-2 text-orange" />{" "}
                Light
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("dark")}>
                <Ghost size={18} weight="fill" className="mr-2 text-muted" />{" "}
                Dark
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("system")}>
                <Desktop size={18} weight="fill" className="mr-2 text-muted" />
                System
              </DropdownMenuItem>
            </DropdownMenuSubContent>
          </DropdownMenuPortal>
        </DropdownMenuSub>

        <DropdownMenuSeparator />

        <DropdownMenuItem onClick={() => navigate({ to: "/settings/profile" })}>
          <Storefront size={18} weight="fill" className="mr-2 text-muted" />
          Store settings
        </DropdownMenuItem>
        <DropdownMenuItem>
          <UserCirclePlus size={18} weight="fill" className="mr-2 text-muted" />
          Invite members
        </DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuSub>
          <DropdownMenuSubTrigger>
            <Stack size={18} weight="fill" className="mr-2 text-muted" />
            Switch stores
          </DropdownMenuSubTrigger>
          <DropdownMenuPortal>
            <DropdownMenuSubContent>
              <DropdownMenuItem>
                <div className="flex items-center gap-1.5">
                  <AvatarLogo alt="Logo">SM</AvatarLogo>
                  <div className="text-sm text-text font-medium">
                    Test store
                  </div>
                </div>
              </DropdownMenuItem>
            </DropdownMenuSubContent>
          </DropdownMenuPortal>
        </DropdownMenuSub>
        <DropdownMenuItem onClick={logout}>
          <SignOut size={18} weight="fill" className="mr-2 text-muted" />
          Logout
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
