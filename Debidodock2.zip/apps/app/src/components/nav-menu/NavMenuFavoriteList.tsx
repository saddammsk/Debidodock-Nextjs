import { Favorite } from "@debido/server";
import { cn } from "@debido/ui/lib/utils";
import { DndContext, closestCorners } from "@dnd-kit/core";
import { CaretRight } from "@phosphor-icons/react";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { useDndOnDragEnd } from "../../hooks/useDndOnDragEnd";
import SortableDroppable from "../common/SortableDroppable";
import NavMenuFavoriteListItem from "./NavMenuFavoriteListItem";

const favorites: Favorite[] = [
  {
    title: "PO 12",
    path: "/purchase-order/r23ihp3uhfksdfadfsdf",
    type: "PURCHASE_ORDER",
    createdAt: new Date(),
    updatedAt: new Date(),
    id: "1",
    membershipId: "1",
  },
  {
    id: "2",
    title: "Purchase order",
    path: "/purchase-order/r23ihp3r2iuhfksdfadfsdf",
    type: "BOARD",
    createdAt: new Date(),
    updatedAt: new Date(),
    membershipId: "1",
  },
  {
    id: "3",
    title: "Velour hoodie",
    path: "/purchase-order/12213223fdgg",
    type: "PRODUCT",
    createdAt: new Date(),
    updatedAt: new Date(),
    membershipId: "1",
  },
];

export default function NavMenuFavoriteList() {
  const [open, setOpen] = useState(true);
  const [favoriteList, setFavoriteList] = useState(favorites);
  const { handleDragEnd, sensors } = useDndOnDragEnd(
    setFavoriteList,
    favoriteList
  );

  return (
    <div className="mt-8">
      {/* HEADER */}
      <DndContext
        onDragEnd={handleDragEnd}
        sensors={sensors}
        collisionDetection={closestCorners}
      >
        <div
          onClick={() => setOpen(!open)}
          className="text-xs cursor-pointer flex items-center gap-2 py-1.5 text-muted px-2 rounded-[4px] hover:bg-menu-active transition-colors duration-100 select-none"
        >
          Favorites
          <CaretRight
            size={12}
            weight="fill"
            className={cn(
              "ml-1 text-muted transition-all duration-100",
              open && "rotate-90"
            )}
          />
        </div>

        {/* ITEMS */}
        <AnimatePresence>
          {open && (
            <SortableDroppable items={favoriteList}>
              <motion.ul
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.1 }}
                className="flex flex-col gap-1 mt-1"
              >
                {favoriteList.map((favorite) => (
                  <NavMenuFavoriteListItem
                    key={favorite.id}
                    favorite={favorite}
                  />
                ))}
              </motion.ul>
            </SortableDroppable>
          )}
        </AnimatePresence>
      </DndContext>
    </div>
  );
}
