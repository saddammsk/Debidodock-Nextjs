import { Button } from "@debido/ui/components/button";
import NavMenuShopDropdown from "./NavMenuShopDropdown";
import { Bell, Layout, Package, Plus, Tag } from "@phosphor-icons/react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@debido/ui/components/dropdown-menu";

export default function NavMenuTop() {
  return (
    <div className="flex items-center justify-between px-0.5">
      {/* SHOP DROPDOWN */}
      <NavMenuShopDropdown />

      {/* ICONS */}
      <div className="flex items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="size-6" size="icon">
              <Plus size={18} className="text-muted" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem>
              <Package size={18} weight="fill" className="mr-2 text-muted" />
              Create purchase order
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Tag size={18} weight="fill" className="mr-2 text-muted" />
              Create product
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Layout size={18} weight="fill" className="mr-2 text-muted" />
              New board
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button variant="ghost" className="size-6" size="icon">
          <Bell size={18} className="text-muted" />
        </Button>
      </div>
    </div>
  );
}
