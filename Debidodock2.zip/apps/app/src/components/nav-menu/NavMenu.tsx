import NavMenuTop from "./NavMenuTop";
import NavMenuItems from "./NavMenuItems";
import NavMenuFavoriteList from "./NavMenuFavoriteList";
import NavMenuBoardList from "./NavMenuBoardList";

export default function MainNavMenu() {
  return (
    <div>
      <NavMenuTop />

      {/* NAV MENU ITEMS */}
      <NavMenuItems />

      {/* NAV MENU FAVORITES */}
      <NavMenuFavoriteList />

      {/* NAV MENU BOARDS */}
      <NavMenuBoardList />
    </div>
  );
}
