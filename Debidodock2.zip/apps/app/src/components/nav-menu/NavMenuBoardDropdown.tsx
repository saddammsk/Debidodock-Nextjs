import { Button } from "@debido/ui/components/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@debido/ui/components/dropdown-menu";
import {
  CirclesThreePlus,
  Copy,
  DotsThree,
  Globe,
  ShareFat,
  Textbox,
  Trash,
} from "@phosphor-icons/react";

export default function NavMenuBoardDropdown() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="outline-none">
        <Button
          onClick={() => console.log("Create board")}
          className="h-3 w-4 text-muted hover:text-text hover:bg-transparent group-hover:flex hidden mr-2"
          variant="ghost"
          size="icon"
        >
          <DotsThree
            weight="bold"
            className="shrink-0 hover:text-text text-muted mr-2"
            size={16}
          />
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="start" className="w-[200px]">
        <DropdownMenuItem>
          <Copy size={18} weight="fill" className="mr-2 text-muted" />
          Copy link
        </DropdownMenuItem>
        <DropdownMenuItem>
          <ShareFat size={18} weight="fill" className="mr-2 text-muted" />
          Share board
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Globe size={18} weight="fill" className="mr-2 text-muted" />
          Make board public
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem>
          <Textbox size={18} weight="fill" className="mr-2 text-muted" />
          Edit name
        </DropdownMenuItem>
        <DropdownMenuItem>
          <CirclesThreePlus
            size={18}
            weight="fill"
            className="mr-2 text-muted"
          />
          Change layout
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem>
          <Trash size={18} weight="fill" className="mr-2 text-muted" />
          Delete board
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
