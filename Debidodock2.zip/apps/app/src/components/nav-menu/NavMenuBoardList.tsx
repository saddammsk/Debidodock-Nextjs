import { Board } from "@debido/server";
import { Button } from "@debido/ui/components/button";
import { cn } from "@debido/ui/lib/utils";
import { DndContext, closestCorners } from "@dnd-kit/core";
import { CaretRight, Plus } from "@phosphor-icons/react";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { useDndOnDragEnd } from "../../hooks/useDndOnDragEnd";
import SortableDroppable from "../common/SortableDroppable";
import NavMenuBoardListItem from "./NavMenuBoardListItem";

const boards: Board[] = [
  {
    id: "1",
    title: "Board 1",
    icon: "package",
    createdAt: new Date(),
    updatedAt: new Date(),
    membershipId: "1",
    items: {},
    path: "/board/1",
  },
  {
    id: "2",
    title: "Board 2",
    icon: "package",
    createdAt: new Date(),
    updatedAt: new Date(),
    membershipId: "1",
    items: {},
    path: "/board/2",
  },
  {
    id: "3",
    title: "Board 3",
    icon: "package",
    createdAt: new Date(),
    updatedAt: new Date(),
    membershipId: "1",
    items: {},
    path: "/board/3",
  },
];

export default function NavMenuBoardList() {
  const [open, setOpen] = useState(true);
  const [boardList, setBoardList] = useState(boards);
  const { handleDragEnd, sensors } = useDndOnDragEnd(setBoardList, boardList);

  return (
    <div className="mt-8">
      {/* HEADER */}
      <DndContext
        onDragEnd={handleDragEnd}
        sensors={sensors}
        collisionDetection={closestCorners}
      >
        <div className="text-xs cursor-pointer flex items-center justify-between py-1.5 text-muted px-2 rounded-[4px] hover:bg-menu-active transition-colors duration-100 select-none group">
          <div
            onClick={() => setOpen(!open)}
            className="flex items-center gap-2 w-full"
          >
            Boards
            <CaretRight
              size={12}
              weight="fill"
              className={cn(
                "ml-1 text-muted transition-all duration-100",
                open && "rotate-90"
              )}
            />
          </div>
          <Button
            onClick={() => console.log("Create board")}
            className="h-3 w-4 text-muted hover:text-text hover:bg-transparent group-hover:flex hidden mr-2"
            variant="ghost"
            size="icon"
          >
            <Plus size={12} weight="bold" className="text-muted" />
          </Button>
        </div>

        {/* ITEMS */}
        <AnimatePresence>
          {open && (
            <SortableDroppable items={boardList}>
              <motion.ul
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.1 }}
                className="flex flex-col gap-1 mt-1"
              >
                {boardList.map((board) => (
                  <NavMenuBoardListItem key={board.id} board={board} />
                ))}
              </motion.ul>
            </SortableDroppable>
          )}
        </AnimatePresence>
      </DndContext>
    </div>
  );
}
