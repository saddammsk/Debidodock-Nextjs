import React from "react";
import SortableDraggable from "../common/SortableDraggable";

import { Board } from "@debido/server";
import { cn } from "@debido/ui/lib/utils";
import { Layout } from "@phosphor-icons/react";
import { useLocation, useNavigate } from "@tanstack/react-router";
import NavMenuBoardDropdown from "./NavMenuBoardDropdown";

type NavMenuBoardListItemProps = {
  board: Board;
};

export default function NavMenuBoardListItem({
  board,
}: NavMenuBoardListItemProps) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  return (
    <SortableDraggable key={board.id} id={board.id}>
      <li
        className={cn(
          "flex items-center justify-between relative cursor-pointer rounded-[4px] hover:bg-menu-active text-muted hover:text-text group",
          pathname === board.path && "bg-menu-active text-text"
        )}
      >
        <div
          onClick={() => navigate({ to: board.path })}
          className="flex items-center gap-2 px-2 py-1.5 w-full"
        >
          <Layout size={18} weight="fill" className="text-muted" />
          <div className="text-sm group-hover:text-text font-medium select-none">
            {board.title}
          </div>
        </div>

        {/* DROPDOWN */}
        <NavMenuBoardDropdown />
      </li>
    </SortableDraggable>
  );
}
