import { useLocation, useNavigate } from "@tanstack/react-router";
import { cn } from "@debido/ui/lib/utils";
import { X } from "@phosphor-icons/react";
import { Favorite } from "@debido/server";
import FavoriteItemIcon from "../common/FavoriteItemIcon";
import SortableDraggable from "../common/SortableDraggable";

type NavMenuFavoriteListItemProps = {
  favorite: Favorite;
};

export default function NavMenuFavoriteListItem({
  favorite,
}: NavMenuFavoriteListItemProps) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  return (
    <SortableDraggable key={favorite.id} id={favorite.id}>
      <li
        key={favorite.id}
        className={cn(
          "flex items-center justify-between relative cursor-pointer rounded-[4px] hover:bg-menu-active text-muted hover:text-text group",
          pathname === favorite.path && "bg-menu-active text-text"
        )}
      >
        <div
          onClick={() => navigate({ to: favorite.path })}
          className="flex items-center gap-2 px-2 py-1.5 w-full"
        >
          <FavoriteItemIcon
            type={favorite.type}
            props={{ size: 18, weight: "fill" }}
          />
          <div className="text-sm group-hover:text-text font-medium select-none">
            {favorite.title}
          </div>
        </div>

        {/* X */}
        <X
          className="group-hover:flex hover:text-text hidden text-muted mr-2"
          size={12}
        />
      </li>
    </SortableDraggable>
  );
}
