import { Button } from "@debido/ui/components/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@debido/ui/components/dropdown-menu";
import { cn } from "@debido/ui/lib/utils";
import {
  Bell,
  CaretRight,
  Circle,
  CreditCard,
  DotsThree,
  GearSix,
  Icon,
  ListBullets,
  Package,
  Plus,
  Pulse,
  SpinnerGap,
  Tag,
  CirclesFour,
  Tray,
} from "@phosphor-icons/react";
import { useLocation, useNavigate } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";

type SubMenuItem = {
  title: string;
  icon: Icon;
  path?: string;
  onClick?: () => void;
  color?: string;
};

type MenuItem = {
  id: string;
  title: string;
  icon: Icon;
  menu?: SubMenuItem[] | null;
  items?: SubMenuItem[] | null;
  itemsDefualtOpen?: boolean;
  path: string;
  color?: string;
};

const menuItems: MenuItem[] = [
  {
    id: "dashboard",
    title: "Dashboard",
    icon: CirclesFour,
    menu: null,
    path: "/dashboard",
    items: null,
  },
  {
    id: "finance",
    title: "Finance",
    icon: CreditCard,
    menu: null,
    path: "/finance",
    items: null,
  },
  {
    id: "products",
    title: "Products",
    icon: Tag,
    menu: null,
    path: "/products",
    items: null,
  },
  {
    id: "purchase-orders",
    title: "Purchase orders",
    icon: Package,
    path: "/purchase-orders/all",
    menu: [
      {
        title: "Create order",
        icon: Plus,
        onClick: () => console.log("Create order"),
      },
      {
        title: "PO settings",
        icon: GearSix,
        onClick: () => console.log("Settings"),
      },
      {
        title: "Manage notifications",
        icon: Bell,
        onClick: () => console.log("Settings"),
      },
    ],
    itemsDefualtOpen: true,
    items: [
      {
        title: "All",
        icon: ListBullets,
        path: "/purchase-orders/all",
        onClick: () => console.log("All"),
        color: "text-muted",
      },
      {
        title: "Active",
        icon: Pulse,
        path: "/purchase-orders/active",
        onClick: () => console.log("Active"),
        color: "text-primary",
      },
      {
        title: "On order",
        icon: SpinnerGap,
        path: "/purchase-orders/on-order",
        onClick: () => console.log("On order"),
        color: "text-orange",
      },
      {
        title: "Drafts",
        icon: Circle,
        path: "/purchase-orders/drafts",
        onClick: () => console.log("Drafts"),
        color: "text-muted",
      },
      {
        title: "Archived",
        icon: Tray,
        path: "/purchase-orders/archived",
        onClick: () => console.log("Archived"),
        color: "text-muted",
      },
    ],
  },
];

export default function NavMenuItems() {
  const [openItem, setOpenItem] = useState<string | null>("Purchase orders");
  const { pathname } = useLocation();
  const navigate = useNavigate();

  const toggleOpenItem = (title: string) => {
    setOpenItem((prev) => (prev === title ? null : title));
  };

  return (
    <ul className="mt-4 flex flex-col relative gap-1">
      {menuItems.map((item) => (
        <li key={item.title}>
          {/* MAIN MENU */}
          <div
            className={cn(
              "flex items-center relative justify-between w-full transition-colors duration-100 cursor-pointer rounded-[4px] hover:bg-menu-active text-muted hover:text-text group",
              pathname.includes(item.id) && "bg-menu-active text-text"
            )}
            onClick={() => {
              if (item.itemsDefualtOpen) {
                toggleOpenItem(item.title);
              }
              navigate({ to: item.path });
            }}
          >
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 px-2 py-[7px]">
                <item.icon size={18} className="text-muted" />
                <div className="text-sm  font-medium">{item.title}</div>
              </div>

              {item.items && (
                <CaretRight
                  size={12}
                  weight="bold"
                  className={cn(
                    "transition-all duration-100",
                    openItem === item.title ? "rotate-90" : ""
                  )}
                />
              )}
            </div>

            {/* DROPDOWN MENU */}
            {item.menu && (
              <DropdownMenu>
                <DropdownMenuTrigger className="outline-none">
                  <Button
                    className="size-6 text-muted  hidden mr-2"
                    variant="ghost"
                    size="icon"
                  >
                    <DotsThree size={16} weight="bold" className="text-muted" />
                  </Button>
                </DropdownMenuTrigger>

                <DropdownMenuContent align="start" alignOffset={-24}>
                  {item.menu.map((menuItem) => (
                    <DropdownMenuItem
                      key={menuItem.title}
                      onClick={menuItem.onClick}
                    >
                      <menuItem.icon
                        size={18}
                        weight="fill"
                        className="mr-2 text-muted"
                      />
                      {menuItem.title}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>

          {/* SUB MENU */}
          <AnimatePresence>
            {item.items && openItem === item.title && (
              <motion.ul
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.1 }}
                className="flex flex-col gap-1 border-l pl-1 ml-4 mt-1"
              >
                {item.items.map((subItem) => (
                  <li
                    key={subItem.title}
                    className={cn(
                      "flex items-center gap-2 relative cursor-pointer rounded-[4px] hover:bg-menu-active text-muted hover:text-text group",
                      pathname === subItem.path && "bg-menu-active text-text"
                    )}
                    onClick={() => navigate({ to: subItem.path })}
                  >
                    <div className="flex items-center gap-2 px-2 py-1">
                      <subItem.icon size={18} className={subItem.color} />
                      <div className="text-sm group-hover:text-text font-medium select-none">
                        {subItem.title}
                      </div>
                    </div>

                    {pathname === subItem.path && (
                      <div className="absolute bg-text/50 -left-[5px] h-full w-px text-muted"></div>
                    )}
                  </li>
                ))}
              </motion.ul>
            )}
          </AnimatePresence>
        </li>
      ))}
    </ul>
  );
}
